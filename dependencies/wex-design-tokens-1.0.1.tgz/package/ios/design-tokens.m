
//
// design-tokens.m
//

// Do not edit directly, this file was auto-generated.


#import ".h"

@implementation 

+ (UIColor *)color:()colorEnum{
  return [[self values] objectAtIndex:colorEnum];
}

+ (NSArray *)values {
  static NSArray* colorArray;
  static dispatch_once_t onceToken;

  dispatch_once(&onceToken, ^{
    colorArray = @[
[UIColor colorWithRed:0.776f green:0.063f blue:0.180f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.341f blue:0.639f alpha:1.000f],
[UIColor colorWithRed:0.149f green:0.545f blue:0.788f alpha:1.000f],
[UIColor colorWithRed:0.051f green:0.537f blue:0.749f alpha:1.000f],
[UIColor colorWithRed:0.824f green:0.255f blue:0.349f alpha:1.000f],
[UIColor colorWithRed:0.451f green:0.490f blue:0.549f alpha:1.000f],
[UIColor colorWithRed:0.824f green:0.255f blue:0.349f alpha:1.000f],
[UIColor colorWithRed:1.000f green:1.000f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.776f green:0.184f blue:0.282f alpha:1.000f],
[UIColor colorWithRed:0.647f green:0.153f blue:0.235f alpha:1.000f],
[UIColor colorWithRed:0.569f green:0.133f blue:0.204f alpha:1.000f],
[UIColor colorWithRed:0.063f green:0.635f blue:0.878f alpha:1.000f],
[UIColor colorWithRed:1.000f green:1.000f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.051f green:0.537f blue:0.749f alpha:1.000f],
[UIColor colorWithRed:0.043f green:0.459f blue:0.635f alpha:1.000f],
[UIColor colorWithRed:0.035f green:0.376f blue:0.525f alpha:1.000f],
[UIColor colorWithRed:0.992f green:0.925f blue:0.808f alpha:1.000f],
[UIColor colorWithRed:0.984f green:0.851f blue:0.616f alpha:1.000f],
[UIColor colorWithRed:0.973f green:0.757f blue:0.384f alpha:1.000f],
[UIColor colorWithRed:0.965f green:0.682f blue:0.192f alpha:1.000f],
[UIColor colorWithRed:0.996f green:0.976f blue:0.941f alpha:1.000f],
[UIColor colorWithRed:0.961f green:0.624f blue:0.039f alpha:1.000f],
[UIColor colorWithRed:0.843f green:0.549f blue:0.035f alpha:1.000f],
[UIColor colorWithRed:0.729f green:0.475f blue:0.031f alpha:1.000f],
[UIColor colorWithRed:0.576f green:0.373f blue:0.024f alpha:1.000f],
[UIColor colorWithRed:0.424f green:0.275f blue:0.016f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.000f blue:0.000f alpha:1.000f],
[UIColor colorWithRed:0.859f green:0.933f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.702f green:0.859f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.439f green:0.737f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.122f green:0.588f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.941f green:0.973f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.478f blue:0.902f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.404f blue:0.761f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.341f blue:0.639f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.278f blue:0.522f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.212f blue:0.400f alpha:1.000f],
[UIColor colorWithRed:0.812f green:0.933f blue:0.988f alpha:1.000f],
[UIColor colorWithRed:0.627f green:0.871f blue:0.973f alpha:1.000f],
[UIColor colorWithRed:0.400f green:0.792f blue:0.957f alpha:1.000f],
[UIColor colorWithRed:0.216f green:0.725f blue:0.945f alpha:1.000f],
[UIColor colorWithRed:0.945f green:0.980f blue:0.996f alpha:1.000f],
[UIColor colorWithRed:0.063f green:0.635f blue:0.878f alpha:1.000f],
[UIColor colorWithRed:0.051f green:0.537f blue:0.749f alpha:1.000f],
[UIColor colorWithRed:0.043f green:0.459f blue:0.635f alpha:1.000f],
[UIColor colorWithRed:0.035f green:0.376f blue:0.525f alpha:1.000f],
[UIColor colorWithRed:0.027f green:0.298f blue:0.412f alpha:1.000f],
[UIColor colorWithRed:0.824f green:0.976f blue:0.878f alpha:1.000f],
[UIColor colorWithRed:0.647f green:0.953f blue:0.761f alpha:1.000f],
[UIColor colorWithRed:0.384f green:0.918f blue:0.580f alpha:1.000f],
[UIColor colorWithRed:0.122f green:0.878f blue:0.400f alpha:1.000f],
[UIColor colorWithRed:0.949f green:0.992f blue:0.965f alpha:1.000f],
[UIColor colorWithRed:0.102f green:0.737f blue:0.333f alpha:1.000f],
[UIColor colorWithRed:0.086f green:0.635f blue:0.286f alpha:1.000f],
[UIColor colorWithRed:0.071f green:0.529f blue:0.239f alpha:1.000f],
[UIColor colorWithRed:0.059f green:0.424f blue:0.192f alpha:1.000f],
[UIColor colorWithRed:0.043f green:0.318f blue:0.145f alpha:1.000f],
[UIColor colorWithRed:0.969f green:0.871f blue:0.886f alpha:1.000f],
[UIColor colorWithRed:0.933f green:0.710f blue:0.745f alpha:1.000f],
[UIColor colorWithRed:0.886f green:0.514f blue:0.576f alpha:1.000f],
[UIColor colorWithRed:0.847f green:0.353f blue:0.435f alpha:1.000f],
[UIColor colorWithRed:0.988f green:0.953f blue:0.957f alpha:1.000f],
[UIColor colorWithRed:0.824f green:0.255f blue:0.349f alpha:1.000f],
[UIColor colorWithRed:0.776f green:0.184f blue:0.282f alpha:1.000f],
[UIColor colorWithRed:0.647f green:0.153f blue:0.235f alpha:1.000f],
[UIColor colorWithRed:0.518f green:0.122f blue:0.188f alpha:1.000f],
[UIColor colorWithRed:0.388f green:0.090f blue:0.141f alpha:1.000f],
[UIColor colorWithRed:0.953f green:0.961f blue:0.969f alpha:1.000f],
[UIColor colorWithRed:0.882f green:0.902f blue:0.918f alpha:1.000f],
[UIColor colorWithRed:0.773f green:0.800f blue:0.827f alpha:1.000f],
[UIColor colorWithRed:0.608f green:0.651f blue:0.690f alpha:1.000f],
[UIColor colorWithRed:0.976f green:0.980f blue:0.984f alpha:1.000f],
[UIColor colorWithRed:0.451f green:0.502f blue:0.549f alpha:1.000f],
[UIColor colorWithRed:0.318f green:0.369f blue:0.424f alpha:1.000f],
[UIColor colorWithRed:0.224f green:0.278f blue:0.337f alpha:1.000f],
[UIColor colorWithRed:0.145f green:0.200f blue:0.255f alpha:1.000f],
[UIColor colorWithRed:0.090f green:0.129f blue:0.169f alpha:1.000f],
[UIColor colorWithRed:1.000f green:1.000f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.969f green:0.953f blue:0.988f alpha:1.000f],
[UIColor colorWithRed:0.922f green:0.871f blue:0.969f alpha:1.000f],
[UIColor colorWithRed:0.820f green:0.714f blue:0.929f alpha:1.000f],
[UIColor colorWithRed:0.702f green:0.522f blue:0.878f alpha:1.000f],
[UIColor colorWithRed:0.600f green:0.361f blue:0.839f alpha:1.000f],
[UIColor colorWithRed:0.502f green:0.200f blue:0.800f alpha:1.000f],
[UIColor colorWithRed:0.439f green:0.176f blue:0.706f alpha:1.000f],
[UIColor colorWithRed:0.380f green:0.153f blue:0.608f alpha:1.000f],
[UIColor colorWithRed:0.302f green:0.122f blue:0.478f alpha:1.000f],
[UIColor colorWithRed:0.220f green:0.086f blue:0.353f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.341f blue:0.639f alpha:1.000f],
[UIColor colorWithRed:1.000f green:1.000f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.278f blue:0.522f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.212f blue:0.400f alpha:1.000f],
[UIColor colorWithRed:0.086f green:0.635f blue:0.286f alpha:1.000f],
[UIColor colorWithRed:1.000f green:1.000f blue:1.000f alpha:1.000f],
[UIColor colorWithRed:0.071f green:0.529f blue:0.239f alpha:1.000f],
[UIColor colorWithRed:0.059f green:0.424f blue:0.192f alpha:1.000f],
[UIColor colorWithRed:0.047f green:0.353f blue:0.161f alpha:1.000f],
[UIColor colorWithRed:0.961f green:0.624f blue:0.039f alpha:1.000f],
[UIColor colorWithRed:0.000f green:0.000f blue:0.000f alpha:1.000f],
[UIColor colorWithRed:0.843f green:0.549f blue:0.035f alpha:1.000f],
[UIColor colorWithRed:0.576f green:0.373f blue:0.024f alpha:1.000f],
[UIColor colorWithRed:0.498f green:0.325f blue:0.020f alpha:1.000f]
    ];
  });

  return colorArray;
}

@end