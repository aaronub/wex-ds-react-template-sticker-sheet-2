/**
 * WexListbox - WEX Design System Listbox Component
 *
 * A list selection component with full accessibility support.
 * This is a custom component that exists only in wex-components-react.
 *
 * Features:
 * - Single and multiple selection modes
 * - Optional checkmarks or checkboxes
 * - Filtering support
 * - Grouped options
 * - Full keyboard navigation (Arrow keys, Home, End, Enter, Space, type-ahead)
 * - Roving tabindex for proper focus management
 * - ARIA compliant
 *
 * @example
 * // Basic single selection
 * <WexListbox
 *   options={cities}
 *   value={selected}
 *   onValueChange={setSelected}
 *   aria-label="Select a city"
 * >
 *   <WexListbox.Options />
 * </WexListbox>
 *
 * @example
 * // Multiple selection with checkboxes
 * <WexListbox
 *   options={cities}
 *   value={selectedCities}
 *   onValueChange={setSelectedCities}
 *   multiple
 *   checkbox
 *   aria-label="Select cities"
 * >
 *   <WexListbox.Options />
 * </WexListbox>
 *
 * @example
 * // With filter
 * <WexListbox
 *   options={cities}
 *   value={selected}
 *   onValueChange={setSelected}
 *   aria-label="Select a city"
 * >
 *   <WexListbox.Header>
 *     <WexListbox.Filter placeholder="Search city..." />
 *   </WexListbox.Header>
 *   <WexListbox.Options />
 *   <WexListbox.Empty>No cities found</WexListbox.Empty>
 * </WexListbox>
 */

import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { Check, Search } from "lucide-react"
import { cn } from "./lib/utils"
import { WexCheckbox } from "./wex-checkbox"
import { WexInput, type WexInputProps } from "./wex-input"
import { multiSelectOptionVariants as listboxOptionVariants } from "./wex-multiselect"

// ============================================================================
// TYPES
// ============================================================================

export interface ListboxOptionData {
  label: string
  value: string
  disabled?: boolean
  group?: string
}

interface ListboxContextValue {
  // Data
  options: ListboxOptionData[]
  value: string | string[] | null
  // Config
  multiple: boolean
  checkmark: boolean
  checkbox: boolean
  disabled: boolean
  // Accessibility
  ariaLabel?: string
  ariaLabelledBy?: string
  // State
  focusedIndex: number
  hasFocus: boolean
  isKeyboardNav: boolean
  filterValue: string
  filteredOptions: ListboxOptionData[]
  // For manual options
  totalOptions: number
  firstEnabledIndex: number
  // Actions
  onValueChange: (value: string | string[] | null) => void
  setFocusedIndex: (index: number) => void
  setIsKeyboardNav: (isKeyboard: boolean) => void
  setFilterValue: (value: string) => void
  handleSelect: (optionValue: string, optionDisabled?: boolean) => void
  handleKeyDown: (e: React.KeyboardEvent) => void
  isSelected: (optionValue: string) => boolean
  registerOption: (disabled?: boolean) => number
  focusOption: (index: number, fromKeyboard?: boolean) => void
  // Refs
  listRef: React.RefObject<HTMLUListElement | null>
  optionRefs: React.MutableRefObject<Map<number, HTMLLIElement>>
}

const ListboxContext = React.createContext<ListboxContextValue | null>(null)

function useListboxContext() {
  const context = React.useContext(ListboxContext)
  if (!context) {
    throw new Error("Listbox components must be used within a <WexListbox>")
  }
  return context
}

// ============================================================================
// STYLES
// ============================================================================

/** Shell: align with WexMultiSelect / WexSelect popover (see wex-multiselect, wex-select). */
export const listboxVariants = cva(
  "w-full overflow-hidden rounded-[var(--wex-radius-controls-large)] border border-solid border-border bg-wex-select-content-bg text-sm text-wex-select-content-fg shadow-[var(--wex-shadow-medium)] transition-colors",
  {
    variants: {
      invalid: {
        true: "border-wex-listbox-invalid-border",
        false: "",
      },
      disabled: {
        true: "opacity-50 cursor-not-allowed",
        false: "",
      },
    },
    defaultVariants: {
      invalid: false,
      disabled: false,
    },
  }
)

/** Row styling matches WexMultiSelect list options. */
export { listboxOptionVariants }

// ============================================================================
// LISTBOX ROOT
// ============================================================================

export interface ListboxRootProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange">,
    VariantProps<typeof listboxVariants> {
  /** Array of options (for auto-generated options) */
  options?: ListboxOptionData[]
  /** Currently selected value(s) */
  value?: string | string[] | null
  /** Callback when selection changes */
  onValueChange?: (value: string | string[] | null) => void
  /** Enable multiple selection */
  multiple?: boolean
  /** Show checkmark next to selected items */
  checkmark?: boolean
  /** Show checkbox for multiple selection */
  checkbox?: boolean
  /** Accessible label */
  "aria-label"?: string
  /** ID of element that labels this listbox */
  "aria-labelledby"?: string
}

function ListboxRoot({
  className,
  children,
  options = [],
  value = null,
  onValueChange = () => {},
  multiple = false,
  checkmark = false,
  checkbox = false,
  invalid = false,
  disabled = false,
  "aria-label": ariaLabel,
  "aria-labelledby": ariaLabelledBy,
  ...props
}: ListboxRootProps) {
  const listRef = React.useRef<HTMLUListElement>(null)
  const containerRef = React.useRef<HTMLDivElement>(null)
  const optionRefs = React.useRef<Map<number, HTMLLIElement>>(new Map())
  const [focusedIndex, setFocusedIndex] = React.useState<number>(-1)
  const [hasFocus, setHasFocus] = React.useState(false)
  const [isKeyboardNav, setIsKeyboardNav] = React.useState(false)
  const [filterValue, setFilterValue] = React.useState("")
  const [typeaheadBuffer, setTypeaheadBuffer] = React.useState("")
  const typeaheadTimeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)
  
  // Counter and tracking for manual option registration
  const optionCounterRef = React.useRef(0)
  const firstEnabledIndexRef = React.useRef<number>(-1)

  // Filter options based on search input
  const filteredOptions = React.useMemo(() => {
    if (!filterValue) return options
    return options.filter((option) =>
      option.label.toLowerCase().includes(filterValue.toLowerCase())
    )
  }, [options, filterValue])

  // First enabled index for data-driven options
  const firstEnabledDataIndex = React.useMemo(() => {
    return filteredOptions.findIndex((option) => !option.disabled)
  }, [filteredOptions])

  // Track manual option count using state to avoid ref access during render
  const [manualOptionCount, setManualOptionCount] = React.useState(0)
  const [manualFirstEnabledIndex, setManualFirstEnabledIndex] = React.useState<number>(-1)

  // Total options count (from data or manual registration)
  const totalOptions = React.useMemo(() => {
    return filteredOptions.length > 0 ? filteredOptions.length : manualOptionCount
  }, [filteredOptions.length, manualOptionCount])

  // First enabled index (data-driven or manual)
  const firstEnabledIndex = React.useMemo(() => {
    return filteredOptions.length > 0 ? firstEnabledDataIndex : manualFirstEnabledIndex
  }, [filteredOptions.length, firstEnabledDataIndex, manualFirstEnabledIndex])

  // Register a manual option and return its index
  const registerOption = React.useCallback((optionDisabled?: boolean) => {
    const index = optionCounterRef.current
    optionCounterRef.current += 1
    setManualOptionCount(optionCounterRef.current)
    // Track first enabled option for manual options
    if (!optionDisabled && manualFirstEnabledIndex === -1) {
      setManualFirstEnabledIndex(index)
    }
    return index
  }, [manualFirstEnabledIndex])

  // Focus a specific option
  const focusOption = React.useCallback((index: number, fromKeyboard = false) => {
    const optionEl = optionRefs.current.get(index)
    if (optionEl) {
      optionEl.focus()
      setFocusedIndex(index)
      setIsKeyboardNav(fromKeyboard)
    }
  }, [])

  // Check if a value is selected
  const isSelected = React.useCallback(
    (optionValue: string) => {
      if (value === null || value === undefined) return false
      if (multiple && Array.isArray(value)) {
        return value.includes(optionValue)
      }
      return value === optionValue
    },
    [value, multiple]
  )

  // Handle option selection
  const handleSelect = React.useCallback(
    (optionValue: string, optionDisabled?: boolean) => {
      if (disabled || optionDisabled) return

      if (multiple) {
        const currentValue = Array.isArray(value) ? value : []
        if (currentValue.includes(optionValue)) {
          onValueChange(currentValue.filter((v) => v !== optionValue))
        } else {
          onValueChange([...currentValue, optionValue])
        }
      } else {
        onValueChange(optionValue)
      }
    },
    [disabled, multiple, value, onValueChange]
  )

  // Get flat list of enabled option indices for keyboard navigation
  const enabledIndices = React.useMemo(() => {
    if (filteredOptions.length > 0) {
      return filteredOptions
        .map((option, index) => ({ index, disabled: option.disabled }))
        .filter((item) => !item.disabled)
        .map((item) => item.index)
    }
    // For manual options, assume all are enabled (disabled ones handle it themselves)
    return Array.from({ length: totalOptions }, (_, i) => i)
  }, [filteredOptions, totalOptions])

  // Keyboard navigation
  const handleKeyDown = React.useCallback(
    (e: React.KeyboardEvent) => {
      if (disabled) return

      const currentEnabledIndex = enabledIndices.indexOf(focusedIndex)

      switch (e.key) {
        case "ArrowDown":
          e.preventDefault()
          if (currentEnabledIndex < enabledIndices.length - 1) {
            focusOption(enabledIndices[currentEnabledIndex + 1], true)
          } else if (focusedIndex === -1 && enabledIndices.length > 0) {
            focusOption(enabledIndices[0], true)
          }
          break

        case "ArrowUp":
          e.preventDefault()
          if (currentEnabledIndex > 0) {
            focusOption(enabledIndices[currentEnabledIndex - 1], true)
          }
          break

        case "Home":
          e.preventDefault()
          if (enabledIndices.length > 0) {
            focusOption(enabledIndices[0], true)
          }
          break

        case "End":
          e.preventDefault()
          if (enabledIndices.length > 0) {
            focusOption(enabledIndices[enabledIndices.length - 1], true)
          }
          break

        case "Enter":
        case " ":
          e.preventDefault()
          if (focusedIndex >= 0) {
            const option = filteredOptions[focusedIndex]
            if (option) {
              handleSelect(option.value, option.disabled)
            } else {
              // Manual option - let the option handle it via onClick
              const optionEl = optionRefs.current.get(focusedIndex)
              if (optionEl) {
                optionEl.click()
              }
            }
          }
          break

        case "a":
        case "A":
          if (e.ctrlKey && multiple) {
            e.preventDefault()
            const allValues = filteredOptions
              .filter((o) => !o.disabled)
              .map((o) => o.value)
            onValueChange(allValues)
          }
          break

        default:
          // Type-ahead: jump to option starting with typed character
          if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
            const char = e.key.toLowerCase()

            if (typeaheadTimeoutRef.current) {
              clearTimeout(typeaheadTimeoutRef.current)
            }

            const newBuffer = typeaheadBuffer + char
            setTypeaheadBuffer(newBuffer)

            const matchIndex = filteredOptions.findIndex(
              (option) =>
                !option.disabled &&
                option.label.toLowerCase().startsWith(newBuffer)
            )

            if (matchIndex >= 0) {
              focusOption(matchIndex, true)
            }

            typeaheadTimeoutRef.current = setTimeout(() => {
              setTypeaheadBuffer("")
            }, 500)
          }
      }
    },
    [
      disabled,
      enabledIndices,
      focusedIndex,
      filteredOptions,
      handleSelect,
      multiple,
      onValueChange,
      typeaheadBuffer,
      focusOption,
    ]
  )

  // Reset option counter and first enabled index when children change
  React.useEffect(() => {
    optionCounterRef.current = 0
    firstEnabledIndexRef.current = -1
    queueMicrotask(() => {
      setManualOptionCount(0)
      setManualFirstEnabledIndex(-1)
    })
  }, [children])

  // Handle focus entering/leaving the listbox container
  const handleContainerFocus = React.useCallback(() => {
    setHasFocus(true)
  }, [])

  const handleContainerBlur = React.useCallback((e: React.FocusEvent) => {
    // Only set hasFocus to false if focus is leaving the container entirely
    if (!containerRef.current?.contains(e.relatedTarget as Node)) {
      setHasFocus(false)
      setIsKeyboardNav(false)
    }
  }, [])

  const contextValue: ListboxContextValue = {
    options,
    value,
    multiple,
    checkmark,
    checkbox,
    disabled: disabled ?? false,
    ariaLabel,
    ariaLabelledBy,
    focusedIndex,
    hasFocus,
    isKeyboardNav,
    filterValue,
    filteredOptions,
    totalOptions,
    firstEnabledIndex,
    onValueChange,
    setFocusedIndex,
    setIsKeyboardNav,
    setFilterValue,
    handleSelect,
    handleKeyDown,
    isSelected,
    registerOption,
    focusOption,
    listRef,
    optionRefs,
  }

  return (
    <ListboxContext.Provider value={contextValue}>
      <div
        ref={containerRef}
        className={cn(listboxVariants({ invalid, disabled }), className)}
        onFocus={handleContainerFocus}
        onBlur={handleContainerBlur}
        {...props}
      >
        {children}
      </div>
    </ListboxContext.Provider>
  )
}

// ============================================================================
// LISTBOX.HEADER
// ============================================================================

export type ListboxHeaderProps = React.HTMLAttributes<HTMLDivElement>

function ListboxHeader({ className, children, ...props }: ListboxHeaderProps) {
  return (
    <div
      data-slot="listbox-header"
      className={cn("border-b border-border p-2", className)}
      {...props}
    >
      {children}
    </div>
  )
}

// ============================================================================
// LISTBOX.FILTER
// ============================================================================

export interface ListboxFilterProps
  extends Omit<WexInputProps, "onChange" | "value" | "defaultValue"> {
  /** Custom input (defaults to WexInput) */
  as?: React.ComponentType<WexInputProps>
  /** Icon to show in filter */
  showIcon?: boolean
}

function ListboxFilter({
  className,
  placeholder = "Search...",
  showIcon = true,
  as: Component,
  size = "md",
  ...props
}: ListboxFilterProps) {
  const { filterValue, setFilterValue, disabled } = useListboxContext()

  const InputComponent = Component || WexInput

  return (
    <div className="relative">
      {showIcon && (
        <Search className="absolute left-2 top-1/2 z-[1] h-4 w-4 -translate-y-1/2 text-wex-multiselect-search-icon-fg" />
      )}
      <InputComponent
        type="text"
        data-slot="listbox-filter"
        placeholder={placeholder}
        value={filterValue}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setFilterValue(e.target.value)
        }
        className={cn(showIcon && "pl-8", className)}
        disabled={disabled}
        size={size}
        {...props}
      />
    </div>
  )
}

// ============================================================================
// LISTBOX.SELECTALL
// ============================================================================

export interface ListboxSelectAllProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  /** Label text for the select all checkbox */
  label?: string
}

function ListboxSelectAll({
  className,
  label = "Select All",
  ...props
}: ListboxSelectAllProps) {
  const {
    filteredOptions,
    value,
    multiple,
    disabled,
    onValueChange,
  } = useListboxContext()

  // Get all selectable (non-disabled) option values
  // Must be called before any conditional returns to satisfy hooks rules
  const selectableValues = React.useMemo(
    () => filteredOptions.filter((o) => !o.disabled).map((o) => o.value),
    [filteredOptions]
  )

  // Only works in multiple selection mode
  if (!multiple) return null

  // Calculate selection state
  const selectedValues = Array.isArray(value) ? value : []
  const selectedCount = selectableValues.filter((v) => selectedValues.includes(v)).length
  const allSelected = selectedCount === selectableValues.length && selectableValues.length > 0
  const someSelected = selectedCount > 0 && selectedCount < selectableValues.length

  // Determine checkbox state
  const checkboxState: boolean | "indeterminate" = allSelected
    ? true
    : someSelected
    ? "indeterminate"
    : false

  const handleToggle = () => {
    if (disabled) return

    if (allSelected) {
      // Deselect all selectable options (keep any manually selected disabled options)
      const remainingValues = selectedValues.filter(
        (v) => !selectableValues.includes(v)
      )
      onValueChange(remainingValues.length > 0 ? remainingValues : [])
    } else {
      // Select all selectable options (keep any already selected values)
      const newValues = Array.from(new Set([...selectedValues, ...selectableValues]))
      onValueChange(newValues)
    }
  }

  return (
    <label
      data-slot="listbox-selectall"
      className={cn(
        "flex w-full cursor-pointer select-none items-center gap-2 border-b border-border px-3 py-2 text-sm font-medium transition-colors hover:bg-wex-multiselect-item-hover-bg/50",
        disabled && "pointer-events-none cursor-not-allowed opacity-50",
        className
      )}
      {...props}
    >
      <WexCheckbox
        className="shrink-0"
        checked={checkboxState}
        disabled={disabled}
        onCheckedChange={() => handleToggle()}
      />
      <span className="min-w-0 flex-1 truncate">{label}</span>
      {selectableValues.length > 0 && (
        <span className="ml-auto shrink-0 text-xs text-wex-multiselect-count-fg">
          ({selectedCount}/{selectableValues.length})
        </span>
      )}
    </label>
  )
}

// ============================================================================
// LISTBOX.OPTIONS
// ============================================================================

export interface ListboxOptionsProps extends React.HTMLAttributes<HTMLUListElement> {
  /** Accessible label */
  "aria-label"?: string
  /** ID of element that labels this listbox */
  "aria-labelledby"?: string
}

function ListboxOptions({
  className,
  children,
  "aria-label": ariaLabelProp,
  "aria-labelledby": ariaLabelledByProp,
  onMouseLeave,
  ...props
}: ListboxOptionsProps) {
  const {
    filteredOptions,
    multiple,
    disabled,
    focusedIndex,
    isKeyboardNav,
    setFocusedIndex,
    listRef,
    ariaLabel: ariaLabelContext,
    ariaLabelledBy: ariaLabelledByContext,
  } = useListboxContext()

  // Use props if provided, otherwise fall back to context
  const ariaLabel = ariaLabelProp ?? ariaLabelContext
  const ariaLabelledBy = ariaLabelledByProp ?? ariaLabelledByContext

  // If no children provided, auto-generate from options
  const hasChildren = React.Children.count(children) > 0

  // Group options if any have group property
  const groupedOptions = React.useMemo(() => {
    const groups: Record<string, ListboxOptionData[]> = {}
    const ungrouped: ListboxOptionData[] = []

    filteredOptions.forEach((option) => {
      if (option.group) {
        if (!groups[option.group]) {
          groups[option.group] = []
        }
        groups[option.group].push(option)
      } else {
        ungrouped.push(option)
      }
    })

    return { groups, ungrouped }
  }, [filteredOptions])

  const hasGroups = Object.keys(groupedOptions.groups).length > 0

  let optionIndex = 0

  // Generate unique ID for aria-activedescendant
  const activeDescendantId = focusedIndex >= 0 ? `listbox-option-${focusedIndex}` : undefined

  const handleListMouseLeave = (e: React.MouseEvent<HTMLUListElement>) => {
    onMouseLeave?.(e)
    if (!isKeyboardNav) {
      setFocusedIndex(-1)
    }
  }

  return (
    <ul
      ref={listRef}
      role="listbox"
      aria-label={ariaLabel}
      aria-labelledby={ariaLabelledBy}
      aria-multiselectable={multiple}
      aria-disabled={disabled}
      aria-activedescendant={activeDescendantId}
      data-slot="listbox-options"
      className={cn("max-h-60 overflow-auto p-1 focus:outline-none", className)}
      onMouseLeave={handleListMouseLeave}
      {...props}
    >
      {hasChildren ? (
        children
      ) : filteredOptions.length === 0 ? (
        <li className="px-3 py-2 text-center text-sm text-wex-multiselect-empty-fg">
          No options found
        </li>
      ) : hasGroups ? (
        <>
          {groupedOptions.ungrouped.map((option) => {
            const index = optionIndex++
            return (
              <ListboxOption key={option.value} index={index} option={option} />
            )
          })}
          {Object.entries(groupedOptions.groups).map(
            ([groupName, groupOptions]) => (
              <ListboxGroup key={groupName} label={groupName}>
                {groupOptions.map((option) => {
                  const index = optionIndex++
                  return (
                    <ListboxOption
                      key={option.value}
                      index={index}
                      option={option}
                    />
                  )
                })}
              </ListboxGroup>
            )
          )}
        </>
      ) : (
        filteredOptions.map((option, index) => (
          <ListboxOption key={option.value} index={index} option={option} />
        ))
      )}
    </ul>
  )
}

// ============================================================================
// LISTBOX.OPTION
// ============================================================================

export interface ListboxOptionProps extends React.HTMLAttributes<HTMLLIElement> {
  /** Unique key for the option (required for manual options) */
  uKey?: string
  /** Option data (auto-provided when using options prop) */
  option?: ListboxOptionData
  /** Index in the list (auto-provided for data options, auto-registered for manual) */
  index?: number
  /** Disabled state */
  disabled?: boolean
}

function ListboxOption({
  className,
  children,
  uKey,
  option,
  index: providedIndex,
  disabled: propDisabled,
  ...props
}: ListboxOptionProps) {
  const {
    checkmark,
    checkbox,
    multiple,
    disabled: listboxDisabled,
    focusedIndex,
    isKeyboardNav,
    firstEnabledIndex,
    isSelected,
    handleSelect,
    handleKeyDown,
    setFocusedIndex,
    setIsKeyboardNav,
    registerOption,
    optionRefs,
  } = useListboxContext()

  // Support both auto-generated (option prop) and manual (uKey + children)
  const optionDisabled = option?.disabled ?? propDisabled ?? false

  // For manual options without index, register and get an index
  // Use state instead of ref to avoid accessing refs during render
  const [registeredIndex, setRegisteredIndex] = React.useState<number | null>(null)
  if (providedIndex === undefined && registeredIndex === null) {
    const newIndex = registerOption(optionDisabled)
    setRegisteredIndex(newIndex)
  }
  const index = providedIndex ?? registeredIndex ?? 0

  const optionValue = option?.value ?? uKey ?? ""
  const optionLabel = option?.label ?? (typeof children === "string" ? children : "")
  const optionCheckboxId = React.useId()

  const selected = isSelected(optionValue)
  const isFocusedOption = focusedIndex === index
  // Match WexMultiSelect: ring only for keyboard; mouse uses inset bg via className below
  const showRing = isKeyboardNav && isFocusedOption
  
  // Roving tabindex logic:
  // - If this option is focused, it should be tabbable
  // - If no option is focused (focusedIndex === -1) and this is the first enabled option, make it tabbable
  // - Otherwise, not tabbable
  const isFirstEnabled = index === firstEnabledIndex
  const noOptionFocused = focusedIndex === -1
  const shouldBeTabbable = isFocusedOption || (noOptionFocused && isFirstEnabled)

  // Register ref for focus management
  // Ref callbacks are stable by nature, so useCallback is not needed
  const optionRef = (node: HTMLLIElement | null) => {
    if (node) {
      optionRefs.current.set(index, node)
    } else {
      optionRefs.current.delete(index)
    }
  }

  // Handle mouse click - reset keyboard nav mode
  const handleClick = React.useCallback(() => {
    setIsKeyboardNav(false)
    handleSelect(optionValue, optionDisabled)
  }, [handleSelect, optionValue, optionDisabled, setIsKeyboardNav])

  // Handle focus - detect if from keyboard (tab) using :focus-visible
  const handleFocus = React.useCallback((e: React.FocusEvent<HTMLLIElement>) => {
    setFocusedIndex(index)
    // Check if focus is visible (keyboard navigation) using :focus-visible
    // This works because browsers apply :focus-visible when focus comes from keyboard
    if (e.target.matches(':focus-visible')) {
      setIsKeyboardNav(true)
    }
  }, [index, setFocusedIndex, setIsKeyboardNav])

  return (
    <li
      ref={optionRef}
      id={`listbox-option-${index}`}
      role="option"
      aria-selected={selected}
      aria-disabled={optionDisabled}
      data-index={index}
      data-slot="listbox-option"
      // Roving tabindex: focused option (or first option if none focused) is tabbable
      tabIndex={listboxDisabled ? -1 : shouldBeTabbable ? 0 : -1}
      className={cn(
        listboxOptionVariants({
          selected,
          focused: showRing,
          disabled: optionDisabled,
        }),
        isFocusedOption && !isKeyboardNav && !selected && "bg-wex-multiselect-item-focus-bg/50",
        isFocusedOption && !isKeyboardNav && selected && "bg-wex-multiselect-item-selected-bg/25",
        className
      )}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      onFocus={handleFocus}
      onMouseEnter={() => {
        setFocusedIndex(index)
        setIsKeyboardNav(false)
      }}
      {...props}
    >
      {/* Checkbox for multiple selection (aligned with WexMultiSelect) */}
      {checkbox && multiple && (
        <WexCheckbox
          id={optionCheckboxId}
          className="shrink-0"
          checked={selected}
          disabled={listboxDisabled || optionDisabled}
          onClick={(e) => e.stopPropagation()}
          onCheckedChange={() => handleSelect(optionValue, optionDisabled)}
        />
      )}

      {/* Option label */}
      <span className={cn("flex-1", checkbox && multiple && "pointer-events-none select-none")}>
        {children ?? optionLabel}
      </span>

      {/* Checkmark for single selection */}
      {checkmark && selected && !checkbox && (
        <Check className="h-4 w-4 shrink-0" />
      )}
    </li>
  )
}

// ============================================================================
// LISTBOX.GROUP
// ============================================================================

export interface ListboxGroupProps extends React.HTMLAttributes<HTMLLIElement> {
  /** Group label */
  label: string
}

function ListboxGroup({
  className,
  children,
  label,
  ...props
}: ListboxGroupProps) {
  return (
    <li role="presentation" data-slot="listbox-group" {...props}>
      <div
        className={cn(
          "px-3 py-1.5 text-xs font-semibold text-wex-multiselect-group-heading-fg",
          className
        )}
      >
        {label}
      </div>
      <ul role="group" aria-label={label}>
        {children}
      </ul>
    </li>
  )
}

// ============================================================================
// LISTBOX.EMPTY
// ============================================================================

export type ListboxEmptyProps = React.HTMLAttributes<HTMLDivElement>

function ListboxEmpty({ className, children, ...props }: ListboxEmptyProps) {
  const { filteredOptions } = useListboxContext()

  if (filteredOptions.length > 0) return null

  return (
    <div
      data-slot="listbox-empty"
      className={cn("px-3 py-2 text-center text-sm text-wex-multiselect-empty-fg", className)}
      {...props}
    >
      {children ?? "No options found"}
    </div>
  )
}

// ============================================================================
// WEX COMPOUND COMPONENT EXPORT
// ============================================================================

// WEX wrapper with wex-listbox class
const WexListboxRoot = ({
  className,
  ...props
}: ListboxRootProps & { className?: string }) => (
  <ListboxRoot
    className={cn("wex-listbox", className)}
    {...props}
  />
);
WexListboxRoot.displayName = "WexListbox";

// Re-export the compound component with Wex prefix
export const WexListbox = Object.assign(WexListboxRoot, {
  Header: ListboxHeader,
  Filter: ListboxFilter,
  SelectAll: ListboxSelectAll,
  Options: ListboxOptions,
  Option: ListboxOption,
  Group: ListboxGroup,
  Empty: ListboxEmpty,
})

// Export base components for advanced usage
export {
  ListboxRoot,
  ListboxHeader,
  ListboxFilter,
  ListboxSelectAll,
  ListboxOptions,
  ListboxOption,
  ListboxGroup,
  ListboxEmpty,
}

