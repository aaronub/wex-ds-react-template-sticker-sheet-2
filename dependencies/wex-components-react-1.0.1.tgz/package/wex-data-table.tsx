import * as React from "react"
import {
  type Column,
  type ColumnDef,
  type ColumnFiltersState,
  type Row,
  type SortingState,
  type Table as TanStackTable,
  type VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import {
  ArrowDown,
  ArrowUp,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ChevronsUpDown,
  MoreHorizontal,
  Settings2,
} from "lucide-react"

import { fuzzyTextMatches } from "./lib/fuzzyStringMatch"
import { cn } from "./lib/utils"
import { WexButton } from "./wex-button"
import { WexCheckbox } from "./wex-checkbox"
import { WexDropdownMenu } from "./wex-dropdown-menu"
import { WexInput } from "./wex-input"
import { WexSelect } from "./wex-select"
import { WexTable } from "./wex-table"

function resolveColumnDefId<TData, TValue>(
  col: ColumnDef<TData, TValue>
): string | undefined {
  if (col.id) return col.id
  if ("accessorKey" in col && typeof col.accessorKey === "string") {
    return col.accessorKey
  }
  return undefined
}

export interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[]
  data: TData[]
  searchKey?: string
  searchPlaceholder?: string
  enableRowSelection?: boolean
  enableColumnVisibility?: boolean
  enablePagination?: boolean
  enableSorting?: boolean
  enableFiltering?: boolean
  pageSize?: number
  /** Options in the "Rows per page" control. Defaults to 10–50 in steps of 10. */
  pageSizeOptions?: number[]
  /**
   * When `searchKey` is set, use typo-tolerant matching (substring + Levenshtein)
   * instead of exact substring-only filtering. Default: true.
   */
  enableFuzzySearch?: boolean
  className?: string
}

function DataTable<TData, TValue>({
  columns,
  data,
  searchKey,
  searchPlaceholder = "Filter...",
  enableColumnVisibility = true,
  enablePagination = true,
  enableFiltering = true,
  enableRowSelection = false,
  pageSize = 10,
  pageSizeOptions = [10, 20, 30, 40, 50],
  enableFuzzySearch = true,
  className,
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({})
  const [rowSelection, setRowSelection] = React.useState({})

  // Automatically add checkbox column if row selection is enabled
  const columnsWithSelection = React.useMemo(() => {
    if (!enableRowSelection) {
      return columns
    }

    // Check if a select column already exists
    const hasSelectColumn = columns.some((col) => col.id === "select")
    if (hasSelectColumn) {
      return columns
    }

    // Prepend checkbox column
    const selectColumn: ColumnDef<TData, TValue> = {
      id: "select",
      header: ({ table }) => (
        <WexCheckbox
          checked={
            table.getIsAllPageRowsSelected() ||
            (table.getIsSomePageRowsSelected() && "indeterminate")
          }
          onCheckedChange={(value: boolean) => table.toggleAllPageRowsSelected(!!value)}
          aria-label="Select all"
        />
      ),
      cell: ({ row }) => (
        <WexCheckbox
          checked={row.getIsSelected()}
          onCheckedChange={(value: boolean) => row.toggleSelected(!!value)}
          aria-label="Select row"
        />
      ),
      enableSorting: false,
      enableHiding: false,
    }

    return [selectColumn, ...columns]
  }, [columns, enableRowSelection])

  const columnsForTable = React.useMemo(() => {
    if (!searchKey || !enableFiltering || !enableFuzzySearch) {
      return columnsWithSelection
    }

    return columnsWithSelection.map((col) => {
      if (resolveColumnDefId(col) !== searchKey) return col
      return {
        ...col,
        filterFn: (row: Row<TData>, columnId: string, filterValue: unknown) =>
          fuzzyTextMatches(row.getValue(columnId), filterValue),
      }
    })
  }, [columnsWithSelection, searchKey, enableFiltering, enableFuzzySearch])

  // eslint-disable-next-line react-hooks/incompatible-library
  const table = useReactTable({
    data,
    columns: columnsForTable,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: enableRowSelection ? setRowSelection : undefined,
    enableRowSelection: enableRowSelection,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      ...(enableRowSelection && { rowSelection }),
    },
    initialState: {
      pagination: {
        pageSize,
      },
    },
  })

  return (
    <div className={cn("space-y-4", className)}>
      {(enableFiltering || enableColumnVisibility) && (
        <div className="flex items-center gap-2">
          {enableFiltering && searchKey && (
            <WexInput
              placeholder={searchPlaceholder}
              value={
                (table.getColumn(searchKey)?.getFilterValue() as string) ?? ""
              }
              onChange={(event) =>
                table.getColumn(searchKey)?.setFilterValue(event.target.value)
              }
              className="max-w-sm"
            />
          )}
          {enableColumnVisibility && (
            <DataTableViewOptions table={table} />
          )}
        </div>
      )}
      <div className="overflow-hidden rounded-md border">
        <WexTable>
          <WexTable.Header>
            {table.getHeaderGroups().map((headerGroup) => (
              <WexTable.Row key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <WexTable.Head key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </WexTable.Head>
                  )
                })}
              </WexTable.Row>
            ))}
          </WexTable.Header>
          <WexTable.Body>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <WexTable.Row
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                >
                  {row.getVisibleCells().map((cell) => (
                    <WexTable.Cell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </WexTable.Cell>
                  ))}
                </WexTable.Row>
              ))
            ) : (
              <WexTable.Row>
                <WexTable.Cell
                  colSpan={columnsWithSelection.length}
                  className="h-24 text-center"
                >
                  No results.
                </WexTable.Cell>
              </WexTable.Row>
            )}
          </WexTable.Body>
        </WexTable>
      </div>
      {enablePagination && (
        <DataTablePagination pageSizeOptions={pageSizeOptions} table={table} />
      )}
    </div>
  )
}

DataTable.displayName = "DataTable"

interface DataTableColumnHeaderProps<TData, TValue>
  extends React.HTMLAttributes<HTMLDivElement> {
  column: Column<TData, TValue>
  title: string
}

function DataTableColumnHeader<TData, TValue>({
  column,
  title,
  className,
}: DataTableColumnHeaderProps<TData, TValue>) {
  if (!column.getCanSort()) {
    return <div className={cn(className)}>{title}</div>
  }

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <WexButton
        variant="ghost"
        size="sm"
        className="-ml-3 h-8"
        aria-label={`Sort column ${title}`}
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
      >
        <span>{title}</span>
        {column.getIsSorted() === "desc" ? (
          <ArrowDown className="ml-2 h-4 w-4" />
        ) : column.getIsSorted() === "asc" ? (
          <ArrowUp className="ml-2 h-4 w-4" />
        ) : (
          <ChevronsUpDown className="ml-2 h-4 w-4" />
        )}
      </WexButton>
    </div>
  )
}

DataTableColumnHeader.displayName = "DataTableColumnHeader"

interface DataTableViewOptionsProps<TData> {
  table: TanStackTable<TData>
}

function DataTableViewOptions<TData>({
  table,
}: DataTableViewOptionsProps<TData>) {
  return (
    <WexDropdownMenu>
      <WexDropdownMenu.Trigger asChild>
        <WexButton variant="outline" size="sm" className="ml-auto h-8" aria-label="Toggle column visibility">
          <Settings2 className="mr-2 h-4 w-4" />
          View
        </WexButton>
      </WexDropdownMenu.Trigger>
      <WexDropdownMenu.Content align="end" className="w-[150px]">
        <WexDropdownMenu.Label>Toggle columns</WexDropdownMenu.Label>
        <WexDropdownMenu.Separator />
        {table
          .getAllColumns()
          .filter(
            (column) =>
              typeof column.accessorFn !== "undefined" && column.getCanHide()
          )
          .map((column) => {
            return (
              <WexDropdownMenu.CheckboxItem
                key={column.id}
                className="capitalize"
                checked={column.getIsVisible()}
                onCheckedChange={(value: boolean | "indeterminate") =>
                  column.toggleVisibility(!!value)}
              >
                {column.id}
              </WexDropdownMenu.CheckboxItem>
            )
          })}
      </WexDropdownMenu.Content>
    </WexDropdownMenu>
  )
}

DataTableViewOptions.displayName = "DataTableViewOptions"

interface DataTablePaginationProps<TData> {
  table: TanStackTable<TData>
  pageSizeOptions?: number[]
}

function DataTablePagination<TData>({
  table,
  pageSizeOptions = [10, 20, 30, 40, 50],
}: DataTablePaginationProps<TData>) {
  return (
    <div className="flex items-center justify-between px-2">
      <div className="text-wex-datatable-info-fg flex-1 text-sm">
        {table.getFilteredSelectedRowModel().rows.length} of{" "}
        {table.getFilteredRowModel().rows.length} row(s) selected.
      </div>
      <div className="flex items-center space-x-6 lg:space-x-8">
        <div className="flex items-center space-x-2">
          <p className="text-sm font-medium">Rows per page</p>
          <WexSelect
            value={`${table.getState().pagination.pageSize}`}
            onValueChange={(value) => {
              table.setPageSize(Number(value))
            }}
          >
            <WexSelect.Trigger className="h-8 w-[70px]" aria-label="Select rows per page">
              <WexSelect.Value placeholder={String(table.getState().pagination.pageSize)} />
            </WexSelect.Trigger>
            <WexSelect.Content side="top">
              {pageSizeOptions.map((ps) => (
                <WexSelect.Item key={ps} value={`${ps}`}>
                  {ps}
                </WexSelect.Item>
              ))}
            </WexSelect.Content>
          </WexSelect>
        </div>
        <div className="flex w-[100px] items-center justify-center text-sm font-medium">
          Page {table.getState().pagination.pageIndex + 1} of{" "}
          {table.getPageCount()}
        </div>
        <div className="flex items-center space-x-2">
          <WexButton
            variant="outline"
            iconOnly
            size="sm"
            className="hidden lg:flex"
            onClick={() => table.setPageIndex(0)}
            disabled={!table.getCanPreviousPage()}
          >
            <span className="sr-only">Go to first page</span>
            <ChevronsLeft className="h-4 w-4" />
          </WexButton>
          <WexButton
            variant="outline"
            iconOnly
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <span className="sr-only">Go to previous page</span>
            <ChevronLeft className="h-4 w-4" />
          </WexButton>
          <WexButton
            variant="outline"
            iconOnly
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            <span className="sr-only">Go to next page</span>
            <ChevronRight className="h-4 w-4" />
          </WexButton>
          <WexButton
            variant="outline"
            iconOnly
            size="sm"
            className="hidden lg:flex"
            onClick={() => table.setPageIndex(table.getPageCount() - 1)}
            disabled={!table.getCanNextPage()}
          >
            <span className="sr-only">Go to last page</span>
            <ChevronsRight className="h-4 w-4" />
          </WexButton>
        </div>
      </div>
    </div>
  )
}

DataTablePagination.displayName = "DataTablePagination"

interface DataTableRowActionsProps {
  children: React.ReactNode
}

function DataTableRowActions({ children }: DataTableRowActionsProps) {
  return (
    <WexDropdownMenu>
      <WexDropdownMenu.Trigger asChild>
        <WexButton variant="ghost" className="h-8 w-8 p-0">
          <span className="sr-only">Open menu</span>
          <MoreHorizontal className="h-4 w-4" />
        </WexButton>
      </WexDropdownMenu.Trigger>
      <WexDropdownMenu.Content align="end">{children}</WexDropdownMenu.Content>
    </WexDropdownMenu>
  )
}

DataTableRowActions.displayName = "DataTableRowActions"

/**
 * WexDataTable - WEX Design System Data Table Component
 *
 * Advanced table component with sorting, filtering, pagination, and column visibility.
 * Built on top of @tanstack/react-table.
 *
 * @example
 * const columns: ColumnDef<Data>[] = [
 *   {
 *     accessorKey: "name",
 *     header: ({ column }) => (
 *       <WexDataTable.ColumnHeader column={column} title="Name" />
 *     ),
 *   },
 * ];
 *
 * <WexDataTable columns={columns} data={data} searchKey="name" />
 */

export function WexDataTable<TData, TValue>({
  className,
  ...props
}: DataTableProps<TData, TValue> & { className?: string }) {
  return (
    <div className={cn("wex-data-table", className)}>
      <DataTable {...props} />
    </div>
  )
}

// WEX customizations are applied via CSS classes in the data-table component
// The toolbar, filter inputs, and row hover states use wex-datatable-* tokens
export const WexDataTableColumnHeader = DataTableColumnHeader
export const WexDataTablePagination = DataTablePagination
export const WexDataTableViewOptions = DataTableViewOptions
export const WexDataTableRowActions = DataTableRowActions
