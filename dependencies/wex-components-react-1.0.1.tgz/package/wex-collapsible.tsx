import * as React from "react";
import {
  Collapsible as CollapsibleRoot,
  CollapsibleTrigger,
  CollapsibleContent,
} from "./shadcn/collapsible";
import { cn } from "./lib/utils";

/** Divides stacked direct children with Border / Default / Tertiary (no gap). */
const collapsibleStackDividers =
  "[&>*+*]:border-t [&>*+*]:border-solid [&>*+*]:border-[hsl(var(--wex-border-default-tertiary))]";

/** 52px (3.25rem at 16px root): aligns rows with trigger. Root skips Content slot so collapse height still animates. */
const collapsibleRowMinHeight =
  "[&>*:not([data-slot=collapsible-content])]:min-h-[3.25rem] [&>*:not([data-slot=collapsible-content])]:flex [&>*:not([data-slot=collapsible-content])]:items-center";

/** Rows inside expanded content match the same minimum row height. */
const collapsibleContentRowMinHeight =
  "[&>*]:min-h-[3.25rem] [&>*]:flex [&>*]:items-center";

/**
 * WexCollapsible - WEX Design System Collapsible Component
 *
 * Expandable/collapsible content section.
 * Root uses the same chrome as WexAccordion: --wex-border-default-tertiary and
 * --wex-radius-controls-large. Root stacks direct children in a column with
 * tertiary borders between rows. `Content` applies the same stacking to its direct
 * children so nested sections divide cleanly without extra border utilities.
 * Rows outside `Content` and rows inside `Content` use a minimum height of 3.25rem (52px at 16px root).
 * The content slot is excluded from root min-height so collapse still animates.
 * Uses namespace pattern: WexCollapsible.Trigger, WexCollapsible.Content
 *
 * @example
 * <WexCollapsible>
 *   <WexCollapsible.Trigger>Toggle</WexCollapsible.Trigger>
 *   <WexCollapsible.Content>
 *     Hidden content revealed on toggle
 *   </WexCollapsible.Content>
 * </WexCollapsible>
 */

const WexCollapsibleRoot = React.forwardRef<
  React.ElementRef<typeof CollapsibleRoot>,
  React.ComponentPropsWithoutRef<typeof CollapsibleRoot>
>(({ className, ...props }, ref) => (
  <CollapsibleRoot
    ref={ref}
    className={cn(
      "wex-collapsible flex flex-col overflow-hidden rounded-[var(--wex-radius-controls-large)] border border-solid border-[hsl(var(--wex-border-default-tertiary))]",
      collapsibleStackDividers,
      collapsibleRowMinHeight,
      className
    )}
    {...props}
  />
));
WexCollapsibleRoot.displayName = "WexCollapsible";

const WexCollapsibleContent = React.forwardRef<
  React.ElementRef<typeof CollapsibleContent>,
  React.ComponentPropsWithoutRef<typeof CollapsibleContent>
>(({ className, ...props }, ref) => (
  <CollapsibleContent
    ref={ref}
    className={cn(
      "flex min-h-0 flex-col",
      collapsibleStackDividers,
      collapsibleContentRowMinHeight,
      className
    )}
    {...props}
  />
));
WexCollapsibleContent.displayName = "WexCollapsible.Content";

export const WexCollapsible = Object.assign(WexCollapsibleRoot, {
  Trigger: CollapsibleTrigger,
  Content: WexCollapsibleContent,
});

