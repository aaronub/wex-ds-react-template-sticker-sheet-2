# @wex/components-react

WEX Design System React components - theme-agnostic UI components built on Radix UI and shadcn/ui primitives.

## Upstream shadcn snapshot

Vendored primitives under **`shadcn/`** are refreshed in the design-system repo using a **pinned** [shadcn CLI](https://ui.shadcn.com/) version. The authoritative metadata ships with this package:

| Field | Meaning |
|--------|--------|
| **`shadcnCliVersion`** | npm CLI version used to add/refresh primitives (pinned, not “whatever is latest” on each install). |
| **`registryStyle`** | Registry preset (e.g. New York) aligned with Tailwind v4 in this package. |
| **`generatedAt`** | Last refresh date, **m/d/yy** (e.g. `4/13/26`) — no leading zeros on month/day; yy is two digits. |

**Machine-readable:** After `npm install`, open **`node_modules/@wex/components-react/SHADCN_UI_SOURCE.json`**. Your app does not run the shadcn CLI for normal consumption—only WEX maintainers bump the pin and refresh `shadcn/` when upgrading upstream.

### Cursor / AI assistants (optional)

This package ships a **Cursor rule** you can use in consuming repos:

- **Published path:** `node_modules/@wex/components-react/.cursor/rules/wex-components-react.mdc`

**Cursor does not always load rules from `node_modules` automatically.** Copy that file into your app’s **`.cursor/rules/`** (or merge its contents into your project rules) so assistants apply the same import, CSS, peer-dependency, and bundler guidance as this README. If rules conflict with team defaults, scope or trim sections—this file is aimed at **`@wex/components-react`** usage.

## Architecture

WEX components wrap shadcn/ui components, which are built on Radix UI primitives. This layered approach means:

- **Radix UI** provides accessibility, keyboard navigation, and ARIA attributes
- **shadcn/ui** provides styled components with Tailwind CSS (vendored under **`shadcn/`** in this package; refresh via the shadcn CLI from `packages/wex-components-react`)
- **WEX components** add WEX-specific branding, props, and features

Inside the package, Wex modules prefer **relative imports to other Wex components** where a wrapper exists, and use **`@/shadcn/...`** only for primitives that do not have a Wex sibling (see "Configure the `@` path alias" below).

**Important:** Primitives ship inside this package at **`shadcn/*.tsx`** (flat; no `ui` subfolder). WEX wrappers at the package root import them via **`./shadcn/...`** or **`@/shadcn/...`**. Consuming apps must map **`@/shadcn/*`** to the installed package’s `shadcn` folder (see below).

## Installation

### 1. Install the package

```bash
npm install @wex/components-react
```

Installing **`@wex/components-react`** pulls in **`@wex/design-tokens`**, **`radix-ui`**, **`@radix-ui/react-*`**, **`react-hook-form`**, and the rest of the Radix/shadcn stack as **normal `dependencies`** of this package—you do **not** need a separate install step for those in a typical app.

**Peers (your app must still provide):** **`react`**, **`react-dom`**, and **`tailwindcss`** (for your build), declared as `peerDependencies` so a single shared React/Tailwind instance is used.

**Avoid duplicate stacks:** Do not add a second direct dependency on **`@wex/design-tokens`** or duplicate **`@radix-ui/*` / `radix-ui`** at conflicting versions, or you may get two copies in `node_modules` and subtle bugs. Prefer the versions that come with `@wex/components-react`; use **`overrides`** only if you must align versions across the tree.

**Monorepo / `file:`-linked installs:** If you link **`@wex/components-react`** from a local path, npm may nest **`@wex/design-tokens`** under that package. Some teams still add a direct **`file:`** (or registry) dependency on **`@wex/design-tokens`** at the app root so **`@import "@wex/design-tokens/..."`** in CSS resolves without extra Vite aliases. Keep versions aligned with the range used by your **`@wex/components-react`** release.

### 2. Do not copy shadcn into the app

WEX components use **vendored** primitives under **`node_modules/@wex/components-react/shadcn/`**. Do **not** run **`npx shadcn add`** into your app for normal use.

**Maintainers** refresh primitives by running the shadcn CLI **inside** `packages/wex/components-react` in the design-system repo only.

**Contributors (monorepo):** Run **`npm install` from the design-system repo root** so React resolves once. A standalone **`node_modules` inside this package** (from running `npm install` only here) can duplicate React and break tests.

### 3. Configure the `@` path alias

#### What it is (and what it is not)

The only WEX packages you install from npm are **`@wex/components-react`** and **`@wex/design-tokens`**. **`@` is not a package**—it does not appear in `dependencies`, and nothing is published to a registry under that name.

It is a **path alias**: you declare it in **TypeScript** (`compilerOptions.paths`) and mirror it in your **bundler**. An import such as `@/shadcn/button` must resolve to **`node_modules/@wex/components-react/shadcn/button.tsx`** (or your monorepo path to the same file).

#### How it is used

`@wex/components-react` ships **WEX wrappers** and **vendored shadcn files** under **`shadcn/`**. Your bundler resolves **`@/shadcn/...`** to **`node_modules/@wex/components-react/shadcn/...`** when you add the path mapping below.

#### Why this pattern

- **Radix and tokens** are bundled as dependencies of `@wex/components-react`; align with the versions in that release if you add anything Radix-related yourself.
- **Resolution is explicit** — the alias points at a single “host root” per app or per MFE package, so builds do not depend on whatever `@/` happens to mean elsewhere in the repo.
- **Monorepo-safe** — each package (e.g. `packages/my-mfe`) can set `@` to that package’s `src` without colliding with `@components`, `@/`, or other team conventions.
- **Naming** — `@/*` reads as “the host application’s tree,” which avoids implying another WEX-scoped npm package next to `@wex/components-react` and `@wex/design-tokens`.

**Critical:** `@wex/components-react` imports shadcn/ui files using the **`@`** prefix (for example `@/shadcn/button`). This is separate from your app’s own `@/*` or `@components/*` aliases, so it works in monorepos and micro-frontends where `@` might mean something else.

Map **`@/shadcn/*`** to the primitives inside the installed package:

| Context | `compilerOptions.paths` | Vite `resolve.alias` |
|---------|-------------------------|----------------------|
| Typical app | `"@/shadcn/*": ["./node_modules/@wex/components-react/shadcn/*"]` | Same target as `path.resolve` to that `shadcn` folder |
| Monorepo / linked package | Point `@/shadcn/*` at the workspace copy of `packages/wex-components-react/shadcn/*` |

#### TypeScript

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}
```

#### Vite

```typescript
import path from 'path';

export default {
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
};
```

**Note:** You only need this **one** `@` mapping to the folder that contains `components/` and `lib/`. Separate bundler aliases for `@/components`, `@/shadcn`, or `@/lib` are redundant—they are the same subpaths under `@`.

**Forms:** Build forms with **WexField**, inputs, and **`react-hook-form`** (a **dependency** of this package: `useForm`, `FormProvider`, `Controller`). Vendored **`shadcn/form.tsx`** is available for the classic shadcn + RHF pattern if you need it. For Zod or **`@hookform/resolvers`**, add those in **your** app.

**Migration:** If you previously configured only `@/*` for WEX, add the `@` mapping above. Your application code can keep using `@/` for its own imports; WEX no longer relies on that alias.

### 4. Import Theme CSS

In your main entry file (e.g., `main.tsx` or `index.tsx`):

```tsx
// Import the WEX theme (required for components to be styled)
import '@wex/design-tokens/css';

// Your app
import App from './App';
```

**Bundler note:** If `@wex/design-tokens` is listed in `dependencies` and installed, the import above resolves via the package **`exports`** field—no extra Vite or webpack configuration. Only ad hoc monorepo setups (sibling clone without an install, or similar) need a manual `resolve.alias` to the tokens package root; that is not required for typical consumers.

### 5. Configure Tailwind

```typescript
// tailwind.config.ts
import type { Config } from 'tailwindcss';
import wexComponentsPreset from '@wex/components-react/tailwind-preset';
import wexDesignTokensPreset from '@wex/design-tokens/tailwind-preset';

export default {
  presets: [wexDesignTokensPreset, wexComponentsPreset],
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
    // Include the component library source for Tailwind to scan
    './node_modules/@wex/components-react/**/*.{ts,tsx}',
  ],
} satisfies Config;
```

### 6. Use Components

```tsx
import { WexButton } from '@wex/components-react/wex-button';
import { WexInput } from '@wex/components-react/wex-input';
import { WexCard } from '@wex/components-react/wex-card';
import { WexDialog } from '@wex/components-react/wex-dialog';

function MyForm() {
  return (
    <WexCard>
      <WexCard.Header>
        <WexCard.Title>Contact Form</WexCard.Title>
      </WexCard.Header>
      <WexCard.Content>
        <WexInput placeholder="Enter your name" />
        <WexButton intent="primary">Submit</WexButton>
      </WexCard.Content>
    </WexCard>
  );
}
```

## How It Works

### Import Resolution Flow

1. **WEX components** import from **`./shadcn/...`** or **`@/shadcn/*`**
   - Example: `import { Button } from "@/shadcn/button"`
2. **Your bundler resolves** `@/shadcn/*` → **`@wex/components-react/shadcn/*`**
3. **Primitives** import **`radix-ui`**, **`@radix-ui/*`**, and other packages listed as **dependencies** of `@wex/components-react`
4. **Everything builds together** in your application

**The complete dependency chain:**
- `@wex/components-react` → imports from → `@/shadcn/*` (shadcn components)
- Those files → import from → `@radix-ui/*` (Radix primitives, auto-installed)
- `@radix-ui/*` → provides → accessibility, keyboard navigation, ARIA attributes

### Path alias configuration

**In this monorepo (development):** root `tsconfig` / Vite map `@/shadcn/*` → `packages/wex-components-react/shadcn/*`; the package’s own `tsconfig` maps `@/*` → `.` so `@/shadcn/button` resolves inside the package.

**In consuming applications:** add the **`@/shadcn/*`** → **`node_modules/@wex/components-react/shadcn/*`** mapping in `tsconfig` and Vite (see table above).

This architecture gives you:
- ✅ Vendored primitives in a single **`shadcn/`** folder (flat; no `ui` segment)
- ✅ WEX wrappers as **`wex-*.tsx`** at the package root
- ✅ WEX branding and features on top

## Component Categories

### Form Components
- `WexInput` - Text input field
- `WexTextarea` - Multi-line text input
- `WexCheckbox` - Checkbox control
- `WexSwitch` - Toggle switch
- `WexSlider` - Range slider
- `WexRadioGroup` - Radio button group
- `WexSelect` - Dropdown select
- `WexCombobox` - Searchable select with autocomplete
- `WexDatePicker` - Date selection
- `WexCalendar` - Calendar display
- `WexInputOTP` - One-time password input
- `WexInputGroup` - Input with addons
- `WexField` - Form field wrapper with label/error

### Button Components
- `WexButton` - Primary action button with intents (primary, secondary, destructive, success, info, warning, help, contrast, ghost, outline, link)
- `WexButtonGroup` - Group of related buttons
- `WexToggle` - Toggle button
- `WexToggleGroup` - Group of toggle buttons

### Overlay Components
- `WexDialog` - Modal dialog
- `WexAlertDialog` - Confirmation dialog
- `WexSheet` - Side panel overlay
- `WexDrawer` - Bottom/side drawer
- `WexPopover` - Floating content
- `WexTooltip` - Hover tooltip
- `WexHoverCard` - Rich hover content

### Menu Components
- `WexDropdownMenu` - Dropdown menu
- `WexContextMenu` - Right-click menu
- `WexMenubar` - Application menubar
- `WexNavigationMenu` - Navigation links
- `WexCommand` - Command palette

### Layout Components
- `WexCard` - Content container
- `WexTable` - Data table
- `WexDataTable` - Advanced data table with sorting/filtering
- `WexTabs` - Tabbed content
- `WexAccordion` - Collapsible sections
- `WexSeparator` - Visual divider
- `WexScrollArea` - Scrollable container
- `WexResizable` - Resizable panels
- `WexAspectRatio` - Fixed aspect ratio container
- `WexCollapsible` - Collapsible content
- `WexSidebar` - Navigation sidebar

### Navigation Components
- `WexBreadcrumb` - Breadcrumb navigation
- `WexPagination` - Page navigation

### Display Components
- `WexAvatar` - User avatar
- `WexBadge` - Status badge
- `WexAlert` - Alert message
- `WexProgress` - Progress indicator
- `WexSkeleton` - Loading placeholder
- `WexSpinner` - Loading spinner
- `WexCarousel` - Image carousel
- `WexEmpty` - Empty state
- `WexItem` - List item
- `WexKbd` - Keyboard shortcut display

### Feedback Components
- `WexToast` - Toast container
- `wexToast` - Toast notification function

### Data Visualization
- `WexChart` - Chart component (wraps Recharts)

## Requirements

### Required Setup

1. **Primitives**: Shipped inside **`@wex/components-react/shadcn/`**; refresh via shadcn CLI from `packages/wex-components-react` when upgrading.
2. **Path alias**: Map **`@/shadcn/*`** to the package’s **`shadcn`** folder (see above).
3. **Radix / tokens**: Pulled in **transitively** with `@wex/components-react`; avoid duplicating them at conflicting versions (see Installation).
4. **Theme**: Import `@wex/design-tokens` CSS / theme entry as documented (tokens are a dependency of this package).

### Why This Architecture?

- **Fewer install mistakes**: Radix and tokens ship with the component package.
- **Vendored shadcn**: Primitives live under **`shadcn/`** in this package; consumers map **`@/shadcn/*`** instead of copying `components/ui`.
- **Shared React/Tailwind**: Peers keep a single React and a single Tailwind toolchain in the app.

## Theme Requirement

**Important:** Components are theme-agnostic and require a theme package to be styled.

Without importing a theme:
- Components will render with browser defaults
- Colors, spacing, and typography will be unstyled
- CSS variables like `--wex-primary` will be undefined

### Using the WEX Theme

```tsx
import '@wex/design-tokens/css';
```

### Creating a Custom Theme (White-Label)

1. Copy the `@wex/design-tokens` package
2. Rename to your brand (e.g., `@acme/design-tokens`)
3. Modify `tokens.css` with your brand colors
4. Components automatically use your new theme

## Peer Dependencies

This package requires:
- `react` ^18.0.0 or ^19.0.0
- `react-dom` ^18.0.0 or ^19.0.0
- `tailwindcss` ^3.4.0

## TypeScript Support

Full TypeScript support with exported types:

```tsx
import { WexButton, type WexButtonProps } from '@wex/components-react/wex-button';

const MyButton: React.FC<WexButtonProps> = (props) => (
  <WexButton {...props} />
);
```

## License

UNLICENSED - Internal WEX use only.

