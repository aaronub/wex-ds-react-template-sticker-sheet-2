import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "./lib/utils";

/**
 * WexInput - WEX Design System Input Component
 *
 * Text input field for forms with PrimeNG-style variants.
 * Uses WEX sizing tokens for accessible touch targets.
 *
 * @example
 * // Basic
 * <WexInput placeholder="Enter text" />
 * 
 * // Sizes: same as WexButton (md 2.5 rem, lg 3 rem, xl 3.5 rem). Default is md.
 * <WexInput size="md" placeholder="md" />
 * <WexInput size="xl" placeholder="xl" />
 * 
 * // Filled variant
 * <WexInput variant="filled" placeholder="Filled input" />
 * 
 * // With icons
 * <WexInput leftIcon={<Search className="h-4 w-4" />} placeholder="Search..." />
 * <WexInput rightIcon={<Mail className="h-4 w-4" />} placeholder="Email" />
 * // When using leftIcon/rightIcon, `className` is applied to the outer wrapper so width
 * // constraints (e.g. max-w-sm) include the icons; the input still fills that wrapper.
 * 
 * // Invalid state
 * <WexInput invalid placeholder="Invalid input" />
 */

// Helper to check if a ReactNode is an interactive element (button)
const isInteractiveElement = (node: React.ReactNode): boolean => {
  if (!React.isValidElement(node)) return false;
  const elementType = node.type;
  if (typeof elementType === "string") {
    return elementType === "button";
  }
  if (typeof elementType === "function") {
    const displayName = (elementType as React.ComponentType & { displayName?: string })?.displayName;
    return displayName === "button" || displayName === "Button";
  }
  return false;
};

const wexInputVariants = cva(
  [
    // Layout
    "flex w-full px-3 py-2 text-sm shadow-sm transition-colors",
    // Layer 3 tokens - text
    "text-wex-input-fg",
    // Layer 3 tokens - placeholder
    "placeholder:text-wex-input-placeholder",
    // Focus ring
    "focus-visible:outline-none focus-visible:ring-1",
    // Disabled states
    "disabled:cursor-not-allowed",
    "disabled:bg-wex-input-disabled-bg",
    "disabled:text-wex-input-disabled-fg",
    "disabled:border-wex-input-disabled-border",
    "disabled:opacity-[var(--wex-component-input-disabled-opacity)]",
    // File input
    "file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-wex-input-fg",
  ],
  {
    variants: {
      variant: {
        default: [
          "bg-wex-input-bg",
          "border border-wex-input-border",
          "hover:border-wex-input-border-hover",
          "focus-visible:border-wex-input-border-focus",
          "focus-visible:ring-wex-input-focus-ring",
        ].join(" "),
        filled: [
          "bg-wex-input-filled-bg",
          "border border-transparent",
          "hover:bg-wex-input-filled-hover-bg",
          "focus-visible:border-wex-input-border-focus",
          "focus-visible:ring-wex-input-focus-ring",
        ].join(" "),
      },
      size: {
        md: [
          "h-10 min-h-10",
          "rounded-[var(--wex-radius-controls-medium)]",
        ].join(" "),
        lg: [
          "h-12 min-h-12",
          "rounded-[var(--wex-radius-controls-large)]",
        ].join(" "),
        xl: [
          "h-14 min-h-14",
          "rounded-[var(--wex-radius-controls-extra-large)]",
        ].join(" "),
      },
      invalid: {
        true: [
          "border-wex-input-invalid-border",
          "focus-visible:border-wex-input-invalid-border",
          "focus-visible:ring-wex-input-invalid-focus-ring",
        ].join(" "),
        false: "",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
      invalid: false,
    },
  }
);

export interface WexInputProps
  extends Omit<React.ComponentProps<"input">, "size">,
    VariantProps<typeof wexInputVariants> {
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  /**
   * Class names for the inner &lt;input&gt; element only.
   * When using `leftIcon` or `rightIcon`, `className` applies to the outer wrapper; use `inputClassName`
   * to style the field itself (e.g. float-label padding overrides from `WexFloatLabel.Input`).
   */
  inputClassName?: string;
}

const WexInput = React.forwardRef<HTMLInputElement, WexInputProps>(
  ({
    className,
    inputClassName,
    type,
    variant,
    size,
    invalid,
    leftIcon,
    rightIcon,
    ...props
  }, ref) => {
    // Check if rightIcon is interactive (button element)
    const isRightIconInteractive = rightIcon ? isInteractiveElement(rightIcon) : false;

    if (leftIcon || rightIcon) {
      return (
        <div
          className={cn(
            // `className` on the wrapper so layout/width classes (max-w-*, w-*) constrain the
            // whole control; absolutely positioned icons stay inside the same box as the input.
            // `wex-input`: stacked-field spacing when following `label.wex-label` (see components-bridge.css).
            "wex-input relative flex w-full min-w-0 items-center",
            className
          )}
        >
          {leftIcon && (
            <div className="pointer-events-none absolute left-3 top-1/2 z-10 flex -translate-y-1/2 items-center text-wex-input-placeholder">
              {leftIcon}
            </div>
          )}
          <input
            type={type}
            className={cn(
              wexInputVariants({ variant, size, invalid }),
              leftIcon && "pl-10",
              rightIcon && "pr-10",
              inputClassName
            )}
            ref={ref}
            aria-invalid={invalid || undefined}
            {...props}
          />
          {rightIcon && (
            <div
              className={cn(
                "absolute right-3 top-1/2 z-10 flex -translate-y-1/2 items-center text-wex-input-placeholder",
                !isRightIconInteractive && "pointer-events-none"
              )}
              onClick={(e) => {
                // If rightIcon is interactive, stop propagation to prevent input focus
                if (isRightIconInteractive) {
                  e.stopPropagation();
                }
              }}
            >
              {rightIcon}
            </div>
          )}
        </div>
      );
    }

    return (
      <input
        type={type}
        className={cn(
          "wex-input",
          wexInputVariants({ variant, size, invalid }),
          className,
          inputClassName
        )}
        ref={ref}
        aria-invalid={invalid || undefined}
        {...props}
      />
    );
  }
);
WexInput.displayName = "WexInput";

export { WexInput, wexInputVariants };
