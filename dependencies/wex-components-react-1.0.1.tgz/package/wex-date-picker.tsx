import * as React from "react"
import { format, parse, isValid, startOfMonth } from "date-fns"
import { Calendar as CalendarIcon } from "lucide-react"
import type { DateRange } from "react-day-picker"
import type { ComponentProps } from "react"

import { cn } from "./lib/utils"
import { WexInput, type WexInputProps } from "./wex-input"
import { WexCalendar } from "./wex-calendar"
import { WexPopover } from "./wex-popover"

/** Min width (21.5rem) matches design spec for the date field. */
const wexDatePickerFieldWidthClass = "w-full w-[21.5rem]"

/** Same scale as `WexInput`: md (default), lg, xl */
export type WexDatePickerSize = NonNullable<WexInputProps["size"]>

const wexDatePickerSizeClass: Record<WexDatePickerSize, string> = {
  md: "h-10 min-h-10 rounded-[var(--wex-radius-controls-medium)]",
  lg: "h-12 min-h-12 rounded-[var(--wex-radius-controls-large)]",
  xl: "h-14 min-h-14 rounded-[var(--wex-radius-controls-extra-large)]",
}

/** Aligned with default `WexInput` surface: regular text, border darkens on hover only; no fill change on hover */
const wexDatePickerTriggerClass =
  "inline-flex items-center justify-start gap-2 border bg-wex-input-bg px-3 text-left text-sm font-normal text-wex-input-fg " +
  "border-wex-input-border shadow-sm transition-[border-color,box-shadow] " +
  "hover:border-wex-input-border-hover hover:bg-wex-input-bg " +
  "active:bg-wex-input-bg " +
  "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-wex-input-focus-ring focus-visible:border-wex-input-border " +
  "data-[empty=true]:text-wex-input-placeholder " +
  "disabled:cursor-not-allowed disabled:border-wex-input-disabled-border disabled:bg-wex-input-disabled-bg disabled:text-wex-input-disabled-fg " +
  "disabled:opacity-[var(--wex-component-input-disabled-opacity)]"

const wexDatePickerOpenCalendarClass =
  "absolute right-1 top-1/2 z-10 inline-flex h-8 w-8 -translate-y-1/2 shrink-0 items-center justify-center rounded-[var(--wex-radius-controls-medium)] " +
  "border-0 bg-transparent text-wex-input-placeholder " +
  "hover:bg-transparent hover:text-wex-input-fg " +
  "active:bg-transparent " +
  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-wex-input-focus-ring focus-visible:ring-offset-0 " +
  "disabled:pointer-events-none disabled:opacity-50"

/** Invisible popover panel so `WexCalendar` is the only surface (radius + shadow + bg). */
const wexDatePickerCalendarPopoverContentClass =
  "w-auto min-w-0 border-0 bg-transparent p-0 shadow-none rounded-none overflow-visible"

type CalendarPassthrough = Omit<
  ComponentProps<typeof WexCalendar>,
  "mode" | "selected" | "onSelect"
>

/** If `calendarProps` omits both `month` and `onMonthChange`, sync visible month from `date` or today when empty. */
function useSyncedSingleCalendarNavigation(
  calendarProps: CalendarPassthrough | undefined,
  date: Date | undefined
) {
  const {
    month: userMonth,
    onMonthChange: userOnMonthChange,
    ...calendarRest
  } = calendarProps ?? {}

  const userControlsMonth =
    userMonth !== undefined && userOnMonthChange !== undefined

  const [calendarMonth, setCalendarMonth] = React.useState(() =>
    startOfMonth(date ?? new Date())
  )

  /** Stable key when parent `date` changes; avoids setState-in-effect (react-hooks/set-state-in-effect). */
  const dateMonthKey = date?.getTime() ?? "__empty__",
    [prevDateMonthKey, setPrevDateMonthKey] = React.useState(dateMonthKey)
  if (!userControlsMonth && dateMonthKey !== prevDateMonthKey) {
    setPrevDateMonthKey(dateMonthKey)
    setCalendarMonth(date ? startOfMonth(date) : startOfMonth(new Date()))
  }

  return {
    calendarRest,
    month: userControlsMonth ? userMonth : calendarMonth,
    onMonthChange: userControlsMonth ? userOnMonthChange : setCalendarMonth,
  }
}

export interface DatePickerProps {
  date?: Date
  onDateChange?: (date: Date | undefined) => void
  placeholder?: string
  className?: string
  disabled?: boolean
  /** Input-aligned height and radius. Default: `md` (medium, matches WexButton). */
  size?: WexDatePickerSize
  /**
   * Forwarded to the embedded `WexCalendar` (e.g. `captionLayout`, `fromYear`,
   * `disabled` matchers); `mode`, `selected`, and `onSelect` are controlled by the picker.
   * Pass **both** `month` and `onMonthChange` only if you manage the visible month yourself;
   * otherwise the picker keeps the caption on the selected date’s month/year, or on today when empty.
   */
  calendarProps?: CalendarPassthrough
}

export interface DatePickerRangeProps {
  date?: DateRange
  onDateChange?: (date: DateRange | undefined) => void
  placeholder?: string
  className?: string
  disabled?: boolean
  /** Input-aligned height and radius. Default: `md` (medium, matches WexButton). */
  size?: WexDatePickerSize
}

export interface DatePickerWithInputProps {
  date?: Date
  onDateChange?: (date: Date | undefined) => void
  placeholder?: string
  className?: string
  disabled?: boolean
  label?: string
  /** Input-aligned height and radius. Default: `md` (medium, matches WexButton). */
  size?: WexDatePickerSize
  calendarProps?: CalendarPassthrough
}

function DatePicker({
  date,
  onDateChange,
  placeholder = "Pick a date",
  className,
  disabled = false,
  size = "md",
  calendarProps,
}: DatePickerProps) {
  const [open, setOpen] = React.useState(false)
  const { calendarRest, month, onMonthChange } =
    useSyncedSingleCalendarNavigation(calendarProps, date)

  return (
    <WexPopover open={open} onOpenChange={setOpen}>
      <WexPopover.Trigger asChild>
        <button
          type="button"
          data-empty={!date}
          disabled={disabled}
          style={{ borderRadius: "var(--wex-component-input-radius)" }}
          className={cn(
            wexDatePickerFieldWidthClass,
            wexDatePickerTriggerClass,
            wexDatePickerSizeClass[size],
            className
          )}
        >
          {date ? format(date, "PPP") : <span>{placeholder}</span>}
          <CalendarIcon className="ml-auto h-4 w-4 shrink-0 text-wex-input-placeholder" aria-hidden="true" />
        </button>
      </WexPopover.Trigger>
      <WexPopover.Content
        className={wexDatePickerCalendarPopoverContentClass}
        align="start"
      >
        <WexCalendar
          {...calendarRest}
          mode="single"
          month={month}
          onMonthChange={onMonthChange}
          selected={date}
          onSelect={(selectedDate: Date | undefined) => {
            onDateChange?.(selectedDate)
            setOpen(false)
          }}
        />
      </WexPopover.Content>
    </WexPopover>
  )
}

DatePicker.displayName = "DatePicker"

function DatePickerRange({
  date,
  onDateChange,
  placeholder = "Pick a date range",
  className,
  disabled = false,
  size = "md",
}: DatePickerRangeProps) {
  const [open, setOpen] = React.useState(false)
  const rangeAnchor = date?.from ?? date?.to,
    anchorKey = rangeAnchor?.getTime() ?? "__empty__",
    [calendarMonth, setCalendarMonth] = React.useState(() =>
      startOfMonth(rangeAnchor ?? new Date())
    ),
    [prevAnchorKey, setPrevAnchorKey] = React.useState(anchorKey)
  if (anchorKey !== prevAnchorKey) {
    setPrevAnchorKey(anchorKey)
    setCalendarMonth(
      rangeAnchor ? startOfMonth(rangeAnchor) : startOfMonth(new Date())
    )
  }

  return (
    <WexPopover open={open} onOpenChange={setOpen}>
      <WexPopover.Trigger asChild>
        <button
          type="button"
          data-empty={!date?.from}
          disabled={disabled}
          style={{ borderRadius: "var(--wex-component-input-radius)" }}
          className={cn(
            wexDatePickerFieldWidthClass,
            wexDatePickerTriggerClass,
            wexDatePickerSizeClass[size],
            className
          )}
        >
          {date?.from ? (
            date.to ? (
              <>
                {format(date.from, "LLL dd, y")} -{" "}
                {format(date.to, "LLL dd, y")}
              </>
            ) : (
              format(date.from, "LLL dd, y")
            )
          ) : (
            <span>{placeholder}</span>
          )}
          <CalendarIcon className="ml-auto h-4 w-4 shrink-0 text-wex-input-placeholder" aria-hidden="true" />
        </button>
      </WexPopover.Trigger>
      <WexPopover.Content
        className={wexDatePickerCalendarPopoverContentClass}
        align="start"
      >
        <WexCalendar
          mode="range"
          month={calendarMonth}
          onMonthChange={setCalendarMonth}
          selected={date}
          onSelect={(range: DateRange | undefined) => {
            onDateChange?.(range)
            // Don't close automatically - only close when clicking outside
          }}
          numberOfMonths={2}
        />
      </WexPopover.Content>
    </WexPopover>
  )
}

DatePickerRange.displayName = "DatePickerRange"

function DatePickerWithInput({
  date,
  onDateChange,
  placeholder = "Select date",
  className,
  disabled = false,
  label,
  size = "md",
  calendarProps,
}: DatePickerWithInputProps) {
  const [open, setOpen] = React.useState(false)
  const { calendarRest, month, onMonthChange } =
    useSyncedSingleCalendarNavigation(calendarProps, date)
  const [inputValue, setInputValue] = React.useState(
    date ? format(date, "PPP") : ""
  )
  const inputRef = React.useRef<HTMLInputElement>(null)
  const openedFromInputRef = React.useRef(false)

  React.useEffect(() => {
    queueMicrotask(() => {
      if (date) {
        setInputValue(format(date, "PPP"))
      } else {
        setInputValue("")
      }
    })
  }, [date])

  // Ensure popover stays open when opened from input focus
  React.useEffect(() => {
    if (open && openedFromInputRef.current && inputRef.current) {
      // Ensure input maintains focus when popover is open
      const timeoutId = setTimeout(() => {
        if (inputRef.current && document.activeElement !== inputRef.current) {
          inputRef.current.focus()
        }
      }, 10)
      return () => clearTimeout(timeoutId)
    }
  }, [open])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value
    setInputValue(val)
    // Try to parse the input as a date in various formats
    let parsedDate: Date | undefined
    const formats = ["PPP", "PP", "P", "MM/dd/yyyy", "yyyy-MM-dd", "MM-dd-yyyy"]
    for (const fmt of formats) {
      try {
        const parsed = parse(val, fmt, new Date())
        if (isValid(parsed)) {
          parsedDate = parsed
          break
        }
      } catch {
        // Continue to next format
      }
    }
    if (parsedDate) {
      onDateChange?.(parsedDate)
    } else if (val === "") {
      onDateChange?.(undefined)
    }
  }

  return (
    <div className={cn("flex flex-col gap-2", wexDatePickerFieldWidthClass, className)}>
      {label && (
        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
          {label}
        </label>
      )}
      <div className="relative w-full">
        <WexPopover open={open} onOpenChange={setOpen}>
          <WexPopover.Anchor asChild>
            <div className="relative w-full">
              <WexInput
                ref={inputRef}
                value={inputValue}
                onChange={handleInputChange}
                placeholder={placeholder}
                disabled={disabled}
                size={size}
                className="w-full pr-10 focus-visible:border-wex-input-border"
                aria-label="Date input"
                onFocus={() => {
                  openedFromInputRef.current = true
                  setOpen(true)
                }}
              />
              <WexPopover.Trigger asChild>
                <button
                  type="button"
                  className={wexDatePickerOpenCalendarClass}
                  disabled={disabled}
                  aria-label="Open calendar"
                  onClick={() => {
                    openedFromInputRef.current = false
                  }}
                >
                  <CalendarIcon className="h-4 w-4" aria-hidden="true" />
                </button>
              </WexPopover.Trigger>
            </div>
          </WexPopover.Anchor>
          <WexPopover.Content
            className={wexDatePickerCalendarPopoverContentClass}
            align="start"
            side="bottom"
            sideOffset={4}
            onOpenAutoFocus={(e) => {
              // Prevent popover from stealing focus from input when opened from input focus
              if (openedFromInputRef.current && inputRef.current) {
                e.preventDefault()
                // Refocus input immediately to allow typing
                setTimeout(() => {
                  inputRef.current?.focus()
                }, 0)
              }
            }}
            onInteractOutside={(e) => {
              // Prevent closing when clicking on the input field or its container
              const target = e.target as Node
              if (inputRef.current && (inputRef.current === target || inputRef.current.contains(target))) {
                e.preventDefault()
              }
            }}
            onEscapeKeyDown={() => {
              // Allow escape to close, but refocus input if it was opened from input
              if (openedFromInputRef.current && inputRef.current) {
                openedFromInputRef.current = false
                setTimeout(() => {
                  inputRef.current?.focus()
                }, 0)
              }
            }}
            onCloseAutoFocus={() => {
              // Reset the flag when popover closes
              openedFromInputRef.current = false
            }}
          >
            <WexCalendar
              {...calendarRest}
              mode="single"
              month={month}
              onMonthChange={onMonthChange}
              selected={date}
              onSelect={(selectedDate: Date | undefined) => {
                onDateChange?.(selectedDate)
                setOpen(false)
              }}
            />
          </WexPopover.Content>
        </WexPopover>
      </div>
    </div>
  )
}

DatePickerWithInput.displayName = "DatePickerWithInput"

/**
 * WexDatePicker - WEX Design System Date Picker Component
 *
 * Date selection input combining Calendar with Popover.
 * Supports single date selection with button trigger or input field.
 * `size` matches WexInput (`md` | `lg` | `xl`), default `md`.
 *
 * @example
 * <WexDatePicker
 *   date={date}
 *   onDateChange={setDate}
 *   placeholder="Pick a date"
 *   size="md"
 * />
 *
 * // With input field
 * <WexDatePicker.WithInput
 *   date={date}
 *   onDateChange={setDate}
 *   placeholder="Enter or pick a date"
 *   size="md"
 * />
 */

const WexDatePickerRoot = React.forwardRef<
  HTMLDivElement,
  DatePickerProps
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("wex-date-picker", className)}>
    <DatePicker {...props} />
  </div>
))
WexDatePickerRoot.displayName = "WexDatePicker"

const WexDatePickerWithInput = React.forwardRef<
  HTMLDivElement,
  DatePickerWithInputProps
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("wex-date-picker", className)}>
    <DatePickerWithInput {...props} />
  </div>
))
WexDatePickerWithInput.displayName = "WexDatePicker.WithInput"

const WexDatePickerRange = React.forwardRef<
  HTMLDivElement,
  DatePickerRangeProps
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("wex-date-picker", className)}>
    <DatePickerRange {...props} />
  </div>
))
WexDatePickerRange.displayName = "WexDatePicker.Range"

export const WexDatePicker = Object.assign(WexDatePickerRoot, {
  WithInput: WexDatePickerWithInput,
  Range: WexDatePickerRange,
})
