import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "./lib/utils";
import { Loader2 } from "lucide-react";

/**
 * WexButton - WEX Design System Button Component
 *
 * The primary interactive element for triggering actions.
 * Uses WEX semantic tokens and meets WCAG 2.5.5 touch target requirements.
 *
 * **Intents** — `primary`, `destructive`, and `contrast` (there is no separate “neutral” intent).
 * **Variants** — `solid`, `outline`, `ghost`, and `link`.
 * **Sizes** — sm (2rem), md (2.5rem, default), lg (3rem), xl (3.5rem). Label text is
 * always 0.875rem; corner radius uses `--wex-component-button-radius-sm|md|lg|xl` (see design tokens).
 * **iconOnly** — square icon-only buttons use the same four size steps (aligned heights/widths).
 *
 * **Low emphasis vs disabled:** Outline and ghost styles for `intent="primary"` use muted
 * foreground and border tokens by design (lower visual weight than solid primary or
 * `intent="destructive"`). That is the intended look for secondary or supplementary actions, not
 * a substitute for the disabled state. To show unavailable actions, set `disabled` or `loading`
 * (both apply `--wex-component-button-disabled-opacity` and disabled-specific colors).
 *
 * @example
 * <WexButton intent="primary">Save Changes</WexButton>
 * <WexButton intent="destructive" variant="outline">Delete</WexButton>
 * <WexButton variant="outline" intent="primary">Cancel</WexButton>
 * <WexButton intent="primary" loading>Saving...</WexButton>
 */

const wexButtonVariants = cva(
  // Base classes - hardened with accessibility requirements
  [
    "inline-flex items-center justify-center gap-2",
    "whitespace-nowrap text-[0.875rem] font-medium",
    "transition-colors",
    // HARDENED: Focus ring - always visible on focus-visible
    "focus-visible:outline-none",
    "focus-visible:ring-[length:var(--wex-focus-ring-width)]",
    "focus-visible:ring-wex-button-primary-focus-ring",
    "focus-visible:ring-offset-[length:var(--wex-focus-ring-offset)]",
    "focus-visible:ring-offset-background",
    // Disabled state - pointer-events in base, colors per-variant
    "disabled:pointer-events-none",
    // SVG handling (icon size is set per size variant)
    "[&_svg]:pointer-events-none [&_svg]:shrink-0",
  ],
  {
    variants: {
      intent: {
        primary: "",
        destructive: "",
        contrast: "",
      },
      variant: {
        solid: "",
        outline: "bg-transparent",
        ghost: "bg-transparent border-transparent",
        link: "bg-transparent border-transparent underline-offset-4 hover:underline",
      },
      size: {
        sm: "h-8 min-h-8 px-3 gap-1.5 rounded-[var(--wex-component-button-radius-sm)] [&_svg]:size-3.5",
        md: "h-10 min-h-10 px-4 py-2 gap-2 rounded-[var(--wex-component-button-radius-md)] [&_svg]:size-4",
        lg: "h-12 min-h-12 px-5 gap-2 rounded-[var(--wex-component-button-radius-lg)] [&_svg]:size-5",
        xl: "h-14 min-h-14 px-6 gap-2.5 rounded-[var(--wex-component-button-radius-xl)] [&_svg]:size-6",
      },
      iconOnly: {
        false: "",
        true: "",
      },
      rounded: {
        true: "rounded-[var(--wex-component-button-radius-rounded)]",
        false: "",
      },
    },
    compoundVariants: [
      // ═══════════════════════════════════════════════════════════════════
      // SOLID VARIANTS (default) - filled background with intent color
      // ═══════════════════════════════════════════════════════════════════
      {
        intent: "primary",
        variant: "solid",
        class: [
          "bg-wex-button-primary-bg",
          "text-wex-button-primary-fg",
          "border-none",
          "hover:bg-wex-button-primary-hover-bg",
          "active:bg-wex-button-primary-active-bg",
          "disabled:bg-wex-button-primary-disabled-bg",
          "disabled:text-wex-button-primary-fg",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "destructive",
        variant: "solid",
        class: [
          "bg-wex-button-destructive-bg",
          "text-wex-button-destructive-fg",
          "border-none",
          "hover:bg-wex-button-destructive-hover-bg",
          "active:bg-wex-button-destructive-active-bg",
          "disabled:bg-wex-button-destructive-disabled-bg",
          "disabled:text-wex-button-destructive-disabled-fg",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "contrast",
        variant: "solid",
        class: [
          "bg-wex-button-contrast-bg",
          "text-wex-button-contrast-fg",
          "border-none",
          "hover:bg-wex-button-contrast-hover-bg",
          "active:bg-wex-button-contrast-active-bg",
          "disabled:bg-wex-button-contrast-disabled-bg",
          "disabled:text-wex-button-contrast-disabled-fg",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      // ═══════════════════════════════════════════════════════════════════
      // OUTLINE VARIANTS - transparent bg, colored border, tinted hover
      // ═══════════════════════════════════════════════════════════════════
      {
        intent: "primary",
        variant: "outline",
        class: [
          "text-wex-button-primary-outline-fg",
          "border border-wex-button-primary-outline-border",
          "hover:bg-wex-button-primary-outline-hover-bg",
          "active:bg-wex-button-primary-outline-active-bg",
          "disabled:text-wex-button-primary-outline-disabled-fg",
          "disabled:border-wex-button-primary-outline-disabled-border",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "destructive",
        variant: "outline",
        class: [
          "text-wex-button-destructive-outline-fg",
          "border border-wex-button-destructive-outline-border",
          "hover:bg-wex-button-destructive-outline-hover-bg",
          "active:bg-wex-button-destructive-outline-active-bg",
          "disabled:text-wex-button-destructive-outline-disabled-fg",
          "disabled:border-wex-button-destructive-outline-disabled-border",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "contrast",
        variant: "outline",
        class: [
          "text-wex-button-contrast-outline-fg",
          "border border-wex-button-contrast-outline-border",
          "hover:bg-wex-button-contrast-outline-hover-bg",
          "active:bg-wex-button-contrast-outline-active-bg",
          "disabled:text-wex-button-contrast-outline-disabled-fg",
          "disabled:border-wex-button-contrast-outline-disabled-border",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      // ═══════════════════════════════════════════════════════════════════
      // GHOST VARIANTS - transparent bg, intent-colored text, tinted hover
      // ═══════════════════════════════════════════════════════════════════
      {
        intent: "primary",
        variant: "ghost",
        class: [
          "text-wex-button-ghost-primary-fg",
          "hover:bg-wex-button-primary-outline-hover-bg",
          "active:bg-wex-button-primary-outline-active-bg",
          "disabled:text-wex-button-ghost-disabled-fg",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "destructive",
        variant: "ghost",
        class: [
          "text-wex-button-ghost-destructive-fg",
          "hover:bg-wex-button-destructive-outline-hover-bg",
          "active:bg-wex-button-destructive-outline-active-bg",
          "disabled:text-wex-button-ghost-disabled-fg",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "contrast",
        variant: "ghost",
        class: [
          "text-wex-button-ghost-contrast-fg",
          "hover:bg-wex-button-contrast-outline-hover-bg",
          "active:bg-wex-button-contrast-outline-active-bg",
          "disabled:text-wex-button-ghost-disabled-fg",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      // ═══════════════════════════════════════════════════════════════════
      // LINK VARIANTS - transparent bg, intent-colored text, underline on hover
      // ═══════════════════════════════════════════════════════════════════
      {
        intent: "primary",
        variant: "link",
        class: [
          "text-wex-button-link-fg",
          "hover:text-wex-button-link-hover-fg",
          "active:text-wex-button-link-active-fg",
          "disabled:text-wex-button-link-disabled-fg",
          "disabled:no-underline",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "destructive",
        variant: "link",
        class: [
          "text-wex-button-link-destructive-fg",
          "hover:text-wex-button-link-destructive-hover-fg",
          "active:text-wex-button-link-destructive-active-fg",
          "disabled:text-wex-button-link-disabled-fg",
          "disabled:no-underline",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      {
        intent: "contrast",
        variant: "link",
        class: [
          "text-wex-button-link-contrast-fg",
          "hover:text-wex-button-link-contrast-hover-fg",
          "active:text-wex-button-link-contrast-active-fg",
          "disabled:text-wex-button-link-disabled-fg",
          "disabled:no-underline",
          "disabled:opacity-[var(--wex-component-button-disabled-opacity)]",
        ].join(" "),
      },
      // Link: inline text hit area (overrides fixed heights from size variants)
      {
        variant: "link",
        size: "sm",
        class: "!h-auto min-h-0 w-auto py-0.5 px-1 gap-1.5",
      },
      {
        variant: "link",
        size: "md",
        class: "!h-auto min-h-0 w-auto py-1 px-1.5 gap-2",
      },
      {
        variant: "link",
        size: "lg",
        class: "!h-auto min-h-0 w-auto py-1.5 px-2 gap-2",
      },
      {
        variant: "link",
        size: "xl",
        class: "!h-auto min-h-0 w-auto py-2 px-2.5 gap-2.5",
      },
      // Icon-only: square control, same four heights as text buttons (not a separate size)
      {
        iconOnly: true,
        size: "sm",
        class:
          "!h-8 !min-h-8 !w-8 !min-w-8 !max-w-none shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-3.5",
      },
      {
        iconOnly: true,
        size: "md",
        class:
          "!h-10 !min-h-10 !w-10 !min-w-10 !max-w-none shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-4",
      },
      {
        iconOnly: true,
        size: "lg",
        class:
          "!h-12 !min-h-12 !w-12 !min-w-12 !max-w-none shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-5",
      },
      {
        iconOnly: true,
        size: "xl",
        class:
          "!h-14 !min-h-14 !w-14 !min-w-14 !max-w-none shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-6",
      },
      // Link + icon-only: square hit target per size, keeps link intent colors
      {
        variant: "link",
        iconOnly: true,
        size: "sm",
        class:
          "!h-8 !min-h-8 !w-8 !min-w-8 shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-3.5",
      },
      {
        variant: "link",
        iconOnly: true,
        size: "md",
        class:
          "!h-10 !min-h-10 !w-10 !min-w-10 shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-4",
      },
      {
        variant: "link",
        iconOnly: true,
        size: "lg",
        class:
          "!h-12 !min-h-12 !w-12 !min-w-12 shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-5",
      },
      {
        variant: "link",
        iconOnly: true,
        size: "xl",
        class:
          "!h-14 !min-h-14 !w-14 !min-w-14 shrink-0 !gap-0 !p-0 aspect-square [&_svg]:size-6",
      },
    ],
    defaultVariants: {
      intent: "primary",
      variant: "solid",
      size: "md",
      iconOnly: false,
      rounded: false,
    },
  }
);

export interface WexButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof wexButtonVariants> {
  asChild?: boolean;
  loading?: boolean;
}

const WexButton = React.forwardRef<HTMLButtonElement, WexButtonProps>(
  (
    {
      className,
      intent,
      variant,
      size,
      rounded,
      iconOnly = false,
      asChild = false,
      loading = false,
      disabled,
      children,
      ...props
    },
    ref
  ) => {
    const Comp = asChild ? Slot : "button";
    const isDisabled = disabled || loading;
    
    // When using asChild, Slot expects exactly ONE child element.
    // We cannot render the loading spinner alongside children when asChild is true.
    // Loading spinner is only shown for regular button mode.
    const renderChildren = () => {
      if (asChild) {
        // asChild mode: pass children directly to Slot (must be single element)
        return children;
      }
      // Regular button mode: can include loading spinner
      return (
        <>
          {loading && <Loader2 className="animate-spin" />}
          {children}
        </>
      );
    };
    
    return (
      <Comp
        className={
          "wex-button " +
          cn(wexButtonVariants({ intent, variant, size, rounded, iconOnly }), className)
        }
        ref={ref}
        disabled={isDisabled}
        aria-busy={loading}        
        {...props}
      >
        {renderChildren()}
      </Comp>
    );
  }
);
WexButton.displayName = "WexButton";

export { WexButton, wexButtonVariants };
