import * as React from "react";
import { type VariantProps } from "class-variance-authority";
import { ToggleGroup as ToggleGroupPrimitive } from "radix-ui";
import { cn } from "./lib/utils";
import { wexToggleVariants } from "./wex-toggle";

/**
 * WexToggleGroup - WEX Design System Toggle Group Component
 *
 * Set of two-state buttons for grouped toggles.
 * Uses namespace pattern: WexToggleGroup.Item
 *
 * Implemented with Radix toggle-group primitives and {@link wexToggleVariants}
 * so items match WexToggle token styling without modifying vendored shadcn files.
 * The group root uses `--wex-component-togglegroup-radius` and, for outline with flush
 * `spacing` (0), `--wex-component-togglegroup-outline-shadow`. Items always use a full
 * `border-wex-toggle-border`; when `spacing` is 0, adjacent items overlap seams with `-ml-px`.
 *
 * @example
 * <WexToggleGroup type="single">
 *   <WexToggleGroup.Item value="left" aria-label="Align left">
 *     <AlignLeft className="h-4 w-4" />
 *   </WexToggleGroup.Item>
 *   <WexToggleGroup.Item value="center" aria-label="Align center">
 *     <AlignCenter className="h-4 w-4" />
 *   </WexToggleGroup.Item>
 * </WexToggleGroup>
 */

const WexToggleGroupContext = React.createContext<
  VariantProps<typeof wexToggleVariants> & {
    spacing?: number;
  }
>({
  size: "default",
  variant: "default",
  spacing: 0,
});

const WexToggleGroupRoot = React.forwardRef<
  React.ElementRef<typeof ToggleGroupPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ToggleGroupPrimitive.Root> &
    VariantProps<typeof wexToggleVariants> & {
      spacing?: number;
    }
>(({ className, variant, size, spacing = 0, children, ...props }, ref) => {
  const contextValue = React.useMemo(
    () => ({ variant, size, spacing }),
    [variant, size, spacing]
  );

  return (
    <ToggleGroupPrimitive.Root
      ref={ref}
      data-slot="toggle-group"
      data-variant={variant}
      data-size={size}
      data-spacing={spacing}
      style={{ "--gap": spacing } as React.CSSProperties}
      className={cn(
        "group/toggle-group flex w-fit items-center gap-[--spacing(var(--gap))] rounded-[var(--wex-component-togglegroup-radius)]",
        "data-[variant=outline]:data-[spacing=0]:shadow-[var(--wex-component-togglegroup-outline-shadow)]",
        "wex-toggle-group",
        className
      )}
      {...props}
    >
      <WexToggleGroupContext.Provider value={contextValue}>
        {children}
      </WexToggleGroupContext.Provider>
    </ToggleGroupPrimitive.Root>
  );
});
WexToggleGroupRoot.displayName = "WexToggleGroup";

const WexToggleGroupItem = React.forwardRef<
  React.ElementRef<typeof ToggleGroupPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof ToggleGroupPrimitive.Item> &
    VariantProps<typeof wexToggleVariants>
>(({ className, children, variant, size, ...props }, ref) => {
  const context = React.useContext(WexToggleGroupContext);

  return (
    <ToggleGroupPrimitive.Item
      ref={ref}
      data-slot="toggle-group-item"
      data-variant={context.variant || variant}
      data-size={context.size || size}
      data-spacing={context.spacing}
      className={cn(
        wexToggleVariants({
          variant: context.variant || variant,
          size: context.size || size,
        }),
        "w-auto min-w-0 shrink-0 px-3 focus:z-10 focus-visible:z-10",
        // Every group item is bordered; flush layout overlaps 1px seams so dividers stay single-weight.
        "border border-wex-toggle-border",
        "data-[spacing=0]:rounded-none data-[spacing=0]:shadow-none data-[spacing=0]:first:rounded-l-md data-[spacing=0]:last:rounded-r-md data-[spacing=0]:not-first:-ml-px data-[spacing=0]:hover:z-20 data-[spacing=0]:data-[state=on]:z-10",
        className
      )}
      {...props}
    >
      {children}
    </ToggleGroupPrimitive.Item>
  );
});
WexToggleGroupItem.displayName = "WexToggleGroup.Item";

export const WexToggleGroup = Object.assign(WexToggleGroupRoot, {
  Item: WexToggleGroupItem,
});
