import { useTheme } from "next-themes";
import { Toaster as Sonner } from "sonner";
import { CircleCheckIcon, InfoIcon, TriangleAlertIcon, OctagonXIcon, Loader2Icon } from "lucide-react";

/**
 * WexToast - WEX Design System Toast Container Component
 *
 * Toast notification container using Sonner with WEX theming.
 * Place WexToast once at the root of your app.
 *
 * For triggering toasts, use wexToast from "./wex-toast".
 *
 * WCAG 2.2 AA Compliance:
 * - Toast messages are announced by screen readers
 * - Sufficient color contrast in light and dark modes
 * - Focus management handled by Sonner library
 *
 * Positions (ToasterProps / per-toast position):
 * - top-left, top-center, top-right
 * - bottom-left, bottom-center, bottom-right
 *
 * Default toaster position follows Sonner: bottom-right unless you override `position`.
 *
 * @example
 * // In App.tsx or layout:
 * <WexToast position="top-center" />
 */

// ============================================================================
// Base Toaster Component (from shadcn/sonner)
// ============================================================================

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme();

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      icons={{
        success: <CircleCheckIcon className="size-4" />,
        info: <InfoIcon className="size-4" />,
        warning: <TriangleAlertIcon className="size-4" />,
        error: <OctagonXIcon className="size-4" />,
        loading: <Loader2Icon className="size-4 animate-spin" />,
      }}
      toastOptions={{
        classNames: {
          toast:
            "group toast rounded-[var(--wex-component-toast-radius)] group-[.toaster]:bg-wex-toast-bg group-[.toaster]:text-wex-toast-fg group-[.toaster]:border-wex-toast-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-wex-toast-description-fg",
          actionButton:
            "group-[.toast]:bg-wex-toast-action-bg group-[.toast]:text-wex-toast-action-fg",
          cancelButton:
            "group-[.toast]:bg-wex-toast-cancel-bg group-[.toast]:text-wex-toast-cancel-fg",
        },
      }}
      {...props}
    />
  );
};

// ============================================================================
// WEX Wrappers
// ============================================================================

/**
 * Toast positions available for WexToast
 * Custom WEX type (not exported from native sonner)
 */
export type ToastPosition = 
  | "top-left" 
  | "top-center" 
  | "top-right" 
  | "bottom-left" 
  | "bottom-center" 
  | "bottom-right";

export const WexToast = Toaster;
