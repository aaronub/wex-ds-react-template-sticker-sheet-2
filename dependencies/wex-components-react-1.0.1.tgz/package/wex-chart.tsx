import * as React from "react";
import {
  ChartContainer as ChartContainerRoot,
  ChartTooltipContent as ChartTooltipContentBase,
  ChartLegend,
  ChartLegendContent as ChartLegendContentBase,
  ChartStyle,
} from "./shadcn/chart";
import type { ChartConfig } from "./shadcn/chart";
import { cn } from "./lib/utils";
import { Tooltip as RechartsTooltip, Bar } from "recharts";

/* Debug: re-enable if tooltip/cursor issues return
const WEX_CHART_TAG = "[WexChart]";
function wexChartLog(event: string, data?: Record<string, unknown>) {
  const dev =
    (typeof import.meta !== "undefined" &&
      (import.meta as ImportMeta & { env?: { DEV?: boolean } }).env?.DEV) ??
    (typeof process !== "undefined" && process.env.NODE_ENV !== "production");
  if (dev) {
    if (data !== undefined) console.log(WEX_CHART_TAG, event, data);
    else console.log(WEX_CHART_TAG, event);
  }
}
*/

/**
 * Shell: tooltip z-index, bar cursor (no gray band), axis cursor line, active series emphasis.
 * Tooltip popover styling stays on TooltipContent.
 */
const WEX_CHART_SHELL_CSS = `
  .wex-chart-container .recharts-wrapper,
  .wex-chart-container .recharts-responsive-container {
    overflow: visible !important;
  }
  /*
   * BarChart: hide the default tooltip cursor band — emphasis comes from lighter active bars only.
   * (Recharts uses a Rectangle; ChartContainer also applies fill-muted without this override.)
   */
  .wex-chart-container .recharts-rectangle.recharts-tooltip-cursor {
    fill: transparent !important;
    stroke: none !important;
    pointer-events: none !important;
  }
  /*
   * Line / Area / Composed (cartesian): vertical (or horizontal) axis cursor — Recharts renders a Curve path.
   * Uses component chart grid token so the line reads in light and dark.
   */
  .wex-chart-container path.recharts-curve.recharts-tooltip-cursor {
    fill: none !important;
    stroke: hsl(var(--wex-component-chart-grid-fg) / 0.95) !important;
    stroke-width: 1px !important;
    vector-effect: non-scaling-stroke;
    pointer-events: none !important;
  }
  .wex-chart-container .recharts-tooltip-wrapper {
    z-index: 10000 !important;
  }
  /*
   * Tooltip-active datum (bar / area / line dot): lighter tint of the series color.
   * Override via --wex-chart-active-item-brightness on the container.
   */
  .wex-chart-container {
    --wex-chart-active-item-brightness: 1.22;
  }
  .wex-chart-container g.recharts-active-bar,
  .wex-chart-container g.recharts-active-shape,
  .wex-chart-container g.recharts-active-dot {
    filter: brightness(var(--wex-chart-active-item-brightness, 1.22));
  }
`;

function resolveCursor(
  cursor: React.ComponentProps<typeof RechartsTooltip>["cursor"]
): React.ComponentProps<typeof RechartsTooltip>["cursor"] {
  if (cursor === false) return false;
  /*
   * Must not replace default with a rect fill: that breaks Line/Area (Curve vertical cursor) and
   * paints BarChart’s gray band. Recharts Tooltip default is cursor: true (per-chart geometry).
   */
  if (cursor === undefined || cursor === true) return true;
  return cursor;
}

const WexChartContainer = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    config: ChartConfig;
    children: React.ReactNode;
    /** @deprecated Pass WexChart.Tooltip content={<WexChart.TooltipContent />} in chart children instead. */
    data?: Record<string, unknown>[];
    dataKey?: string;
    labelKey?: string;
  }
>(
  (
    { className, children, config, data: _data, dataKey: _dataKey, labelKey: _labelKey, ...props },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={cn("relative min-h-0", className)}
        {...props}
      >
        <style dangerouslySetInnerHTML={{ __html: WEX_CHART_SHELL_CSS }} />
        <ChartContainerRoot
          config={config}
          className={
            "wex-chart-container flex h-full w-full min-h-0 flex-col justify-start aspect-auto"
          }
        >
          {children as React.ReactElement}
        </ChartContainerRoot>
      </div>
    );
  }
);
WexChartContainer.displayName = "WexChart.Container";

/**
 * Bar — displayName must stay `"Bar"` for Recharts layout (see findChildByType).
 * Recharts only wires tooltip `activeIndex` onto Bar when `activeBar` is truthy (see generateCategoricalChart
 * `hasActive`); default `activeBar` is false upstream, so we default to `true` so hover/tooltip highlights apply.
 * Pass `activeBar={false}` to restore stock Recharts behavior, or a custom element/object for the active shape.
 */
function WexChartBar({
  activeBar,
  ...rest
}: Omit<React.ComponentProps<typeof Bar>, "ref">) {
  return <Bar {...rest} activeBar={activeBar ?? true} />;
}
WexChartBar.displayName = "Bar";

type TooltipContentProps = React.ComponentPropsWithoutRef<
  typeof ChartTooltipContentBase
>;

const WexChartTooltipContent = React.forwardRef<
  React.ElementRef<typeof ChartTooltipContentBase>,
  TooltipContentProps
>(({ hideIndicator = true, className, ...props }, ref) => (
  <ChartTooltipContentBase
    ref={ref}
    hideIndicator={hideIndicator}
    className={cn(
      "rounded-lg border border-wex-chart-component-tooltip-border bg-wex-chart-component-tooltip-bg text-wex-chart-component-tooltip-fg shadow-xl px-2.5 py-1.5",
      /* Month/category header + body left-aligned */
      "text-left items-start justify-items-start",
      /* One row: “Value” immediately followed by the number (no space-between) */
      "[&_.flex.justify-between]:justify-start [&_.flex.justify-between]:gap-1.5 [&_.flex.justify-between]:flex-nowrap",
      className
    )}
    {...props}
  />
));
WexChartTooltipContent.displayName = "WexChart.TooltipContent";

function WexChartLegendContent(
  props: React.ComponentPropsWithoutRef<typeof ChartLegendContentBase>
) {
  const { className, ...rest } = props;
  return (
    <ChartLegendContentBase
      className={cn(
        "[&>svg]:text-wex-chart-axis-fg [&_span]:text-wex-chart-fg",
        className
      )}
      {...rest}
    />
  );
}
WexChartLegendContent.displayName = "WexChart.LegendContent";

type RechartsTooltipProps = React.ComponentProps<typeof RechartsTooltip>;

/**
 * Wraps Recharts Tooltip: default axis cursor (vertical line on line charts; transparent bar band) +
 * clones `content` with Recharts-injected props when provided.
 */
const WexChartTooltip = ({
  cursor,
  content: userContent,
  ...rest
}: RechartsTooltipProps) => {
  const resolvedCursor = resolveCursor(cursor);

  const loggedContent = React.useCallback(
    (tooltipProps: Record<string, unknown> & {
      active?: boolean;
      payload?: unknown[];
      label?: unknown;
      coordinate?: { x?: number; y?: number };
    }) => {
      if (React.isValidElement(userContent)) {
        return React.cloneElement(
          userContent,
          tooltipProps as React.Attributes & Partial<TooltipContentProps>
        );
      }
      if (typeof userContent === "function") {
        return (userContent as unknown as (p: unknown) => React.ReactNode)(
          tooltipProps
        );
      }
      return null;
    },
    [userContent]
  );

  if (userContent === undefined) {
    return (
      <RechartsTooltip
        cursor={resolvedCursor}
        allowEscapeViewBox={{ x: true, y: true }}
        {...rest}
      />
    );
  }

  return (
    <RechartsTooltip
      cursor={resolvedCursor}
      allowEscapeViewBox={{ x: true, y: true }}
      {...rest}
      content={loggedContent as unknown as RechartsTooltipProps["content"]}
    />
  );
};
/**
 * MUST be `"Tooltip"` — Recharts finds the chart's <Tooltip /> via `child.type.displayName`
 * (see findAllByType in recharts). Any other name and the chart never wires mouse events or
 * renders the tooltip layer (`hasTooltipWrapper` stays false).
 */
WexChartTooltip.displayName = "Tooltip";

export const WexChart = {
  Container: WexChartContainer,
  Bar: WexChartBar,
  Tooltip: WexChartTooltip,
  TooltipContent: WexChartTooltipContent,
  Legend: ChartLegend,
  LegendContent: WexChartLegendContent,
  Style: ChartStyle,
};

export type { ChartConfig as WexChartConfig };
