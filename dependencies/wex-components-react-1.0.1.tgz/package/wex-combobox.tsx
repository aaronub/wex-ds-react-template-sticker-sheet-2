import * as React from "react";
import { Combobox as ComboboxPrimitive } from "@base-ui/react";
import {
  Combobox as ComboboxRoot,
  ComboboxList,
  ComboboxItem,
  ComboboxEmpty,
  ComboboxTrigger,
} from "./shadcn/combobox";
import { WexInputGroup, type WexInputGroupSize } from "./wex-input-group";
import { cn } from "./lib/utils";

export type { WexInputGroupSize } from "./wex-input-group";

type WexComboboxContentProps = ComboboxPrimitive.Popup.Props &
  Pick<
    ComboboxPrimitive.Positioner.Props,
    "side" | "align" | "sideOffset" | "alignOffset" | "anchor"
  >;

/**
 * Radix `Dialog` / sheet panels use `z-50` (~Tailwind 50). `zIndex` is inline so it survives Base
 * UI’s popper style merge and isn’t purged in consumer builds.
 */
const WEX_COMBOBOX_FLOAT_Z = 200_000;

/**
 * Same structure as shadcn `ComboboxContent` — do **not** set `container={document.body}`: that
 * breaks selection inside a Radix sheet (list is “outside” the dialog subtree for outside-press).
 * Use a very high `zIndex` on `Positioner` and `Popup` so the list paints and hit-tests over in-sheet
 * content (e.g. token cascade accordions, z-50 shell).
 */
function WexComboboxContent({
  className,
  side = "bottom",
  sideOffset = 6,
  align = "start",
  alignOffset = 0,
  anchor,
  style: popupStyle,
  ...props
}: WexComboboxContentProps) {
  const popupZStyle: React.ComponentProps<typeof ComboboxPrimitive.Popup>["style"] = {
    ...popupStyle,
    zIndex: WEX_COMBOBOX_FLOAT_Z,
  };

  return (
    <ComboboxPrimitive.Portal>
      <ComboboxPrimitive.Positioner
        side={side}
        sideOffset={sideOffset}
        align={align}
        alignOffset={alignOffset}
        anchor={anchor}
        className="pointer-events-auto isolate"
        style={{ zIndex: WEX_COMBOBOX_FLOAT_Z }}
      >
        <ComboboxPrimitive.Popup
          data-slot="combobox-content"
          data-chips={!!anchor}
          className={cn(
            "pointer-events-auto group/combobox-content relative max-h-96 w-(--anchor-width) max-w-(--available-width) min-w-[calc(var(--anchor-width)+--spacing(7))] origin-(--transform-origin) overflow-hidden duration-100 data-[chips=true]:min-w-(--anchor-width) data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 *:data-[slot=input-group]:m-1 *:data-[slot=input-group]:mb-0 *:data-[slot=input-group]:h-8 *:data-[slot=input-group]:border-input/30 *:data-[slot=input-group]:bg-input/30 *:data-[slot=input-group]:shadow-none data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95",
            className
          )}
          style={popupZStyle}
          {...props}
        />
      </ComboboxPrimitive.Positioner>
    </ComboboxPrimitive.Portal>
  );
}

export interface ComboboxOption {
  value: string;
  label: string;
}

/** List panel — matches WexSelect.Content (wex-select). */
const comboboxContentWexClassName = cn(
  "overflow-hidden",
  // Match trigger width (shadcn default min-w is wider than anchor)
  "w-(--anchor-width) min-w-(--anchor-width) max-w-(--anchor-width)",
  "rounded-[var(--wex-radius-controls-large)] border border-solid border-border",
  "bg-wex-select-content-bg text-wex-select-content-fg",
  "shadow-[var(--wex-shadow-medium)]",
  "ring-0"
);

const comboboxItemWexClassName = cn(
  "text-wex-select-content-fg",
  "hover:bg-wex-multiselect-item-hover-bg/50",
  "data-highlighted:bg-wex-multiselect-item-hover-bg/50 data-highlighted:text-wex-select-content-fg"
);

const comboboxFieldGroupClass = (disabled: boolean) =>
  cn(
    "w-auto",
    "border-wex-input-border bg-wex-input-bg text-wex-input-fg shadow-sm transition-colors",
    "hover:border-wex-input-border-hover",
    "has-[[data-slot=input-group-control]:focus-visible]:border-wex-input-border-focus",
    "has-[[data-slot=input-group-control]:focus-visible]:ring-1 has-[[data-slot=input-group-control]:focus-visible]:ring-wex-input-focus-ring",
    "has-[[data-slot=input-group-control]:focus-visible]:outline-none",
    disabled && [
      "pointer-events-none",
      "border-wex-input-disabled-border bg-wex-input-disabled-bg",
      "opacity-[var(--wex-component-input-disabled-opacity)]",
    ]
  );

export interface ComboboxProps {
  options?: ComboboxOption[];
  value?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  searchPlaceholder?: string;
  emptyText?: string;
  /** Matches WexInput / WexSelect.Trigger: md (default), lg, xl */
  size?: WexInputGroupSize;
  /** Accessible name for the open-list trigger (icon-only button). */
  triggerAriaLabel?: string;
}

/**
 * WexCombobox — thin wrapper around the shadcn/ui Combobox (Base UI).
 * Passes options as `items` and uses the standard list render-prop pattern.
 */
export const WexCombobox = ({
  className,
  options = [],
  value,
  onValueChange,
  placeholder,
  disabled = false,
  searchPlaceholder,
  emptyText = "No results found.",
  size = "md",
  triggerAriaLabel = "Open options",
  ...props
}: ComboboxProps) => {
  const selectedItem =
    value === undefined || value === ""
      ? null
      : (options.find((o) => o.value === value) ?? null);

  const inputPlaceholder =
    placeholder ?? searchPlaceholder ?? "Select option...";

  // Full field (input + chevron), not the input alone — Base UI defaults anchor to inputElement,
  // which makes --anchor-width too narrow compared to the visible control.
  const fieldRef = React.useRef<HTMLDivElement>(null);

  return (
    <div className={cn("wex-combobox w-full", className)}>
      <ComboboxRoot
        items={options}
        value={selectedItem}
        onValueChange={(next) => {
          if (next == null) {
            onValueChange?.("");
            return;
          }
          onValueChange?.(next.value);
        }}
        disabled={disabled}
        isItemEqualToValue={(a, b) => a?.value === b?.value}
        {...props}
      >
        <WexInputGroup
          ref={fieldRef}
          size={size}
          className={comboboxFieldGroupClass(disabled)}
          data-disabled={disabled ? "true" : undefined}
        >
          <ComboboxPrimitive.Input
            render={
              <WexInputGroup.Input
                disabled={disabled}
                className={cn(
                  disabled &&
                    "disabled:!bg-transparent disabled:!opacity-100"
                )}
              />
            }
            placeholder={inputPlaceholder}
            disabled={disabled}
          />
          <WexInputGroup.Addon align="inline-end">
            <WexInputGroup.Button
              iconOnly
              asChild
              data-slot="input-group-button"
              className={cn(
                "group-has-data-[slot=combobox-clear]/input-group:hidden data-pressed:rounded-full data-pressed:bg-transparent",
                "hover:!bg-transparent active:!bg-transparent focus-visible:!bg-transparent"
              )}
              disabled={disabled}
            >
              <ComboboxTrigger
                aria-label={triggerAriaLabel}
                className="text-wex-input-fg/50 [&>svg]:text-inherit"
              />
            </WexInputGroup.Button>
          </WexInputGroup.Addon>
        </WexInputGroup>
        <WexComboboxContent anchor={fieldRef} className={comboboxContentWexClassName}>
          <ComboboxEmpty className="text-wex-select-content-fg">
            {emptyText}
          </ComboboxEmpty>
          <ComboboxList>
            {(item) => (
              <ComboboxItem
                key={item.value}
                value={item}
                className={comboboxItemWexClassName}
              >
                {item.label}
              </ComboboxItem>
            )}
          </ComboboxList>
        </WexComboboxContent>
      </ComboboxRoot>
    </div>
  );
};
WexCombobox.displayName = "WexCombobox";
