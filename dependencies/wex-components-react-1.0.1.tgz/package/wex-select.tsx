import * as React from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { Check, ChevronDown, ChevronUp } from "lucide-react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "./lib/utils";

/**
 * WexSelect - WEX Design System Select Component
 *
 * Dropdown selection control.
 * Uses namespace pattern: WexSelect.Trigger, WexSelect.Content, etc.
 *
 * @example
 * <WexSelect>
 *   <WexSelect.Trigger className="w-[180px]" size="md">
 *     <WexSelect.Value placeholder="Select a fruit" />
 *   </WexSelect.Trigger>
 *   <WexSelect.Content>
 *     <WexSelect.Group>
 *       <WexSelect.Label>Fruits</WexSelect.Label>
 *       <WexSelect.Item value="apple">Apple</WexSelect.Item>
 *       <WexSelect.Item value="banana">Banana</WexSelect.Item>
 *     </WexSelect.Group>
 *   </WexSelect.Content>
 * </WexSelect>
 */

// ============================================================================
// Base Select Components (from Radix/shadcn)
// ============================================================================

const Select = SelectPrimitive.Root;

const SelectGroup = SelectPrimitive.Group;

const SelectValue = SelectPrimitive.Value;

const SelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex w-full items-center justify-between gap-1 whitespace-nowrap border px-3 text-sm shadow-sm transition-colors ring-offset-background",
      "text-wex-input-fg data-[placeholder]:text-wex-input-placeholder",
      "focus-visible:outline-none focus-visible:ring-1 [&>span]:line-clamp-1",
      "disabled:cursor-not-allowed disabled:bg-wex-input-disabled-bg disabled:text-wex-input-disabled-fg disabled:border-wex-input-disabled-border disabled:opacity-[var(--wex-component-input-disabled-opacity)]",
      className
    )}
    {...props}
  >
    {children}
    <SelectPrimitive.Icon asChild>
      <ChevronDown className="h-4 w-4 opacity-50" />
    </SelectPrimitive.Icon>
  </SelectPrimitive.Trigger>
));
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;

const SelectScrollUpButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollUpButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollUpButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollUpButton
    ref={ref}
    className={cn(
      "flex cursor-default items-center justify-center py-1",
      className
    )}
    {...props}
  >
    <ChevronUp className="h-4 w-4" />
  </SelectPrimitive.ScrollUpButton>
));
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;

const SelectScrollDownButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollDownButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollDownButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollDownButton
    ref={ref}
    className={cn(
      "flex cursor-default items-center justify-center py-1",
      className
    )}
    {...props}
  >
    <ChevronDown className="h-4 w-4" />
  </SelectPrimitive.ScrollDownButton>
));
SelectScrollDownButton.displayName =
  SelectPrimitive.ScrollDownButton.displayName;

const SelectContent = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Content>
>(({ className, children, position = "popper", ...props }, ref) => (
  <SelectPrimitive.Portal>
    <SelectPrimitive.Content
      ref={ref}
      className={cn(
        "relative z-50 max-h-[--radix-select-content-available-height] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-[var(--wex-radius-controls-large)] border bg-wex-select-content-bg text-wex-select-content-fg shadow-[var(--wex-shadow-medium)] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-[--radix-select-content-transform-origin]",
        position === "popper" &&
          "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className
      )}
      position={position}
      {...props}
    >
      <SelectScrollUpButton />
      <SelectPrimitive.Viewport
        className={cn(
          "p-1",
          position === "popper" &&
            "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
        )}
      >
        {children}
      </SelectPrimitive.Viewport>
      <SelectScrollDownButton />
    </SelectPrimitive.Content>
  </SelectPrimitive.Portal>
));
SelectContent.displayName = SelectPrimitive.Content.displayName;

const SelectLabel = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Label>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold", className)}
    {...props}
  />
));
SelectLabel.displayName = SelectPrimitive.Label.displayName;

const SelectItem = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Item>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-default select-none items-center rounded-lg py-1.5 pl-2 pr-8 text-sm outline-none transition-colors",
      "text-wex-select-content-fg hover:bg-wex-multiselect-item-hover-bg/50",
      "data-[highlighted]:bg-wex-multiselect-item-hover-bg/50 data-[highlighted]:text-wex-select-content-fg",
      "data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    )}
    {...props}
  >
    <span className="absolute right-2 flex h-3.5 w-3.5 items-center justify-center">
      <SelectPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </SelectPrimitive.ItemIndicator>
    </span>
    <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
  </SelectPrimitive.Item>
));
SelectItem.displayName = SelectPrimitive.Item.displayName;

const SelectSeparator = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-wex-select-separator-bg", className)}
    {...props}
  />
));
SelectSeparator.displayName = SelectPrimitive.Separator.displayName;

// ============================================================================
// WEX Wrappers
// ============================================================================

const WexSelectRoot = Select;

const wexSelectTriggerVariants = cva(
  [
    "bg-wex-input-bg border-wex-input-border",
    "hover:border-wex-input-border-hover",
    "focus-visible:border-wex-input-border-focus focus-visible:ring-wex-input-focus-ring",
  ],
  {
    variants: {
      size: {
        md: [
          "min-h-10",
          "rounded-[var(--wex-radius-controls-medium)]",
          "py-1.5",
        ].join(" "),
        lg: [
          "min-h-12",
          "rounded-[var(--wex-radius-controls-large)]",
          "py-2",
        ].join(" "),
        xl: [
          "min-h-14",
          "rounded-[var(--wex-radius-controls-extra-large)]",
          "py-2.5",
        ].join(" "),
      },
      invalid: {
        true: [
          "border-wex-input-invalid-border",
          "focus-visible:border-wex-input-invalid-border",
          "focus-visible:ring-wex-input-invalid-focus-ring",
        ].join(" "),
        false: "",
      },
    },
    defaultVariants: {
      size: "md",
      invalid: false,
    },
  }
);

type WexSelectTriggerProps = Omit<
  React.ComponentPropsWithoutRef<typeof SelectTrigger>,
  "size"
> &
  VariantProps<typeof wexSelectTriggerVariants>;

const WexSelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectTrigger>,
  WexSelectTriggerProps
>(({ className, size, invalid, ...props }, ref) => (
  <SelectTrigger
    ref={ref}
    className={cn(
      "wex-select-trigger",
      wexSelectTriggerVariants({ size, invalid }),
      className
    )}
    aria-invalid={invalid || undefined}
    {...props}
  />
));
WexSelectTrigger.displayName = "WexSelect.Trigger";

const WexSelectContent = React.forwardRef<
  React.ElementRef<typeof SelectContent>,
  React.ComponentPropsWithoutRef<typeof SelectContent>
>(({ className, ...props }, ref) => (
  <SelectContent
    ref={ref}
    className={cn(
      "bg-wex-select-content-bg border-solid border-border text-wex-select-content-fg",
      className
    )}
    {...props}
  />
));
WexSelectContent.displayName = "WexSelect.Content";

const WexSelectItem = React.forwardRef<
  React.ElementRef<typeof SelectItem>,
  React.ComponentPropsWithoutRef<typeof SelectItem>
>((props, ref) => <SelectItem ref={ref} {...props} />);
WexSelectItem.displayName = "WexSelect.Item";

export const WexSelect = Object.assign(WexSelectRoot, {
  Group: SelectGroup,
  Value: SelectValue,
  Trigger: WexSelectTrigger,
  Content: WexSelectContent,
  Label: SelectLabel,
  Item: WexSelectItem,
  Separator: SelectSeparator,
  ScrollUpButton: SelectScrollUpButton,
  ScrollDownButton: SelectScrollDownButton,
});

export { wexSelectTriggerVariants };
