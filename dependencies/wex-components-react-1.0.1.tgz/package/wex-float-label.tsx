"use client"

import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "./lib/utils"

/**
 * WexFloatLabel - WEX Design System Floating Label Wrapper
 * 
 * A wrapper component that provides floating label functionality for any input.
 * Works with WexInputNumber, WexInput, WexTextarea, etc.
 * 
 * Uses compound component pattern like PrimeNG:
 * 
 * @example
 * // With InputNumber
 * <WexFloatLabel>
 *   <WexInputNumber value={value} onValueChange={setValue} />
 *   <WexLabel>Amount</WexLabel>
 * </WexFloatLabel>
 * 
 * // With WexInput
 * <WexFloatLabel>
 *   <WexInput value={value} onChange={e => setValue(e.target.value)} />
 *   <WexLabel>Username</WexLabel>
 * </WexFloatLabel>
 */

// ============================================================================
// Context for sharing focus/value state
// ============================================================================

/** Matches WexInput: md 2.5rem, lg 3rem, xl 3.5rem */
export type WexFloatLabelSize = "md" | "lg" | "xl"

interface FloatLabelContextValue {
  isFocused: boolean
  hasValue: boolean
  setFocused: (focused: boolean) => void
  setHasValue: (hasValue: boolean) => void
  inputId: string
  size: WexFloatLabelSize
  // For MultiSelect: track if dropdown is open
  isOpen?: boolean
  setIsOpen?: (open: boolean) => void
  // Track if input has left icon for label positioning
  hasLeftIcon?: boolean
  setHasLeftIcon?: (hasLeftIcon: boolean) => void
}

const FloatLabelContext = React.createContext<FloatLabelContextValue | null>(null)

function useFloatLabelContext() {
  const context = React.useContext(FloatLabelContext)
  if (!context) {
    throw new Error("FloatLabel components must be used within WexFloatLabel")
  }
  return context
}

// ============================================================================
// Variants
// ============================================================================

const floatLabelWrapperVariants = cva(
  // w-full + basis-full ensures proper width in both flex and non-flex containers
  "relative w-full basis-full",
  {
    variants: {
      size: {
        md: "",
        lg: "",
        xl: "",
      },
    },
    defaultVariants: {
      size: "md",
    },
  }
)

// ============================================================================
// Main Wrapper Component
// ============================================================================

export interface WexFloatLabelProps 
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof floatLabelWrapperVariants> {
  /** Size variant — same scale as WexInput (md 2.5rem, lg 3rem, xl 3.5rem) */
  size?: WexFloatLabelSize
  /** Children - should include an input and a label */
  children: React.ReactNode
}

const WexFloatLabelRoot = React.forwardRef<HTMLDivElement, WexFloatLabelProps>(
  ({ className, size = "md", children, ...props }, ref) => {
    const [isFocused, setFocused] = React.useState(false)
    const [hasValue, setHasValue] = React.useState(false)
    const inputId = React.useId()

    const [isOpen, setIsOpen] = React.useState(false)
    const [hasLeftIcon, setHasLeftIcon] = React.useState(false)
    
    const contextValue: FloatLabelContextValue = {
      isFocused,
      hasValue,
      setFocused,
      setHasValue,
      inputId,
      size,
      isOpen,
      setIsOpen,
      hasLeftIcon,
      setHasLeftIcon,
    }

    return (
      <FloatLabelContext.Provider value={contextValue}>
        <div
          ref={ref}
          className={"wex-float-label " + cn(floatLabelWrapperVariants({ size }), className)}
          {...props}
        >
          {children}
        </div>
      </FloatLabelContext.Provider>
    )
  }
)
WexFloatLabelRoot.displayName = "WexFloatLabel"

// ============================================================================
// FloatLabel.Input - Wrapper for any input component
// ============================================================================

interface FloatLabelInputProps {
  children: React.ReactElement<Record<string, unknown>>
}

function FloatLabelInput({ children }: FloatLabelInputProps) {
  const { setFocused, setHasValue, inputId, size, setIsOpen, setHasLeftIcon } = useFloatLabelContext()

  const child = React.Children.only(children) as React.ReactElement<Record<string, unknown>>
  const childProps = child.props as Record<string, unknown>
  
  // Check component type by displayName or props
  const displayName = (child.type as React.ComponentType & { displayName?: string })?.displayName
  
  // Detect if WexInput has leftIcon prop
  const isWexInput = displayName === "WexInput"
  const hasLeftIcon = isWexInput && childProps.leftIcon !== undefined && childProps.leftIcon !== null
  const hasRightIcon = isWexInput && childProps.rightIcon !== undefined && childProps.rightIcon !== null

  // Update context with left icon state
  React.useEffect(() => {
    if (setHasLeftIcon) {
      setHasLeftIcon(hasLeftIcon)
    }
  }, [hasLeftIcon, setHasLeftIcon])
  
  // WexInputNumber detection
  const isInputNumber = displayName === "WexInputNumber" || 
    childProps.showButtons !== undefined ||
    (childProps.mode === "currency" || childProps.mode === "decimal")
  
  // WexInputMask detection (has mask prop or displayName)
  const isInputMask = displayName === "WexInputMask" || 
    childProps.mask !== undefined
  
  // WexMultiSelect detection (has options prop or displayName)
  const isMultiSelect = displayName === "WexMultiSelect" ||
    childProps.options !== undefined ||
    childProps.floatLabel !== undefined

  const isWexTextarea = displayName === "WexTextarea"

  // Refs for MultiSelect - must be declared unconditionally (hooks rules)
  const currentValueRef = React.useRef<string[]>(Array.isArray(childProps.value) ? childProps.value : [])
  const isOpenRef = React.useRef<boolean>(false)

  // Height matches WexInput md/lg/xl (2.5 / 3 / 3.5 rem); padding leaves room for the label
  const regularInputSizeClasses: Record<WexFloatLabelSize, string> = {
    md: "!h-10 !min-h-10 !pt-3 !pb-0.5",
    lg: "!h-12 !min-h-12 !pt-4 !pb-1",
    xl: "!h-14 !min-h-14 !pt-5 !pb-2",
  }

  /**
   * Multi-line field: override single-line `.h-*` from FloatLabel.Input (do NOT collapse textarea to input height).
   * Moderate top padding so the floated label sits closely above typed text without a large gap; min-height keeps a multi-line silhouette.
   */
  const floatLabelTextareaSizeClasses: Record<WexFloatLabelSize, string> = {
    md: "!h-auto !min-h-[7.5rem] !resize-y !rounded-[var(--wex-radius-controls-large)] !pt-6 !pb-3 placeholder:text-transparent",
    lg: "!h-auto !min-h-[9rem] !resize-y !rounded-[var(--wex-radius-controls-large)] !pt-7 !pb-3.5 placeholder:text-transparent",
    xl: "!h-auto !min-h-[10.5rem] !resize-y !rounded-[var(--wex-radius-controls-extra-large)] !pt-8 !pb-4 placeholder:text-transparent",
  }

  // Detect initial value on mount
  const initialValue = childProps.value ?? childProps.defaultValue
  const hasInitialValue = initialValue !== undefined && initialValue !== null && initialValue !== ""
  
  // For InputNumber, check if value is a number (including 0)
  const hasInitialInputNumberValue = isInputNumber && (
    (typeof initialValue === "number" && !isNaN(initialValue)) ||
    (initialValue !== undefined && initialValue !== null && initialValue !== "")
  )
  
  // For MultiSelect, check if value array has items
  const hasInitialMultiSelectValue = isMultiSelect && Array.isArray(initialValue) && initialValue.length > 0
  
  React.useEffect(() => {
    if (hasInitialValue && !isMultiSelect && !isInputNumber) {
      setHasValue(true)
    } else if (hasInitialInputNumberValue) {
      setHasValue(true)
    } else if (hasInitialMultiSelectValue) {
      setHasValue(true)
    }
  }, [hasInitialValue, hasInitialInputNumberValue, hasInitialMultiSelectValue, isMultiSelect, isInputNumber, setHasValue])

  // Build new props
  const newProps: Record<string, unknown> = {
    id: inputId,
    onFocus: (e: React.FocusEvent) => {
      setFocused(true)
      if (typeof childProps.onFocus === 'function') {
        childProps.onFocus(e)
      }
    },
    onBlur: (e: React.FocusEvent) => {
      setFocused(false)
      if (typeof childProps.onBlur === 'function') {
        childProps.onBlur(e)
      }
    },
  }

  if (isInputNumber) {
    // For InputNumber: track value via onValueChange, don't modify styling
    // The size prop on WexInputNumber handles its own height
    newProps.onValueChange = (value: number | null) => {
      setHasValue(value !== null && value !== undefined)
      if (typeof childProps.onValueChange === 'function') {
        childProps.onValueChange(value)
      }
    }
    // Keep original className
    newProps.className = typeof childProps.className === 'string' ? childProps.className : undefined
  } else if (isInputMask) {
    // For InputMask: track value via onValueChange (string value)
    // The floatLabel prop on InputMask handles its own height
    newProps.onValueChange = (value: string, isComplete: boolean) => {
      setHasValue(value !== null && value !== undefined && value !== "")
      if (typeof childProps.onValueChange === 'function') {
        childProps.onValueChange(value, isComplete)
      }
    }
    // Keep original className
    newProps.className = typeof childProps.className === 'string' ? childProps.className : undefined
  } else if (isWexTextarea) {
    newProps.className = cn(
      typeof childProps.className === "string" ? childProps.className : undefined,
      floatLabelTextareaSizeClasses[size]
    )
    newProps.onChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const val = e.target.value
      setHasValue(val !== null && val !== undefined && val !== "")
      if (typeof childProps.onChange === "function") {
        ;(childProps.onChange as (ev: React.ChangeEvent<HTMLTextAreaElement>) => void)(e)
      }
    }
  } else if (isMultiSelect) {
    // For MultiSelect: track value via onValueChange (array value)
    // The floatLabel prop on MultiSelect handles its own height
    // Use refs to track the latest value for the onOpenChange handler
    newProps.onValueChange = (value: string[]) => {
      currentValueRef.current = value
      const hasValueNow = Array.isArray(value) && value.length > 0
      setHasValue(hasValueNow)
      // If value becomes empty and dropdown is closed, also clear focus
      if (!hasValueNow && !isOpenRef.current) {
        setFocused(false)
      }
      if (typeof childProps.onValueChange === 'function') {
        childProps.onValueChange(value)
      }
    }
    // Merge focus handlers to track focus state
    const originalOnFocus = typeof childProps.onFocus === 'function' ? childProps.onFocus : undefined
    const originalOnBlur = typeof childProps.onBlur === 'function' ? childProps.onBlur : undefined
    newProps.onFocus = (e: React.FocusEvent) => {
      setFocused(true)
      originalOnFocus?.(e)
    }
    newProps.onBlur = (e: React.FocusEvent) => {
      setFocused(false)
      originalOnBlur?.(e)
    }
    // Pass setIsOpen callback to MultiSelect so it can notify float label when dropdown opens/closes
    if (setIsOpen) {
      // Store original onOpenChange if it exists
      const originalOnOpenChange = typeof childProps.onOpenChange === 'function' ? childProps.onOpenChange : undefined
      newProps.onOpenChange = (open: boolean) => {
        isOpenRef.current = open
        setIsOpen(open)
        // When dropdown closes, check if there's a value - if not, clear focus to unfloat the label
        if (!open) {
          // Check the latest value from the ref (updated by onValueChange)
          const hasCurrentValue = Array.isArray(currentValueRef.current) && currentValueRef.current.length > 0
          if (!hasCurrentValue) {
            setFocused(false)
          }
        }
        originalOnOpenChange?.(open)
      }
    }
    // Keep original className
    newProps.className = typeof childProps.className === 'string' ? childProps.className : undefined
  } else if (isWexInput && (hasLeftIcon || hasRightIcon)) {
    /**
     * With icons, `className` is on the outer wrapper; apply float-label sizing on the inner &lt;input&gt;
     * (`inputClassName`) so padding/height align with baseline text (icons stay `top-1/2`-centered on the row).
     */
    newProps.className = typeof childProps.className === 'string' ? childProps.className : undefined
    newProps.inputClassName = cn(
      typeof childProps.inputClassName === 'string' ? childProps.inputClassName : undefined,
      regularInputSizeClasses[size]
    )
    newProps.onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value
      setHasValue(val !== null && val !== undefined && val !== '')
      if (typeof childProps.onChange === 'function') {
        ;(childProps.onChange as (ev: React.ChangeEvent<HTMLInputElement>) => void)(e)
      }
    }
  } else {
    newProps.className = cn(
      typeof childProps.className === 'string' ? childProps.className : undefined,
      regularInputSizeClasses[size]
    )
    newProps.onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value
      setHasValue(val !== null && val !== undefined && val !== '')
      if (typeof childProps.onChange === 'function') {
        ;(childProps.onChange as (ev: React.ChangeEvent<HTMLInputElement>) => void)(e)
      }
    }
  }

  // Match WexInput / InputNumber / etc. to wrapper size when child omits `size`
  const resolvedSize: WexFloatLabelSize =
    childProps.size !== undefined && childProps.size !== null
      ? (childProps.size as WexFloatLabelSize)
      : size
  if (
    isWexInput ||
    isInputNumber ||
    (isInputMask && childProps.floatLabel) ||
    (isMultiSelect && childProps.floatLabel)
  ) {
    (newProps as { size?: WexFloatLabelSize }).size = resolvedSize
  }

  return React.cloneElement(child, newProps)
}
FloatLabelInput.displayName = "WexFloatLabel.Input"

// ============================================================================
// FloatLabel.Label - The floating label
// ============================================================================

interface FloatLabelLabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  children: React.ReactNode
}

function FloatLabelLabel({ children, className, ...props }: FloatLabelLabelProps) {
  const { isFocused, hasValue, inputId, size, isOpen, hasLeftIcon } = useFloatLabelContext()
  // Float label when: focused OR has value OR (for MultiSelect) dropdown is open
  // But if dropdown closes and there's no value, unfloat
  const isFloating = hasValue || isFocused || (isOpen ?? false)

  // Size-specific positioning (aligned with input control heights)
  const sizeConfig: Record<
    WexFloatLabelSize,
    { default: string; floating: string }
  > = {
    // Default: optically center label in field (h-10 / 12 / 14); not the same row as value when focused
    md: {
      default: "top-2.5 text-sm",
      floating: "top-1 text-[10px] leading-tight",
    },
    lg: {
      default: "top-3.5 text-sm",
      floating: "top-1.5 text-[10px] leading-tight",
    },
    xl: {
      default: "top-4 text-sm",
      floating: "top-2 text-[10px] leading-tight",
    },
  }

  // Adjust left position if input has left icon (icon takes ~28px = left-3 + pl-10)
  const leftPosition = hasLeftIcon ? "left-10" : "left-3"

  return (
    <label
      htmlFor={inputId}
      className={cn(
        "absolute pointer-events-none z-10",
        leftPosition,
        "origin-top-left transition-all duration-200 ease-out",
        "text-wex-field-label-fg",
        isFloating 
          ? cn(sizeConfig[size].floating, "text-wex-field-value-fg font-medium")
          : sizeConfig[size].default,
        className
      )}
      {...props}
    >
      {children}
    </label>
  )
}
FloatLabelLabel.displayName = "WexFloatLabel.Label"

// ============================================================================
// Compound Component Export
// ============================================================================

export const WexFloatLabel = Object.assign(WexFloatLabelRoot, {
  Input: FloatLabelInput,
  Label: FloatLabelLabel,
})

export type { FloatLabelInputProps, FloatLabelLabelProps }

// ============================================================================
// Legacy: Keep the original self-contained FloatLabel for backwards compat
// ============================================================================

const floatLabelInputVariants = cva(
  [
    // Base input styles
    "peer w-full px-3 text-sm shadow-sm transition-colors",
    // Layer 3 tokens
    "text-wex-input-fg",
    "bg-wex-input-bg",
    "border border-wex-input-border",
    // Hover
    "hover:border-wex-input-border-hover",
    // Focus
    "focus:outline-none focus:border-wex-input-border-focus focus:ring-1 focus:ring-wex-input-focus-ring",
    // Disabled
    "disabled:cursor-not-allowed disabled:opacity-50",
    "disabled:bg-wex-input-disabled-bg disabled:text-wex-input-disabled-fg",
    // Placeholder - hidden but needed for :placeholder-shown
    "placeholder:text-transparent",
  ],
  {
    variants: {
      size: {
        md: [
          "h-10 min-h-10 pt-3 pb-0.5",
          "rounded-[var(--wex-radius-controls-medium)]",
        ].join(" "),
        lg: [
          "h-12 min-h-12 pt-4 pb-1",
          "rounded-[var(--wex-radius-controls-large)]",
        ].join(" "),
        xl: [
          "h-14 min-h-14 pt-5 pb-2",
          "rounded-[var(--wex-radius-controls-extra-large)]",
        ].join(" "),
      },
      invalid: {
        true: [
          "border-wex-input-invalid-border",
          "focus:border-wex-input-invalid-border",
          "focus:ring-wex-input-invalid-focus-ring",
        ].join(" "),
        false: "",
      },
    },
    defaultVariants: {
      size: "md",
      invalid: false,
    },
  }
)

const floatLabelLabelVariants = cva(
  [
    // Positioning
    "absolute pointer-events-none",
    "origin-top-left transition-all duration-200 ease-out",
    // Default state (inside input)
    "text-wex-floatlabel-label-fg",
    // Floated state - applied on focus OR when input has value
    "peer-focus:text-wex-floatlabel-label-focus-fg",
    "peer-focus:scale-75 peer-focus:-translate-y-2.5",
    "peer-[:not(:placeholder-shown)]:scale-75 peer-[:not(:placeholder-shown)]:-translate-y-2.5",
    // When both focused AND has value, use focus color
    "peer-focus:peer-[:not(:placeholder-shown)]:text-wex-floatlabel-label-focus-fg",
  ],
  {
      variants: {
        size: {
          md: "top-2.5 text-sm peer-focus:text-[10px] peer-focus:leading-tight peer-[:not(:placeholder-shown)]:text-[10px] peer-[:not(:placeholder-shown)]:leading-tight",
          lg: "top-3.5 text-sm peer-focus:text-[10px] peer-focus:leading-tight peer-[:not(:placeholder-shown)]:text-[10px] peer-[:not(:placeholder-shown)]:leading-tight",
          xl: "top-4 text-sm peer-focus:text-[10px] peer-focus:leading-tight peer-[:not(:placeholder-shown)]:text-[10px] peer-[:not(:placeholder-shown)]:leading-tight",
        },
      },
    defaultVariants: {
      size: "md",
    },
  }
)

export interface FloatLabelProps
  extends Omit<React.ComponentProps<"input">, "size" | "placeholder">,
    VariantProps<typeof floatLabelWrapperVariants> {
  /** The floating label text */
  label: string
  /** Size variant — same as WexInput (md 2.5rem, lg 3rem, xl 3.5rem) */
  size?: WexFloatLabelSize
  /** Invalid state for form validation */
  invalid?: boolean
  /** Container className */
  containerClassName?: string
  /** Icon to display on the left side of the input */
  leftIcon?: React.ReactNode
  /** Icon to display on the right side of the input */
  rightIcon?: React.ReactNode
}

/**
 * FloatLabel - Floating label input component (legacy self-contained version)
 * 
 * Provides a Material Design / PrimeNG-style floating label that animates
 * from inside the input to above it when focused or containing a value.
 * 
 * Uses CSS peer selectors for pure-CSS state detection:
 * - placeholder=" " enables :placeholder-shown detection
 * - peer-focus: detects focus state
 * - peer-[:not(:placeholder-shown)]: detects filled state
 */
const FloatLabel = React.forwardRef<HTMLInputElement, FloatLabelProps>(
  ({ className, containerClassName, label, size, invalid, id, leftIcon, rightIcon, ...props }, ref) => {
    // Generate a unique id if not provided
    const generatedId = React.useId()
    const inputId = id || generatedId

    return (
      <div className={cn(floatLabelWrapperVariants({ size }), containerClassName)}>
        {/* Left icon */}
        {leftIcon && (
          <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center pointer-events-none text-wex-input-placeholder z-10">
            {leftIcon}
          </div>
        )}
        
        <input
          id={inputId}
          ref={ref}
          placeholder=" " // Required for :placeholder-shown detection
          aria-invalid={invalid || undefined}
          className={cn(
            floatLabelInputVariants({ size, invalid }),
            leftIcon && "pl-10",
            rightIcon && "pr-10",
            className
          )}
          {...props}
        />
        
        <label
          htmlFor={inputId}
          className={cn(
            floatLabelLabelVariants({ size }),
            leftIcon ? "left-10" : "left-3"
          )}
        >
          {label}
        </label>
        
        {/* Right icon */}
        {rightIcon && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center pointer-events-none text-wex-input-placeholder z-10">
            {rightIcon}
          </div>
        )}
      </div>
    )
  }
)
FloatLabel.displayName = "FloatLabel"

// Export as WexFloatLabelInput for backwards compatibility
export const WexFloatLabelInput = FloatLabel
export type { FloatLabelProps as WexFloatLabelInputProps }
