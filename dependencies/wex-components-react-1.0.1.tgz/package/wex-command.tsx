import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { SearchIcon } from "lucide-react";
import {
  Command as CommandRoot,
  CommandList,
  CommandEmpty as CommandEmptyBase,
  CommandGroup,
  CommandItem,
  CommandShortcut,
  CommandSeparator as CommandSeparatorBase,
} from "./shadcn/command";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./shadcn/dialog";
import { cn } from "./lib/utils";

/**
 * Command palette primitives (cmdk) with command bridge tokens on the surfaced pieces.
 *
 * Uses namespace pattern: WexCommand.Input, WexCommand.List, WexCommand.Dialog, etc.
 *
 * @example
 * <WexCommand className="rounded-lg border max-w-md">
 *   <WexCommand.Input placeholder="Search…" />
 *   <WexCommand.List>
 *     <WexCommand.Empty>No results.</WexCommand.Empty>
 *     <WexCommand.Group heading="Suggestions">
 *       <WexCommand.Item>Open</WexCommand.Item>
 *     </WexCommand.Group>
 *   </WexCommand.List>
 * </WexCommand>
 */

/** Sizing tweaks applied when embedding the palette inside DialogContent */
const COMMAND_DIALOG_EMBED_CLASSNAME =
  "**:data-[slot=command-input-wrapper]:h-12 [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-wex-command-group-heading [&_[cmdk-group]]:px-2 [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5";

const WexCommandRoot = React.forwardRef<
  React.ElementRef<typeof CommandRoot>,
  React.ComponentPropsWithoutRef<typeof CommandRoot>
>(({ className, ...props }, ref) => (
  <CommandRoot
    ref={ref}
    className={cn(
      "border border-wex-command-border bg-wex-command-bg text-wex-command-fg",
      className
    )}
    {...props}
  />
));
WexCommandRoot.displayName = "WexCommand";

const WexCommandInput = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Input>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Input>
>(({ className, ...props }, ref) => (
  <div
    data-slot="command-input-wrapper"
    className={cn(
      "flex h-9 items-center gap-2 border-b border-wex-command-border bg-wex-command-input-bg px-3"
    )}
  >
    <SearchIcon
      aria-hidden="true"
      className="size-4 shrink-0 opacity-50 text-wex-command-input-placeholder"
    />
    <CommandPrimitive.Input
      ref={ref}
      data-slot="command-input"
      className={cn(
        "flex h-10 w-full rounded-md bg-transparent py-3 text-sm text-wex-command-fg outline-hidden placeholder:text-wex-command-input-placeholder disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    />
  </div>
));
WexCommandInput.displayName = "WexCommand.Input";

const WexCommandEmpty = React.forwardRef<
  React.ElementRef<typeof CommandEmptyBase>,
  React.ComponentPropsWithoutRef<typeof CommandEmptyBase>
>(({ className, ...props }, ref) => (
  <CommandEmptyBase
    ref={ref}
    className={cn("py-6 text-center text-sm text-wex-command-empty-fg", className)}
    {...props}
  />
));
WexCommandEmpty.displayName = "WexCommand.Empty";

const WexCommandGroup = ({
  className,
  ...props
}: React.ComponentProps<typeof CommandGroup>) => (
  <CommandGroup
    className={cn(
      "overflow-hidden p-1 text-wex-command-fg [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-wex-command-group-heading",
      className
    )}
    {...props}
  />
);
WexCommandGroup.displayName = "WexCommand.Group";

const WexCommandSeparator = ({
  className,
  ...props
}: React.ComponentProps<typeof CommandSeparatorBase>) => (
  <CommandSeparatorBase
    className={cn("-mx-1 h-px bg-wex-command-separator", className)}
    {...props}
  />
);
WexCommandSeparator.displayName = "WexCommand.Separator";

const WexCommandItem = ({ className, ...props }: React.ComponentProps<typeof CommandItem>) => (
  <CommandItem
    className={cn(
      "relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm text-wex-command-fg outline-hidden select-none data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50 data-[selected=true]:bg-wex-command-item-selected-bg data-[selected=true]:text-wex-command-fg hover:bg-wex-command-item-hover-bg [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 [&_svg:not([class*='text-'])]:text-wex-command-group-heading",
      className
    )}
    {...props}
  />
);
WexCommandItem.displayName = "WexCommand.Item";

const WexCommandShortcut = ({
  className,
  ...props
}: React.ComponentProps<typeof CommandShortcut>) => (
  <CommandShortcut
    className={cn("ml-auto text-xs tracking-widest text-wex-command-group-heading", className)}
    {...props}
  />
);
WexCommandShortcut.displayName = "WexCommand.Shortcut";

const WexCommandDialog = ({
  title = "Command Palette",
  description = "Search for a command to run...",
  children,
  className,
  showCloseButton = true,
  ...props
}: React.ComponentProps<typeof Dialog> & {
  title?: string;
  description?: string;
  className?: string;
  showCloseButton?: boolean;
}) => (
  <Dialog {...props}>
    <DialogHeader className="sr-only">
      <DialogTitle>{title}</DialogTitle>
      <DialogDescription>{description}</DialogDescription>
    </DialogHeader>
    <DialogContent
      className={cn("overflow-hidden p-0", className)}
      showCloseButton={showCloseButton}
    >
      <WexCommandRoot className={cn(COMMAND_DIALOG_EMBED_CLASSNAME, "rounded-lg border-none")}>
        {children}
      </WexCommandRoot>
    </DialogContent>
  </Dialog>
);
WexCommandDialog.displayName = "WexCommand.Dialog";

export const WexCommand = Object.assign(WexCommandRoot, {
  Dialog: WexCommandDialog,
  Input: WexCommandInput,
  List: CommandList,
  Empty: WexCommandEmpty,
  Group: WexCommandGroup,
  Item: WexCommandItem,
  Shortcut: WexCommandShortcut,
  Separator: WexCommandSeparator,
});
