/**
 * Fuzzy text matching for DataTable column filters: substring match first,
 * then ordered-character (subsequence / “type‑ahead abbreviation”) matching,
 * then typo-tolerant word and sliding-window checks (Levenshtein).
 */

function normalize(s: string): string {
  return s.trim().toLowerCase()
}

function rowMinCosts(
  a: string,
  b: string,
  i: number,
  prev: readonly number[],
  cur: number[]
): number {
  cur[0] = i
  let rowMin = cur[0]
  for (let j = 1; j <= b.length; j++) {
    const cost = a[i - 1] === b[j - 1] ? 0 : 1
    cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
    if (cur[j] < rowMin) rowMin = cur[j]
  }
  return rowMin
}

/** Levenshtein distance with early exit when result would exceed `max`. */
function levenshteinWithin(a: string, b: string, max: number): number {
  if (a === b) return 0
  if (a.length === 0) return Math.min(b.length, max + 1)
  if (b.length === 0) return Math.min(a.length, max + 1)
  if (Math.abs(a.length - b.length) > max) return max + 1

  const m = a.length
  let prev = new Array<number>(b.length + 1)
  let cur = new Array<number>(b.length + 1)
  for (let j = 0; j <= b.length; j++) prev[j] = j

  for (let i = 1; i <= m; i++) {
    if (rowMinCosts(a, b, i, prev, cur) > max) {
      return max + 1
    }
    const nextPrev = cur
    cur = prev
    prev = nextPrev
  }

  const d = prev[b.length]
  return d > max ? max + 1 : d
}

function maxAllowedTypos(minLen: number): number {
  if (minLen <= 5) return 1
  if (minLen <= 12) return 2
  return Math.min(3, Math.floor(minLen / 4))
}

/**
 * Characters of `query` occur in order somewhere in `haystack` but need not be adjacent
 * ("kn" matches "ken99@yahoo.com").
 */
function matchesSubsequence(query: string, haystack: string): boolean {
  if (query.length === 0) return true
  let qi = 0
  for (let hi = 0; hi < haystack.length && qi < query.length; hi++) {
    if (haystack[hi] === query[qi]) qi++
  }
  return qi === query.length
}

const WINDOW_SCAN_MAX_CELL = 280

function asSearchString(value: unknown): string {
  if (typeof value === "string") return value
  if (value === undefined || value === null) return ""
  if (
    typeof value === "number" ||
    typeof value === "boolean" ||
    typeof value === "bigint"
  ) {
    return String(value)
  }
  return ""
}

function matchWordsAgainstQuery(h: string, q: string, maxTypo: number): boolean {
  const words = h.split(/\s+/).filter((w) => w.length > 0)
  for (const w of words) {
    if (w.includes(q)) return true
    if (
      levenshteinWithin(w, q, maxTypo) <= maxTypo &&
      Math.abs(w.length - q.length) <= maxTypo + 2
    ) {
      return true
    }
  }
  return false
}

function matchSlidingWindows(
  scan: string,
  q: string,
  maxTypo: number
): boolean {
  const ql = q.length
  for (
    let windowLen = Math.max(1, ql - maxTypo);
    windowLen <= ql + maxTypo;
    windowLen++
  ) {
    for (let i = 0; i + windowLen <= scan.length; i++) {
      const slice = scan.slice(i, i + windowLen)
      if (levenshteinWithin(slice, q, maxTypo) <= maxTypo) return true
    }
  }
  return false
}

/** True when `haystack` should match filter `query` (typos allowed). */
export function fuzzyTextMatches(haystack: unknown, query: unknown): boolean {
  const q = normalize(asSearchString(query))
  if (!q) return true

  const h = normalize(asSearchString(haystack))
  if (!h) return false
  if (h.includes(q)) return true

  /** Abbreviations: query letters in order (“kn” → “ken…”, “k99” → “ken99…”). */
  if (matchesSubsequence(q, h)) return true

  const maxTypo = maxAllowedTypos(Math.min(q.length, 32))

  if (matchWordsAgainstQuery(h, q, maxTypo)) return true

  const scan = h.length > WINDOW_SCAN_MAX_CELL ? h.slice(0, WINDOW_SCAN_MAX_CELL) : h
  return matchSlidingWindows(scan, q, maxTypo)
}
