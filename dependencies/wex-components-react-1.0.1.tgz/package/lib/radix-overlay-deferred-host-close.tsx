import * as React from "react";

/**
 * Radix (dialog-based) surfaces keep content mounted through the close animation.
 * If the host resets create/edit (or any) state when `onOpenChange(false)` runs, that
 * UI can re-render to defaults while the overlay is still visible. We delay notifying
 * the host of `open === false` until the content has fully closed, using
 * `onCloseAutoFocus` on the surface's content (runs after exit animation) plus a
 * short timeout fallback. Shared by WexDialog, WexSheet, and WexAlertDialog.
 */

const FALLBACK_MS = 250;

export type WexOverlayDeferredHostCloseContextValue = {
  flushDeferredClose: () => void;
};

export const WexOverlayDeferredHostCloseContext =
  React.createContext<WexOverlayDeferredHostCloseContextValue | null>(null);

export function useWexOverlayDeferredHostClose(
  openProp: boolean | undefined,
  onOpenChangeFromHost: ((open: boolean) => void) | undefined
) {
  const isControlled = openProp !== undefined;
  const [deferRadixClose, setDeferRadixClose] = React.useState(false);
  const pendingHostClose = React.useRef(false);
  const hostCloseFallbackTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearHostCloseFallback = React.useCallback(() => {
    if (hostCloseFallbackTimer.current) {
      clearTimeout(hostCloseFallbackTimer.current);
      hostCloseFallbackTimer.current = null;
    }
  }, []);

  const flushDeferredClose = React.useCallback(() => {
    if (!pendingHostClose.current) return;
    clearHostCloseFallback();
    pendingHostClose.current = false;
    setDeferRadixClose(false);
    onOpenChangeFromHost?.(false);
  }, [clearHostCloseFallback, onOpenChangeFromHost]);

  const scheduleHostCloseFallback = React.useCallback(() => {
    clearHostCloseFallback();
    hostCloseFallbackTimer.current = setTimeout(() => {
      hostCloseFallbackTimer.current = null;
      flushDeferredClose();
    }, FALLBACK_MS);
  }, [clearHostCloseFallback, flushDeferredClose]);

  const handleOpenChange = React.useCallback(
    (next: boolean) => {
      if (next) {
        clearHostCloseFallback();
        pendingHostClose.current = false;
        setDeferRadixClose(false);
        onOpenChangeFromHost?.(true);
        return;
      }
      if (isControlled) {
        if (openProp === true) {
          pendingHostClose.current = true;
          setDeferRadixClose(true);
          scheduleHostCloseFallback();
        } else {
          onOpenChangeFromHost?.(false);
        }
        return;
      }
      pendingHostClose.current = true;
      scheduleHostCloseFallback();
    },
    [clearHostCloseFallback, isControlled, onOpenChangeFromHost, openProp, scheduleHostCloseFallback]
  );

  React.useEffect(() => {
    if (isControlled && openProp === false) {
      clearHostCloseFallback();
      pendingHostClose.current = false;
      queueMicrotask(() => {
        setDeferRadixClose(false);
      });
    }
  }, [clearHostCloseFallback, isControlled, openProp]);

  React.useEffect(() => () => clearHostCloseFallback(), [clearHostCloseFallback]);

  const openForRoot =
    isControlled && openProp === true && deferRadixClose ? false : openProp;

  return {
    contextValue: { flushDeferredClose: flushDeferredClose },
    openForRoot,
    onOpenChange: handleOpenChange,
  };
}
