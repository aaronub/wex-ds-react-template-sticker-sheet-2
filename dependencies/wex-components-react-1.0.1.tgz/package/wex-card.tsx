import * as React from "react";
import {
  Card as CardRoot,
  CardHeader,
  CardFooter,
  CardTitle,
  CardDescription,
  CardContent,
} from "./shadcn/card";
import { cn } from "./lib/utils";

/** Layer 3 slots → Layer 1 card semantics (see components-bridge.css). */
export const WEX_CARD_RADIUS_SIZE_VARS = {
  xs: "var(--wex-component-card-radius-xs)",
  sm: "var(--wex-component-card-radius-sm)",
  md: "var(--wex-component-card-radius-md)",
  lg: "var(--wex-component-card-radius-lg)",
  xl: "var(--wex-component-card-radius-xl)",
} as const;

export type WexCardRadiusSize = keyof typeof WEX_CARD_RADIUS_SIZE_VARS;

/** Maps to `--wex-shadow-*` layout tokens (design-tokens.json). */
export const WEX_CARD_SHADOW_TOKEN_VARS = {
  none: "var(--wex-shadow-none)",
  subtle: "var(--wex-shadow-subtle)",
  low: "var(--wex-shadow-low)",
  medium: "var(--wex-shadow-medium)",
  high: "var(--wex-shadow-high)",
  elevated: "var(--wex-shadow-elevated)",
  floating: "var(--wex-shadow-floating)",
  highest: "var(--wex-shadow-highest)",
} as const;

export type WexCardShadow = keyof typeof WEX_CARD_SHADOW_TOKEN_VARS;

/** Horizontal outer padding (x) per size — px÷16 → rem: 20/24/32/40/48. */
export const WEX_CARD_PADDING_X_REM: Record<WexCardRadiusSize, string> = {
  xs: "1.25rem",
  sm: "1.5rem",
  md: "2rem",
  lg: "2.5rem",
  xl: "3rem",
};

/** Vertical outer padding (y) per size — px÷16 → rem: 24/32/40/48/56. */
export const WEX_CARD_PADDING_Y_REM: Record<WexCardRadiusSize, string> = {
  xs: "1.5rem",
  sm: "2rem",
  md: "2.5rem",
  lg: "3rem",
  xl: "3.5rem",
};

/**
 * WexCard - WEX Design System Card Component
 *
 * `radiusSize` sets both corner radius and outer padding (header, content, footer share one inset).
 * No border unless `bordered`; default shadow is the `low` elevation token.
 * Uses namespace pattern: WexCard.Header, WexCard.Content, etc.
 *
 * @example
 * <WexCard>
 *   <WexCard.Header>
 *     <WexCard.Title>Card Title</WexCard.Title>
 *     <WexCard.Description>Description</WexCard.Description>
 *   </WexCard.Header>
 *   <WexCard.Content>Content here</WexCard.Content>
 *   <WexCard.Footer>
 *     <WexButton>Action</WexButton>
 *   </WexCard.Footer>
 * </WexCard>
 */

interface WexCardProps extends React.ComponentPropsWithoutRef<typeof CardRoot> {
  /** Corner radius and outer padding (xs–xl). Default `sm`. */
  radiusSize?: WexCardRadiusSize;
  /** When true, applies `border-wex-card-border`. Default false (no border). */
  bordered?: boolean;
  /** Box shadow from WEX elevation tokens (`--wex-shadow-*`). Default `low`. */
  shadow?: WexCardShadow;
}

const WexCardRoot = React.forwardRef<
  React.ElementRef<typeof CardRoot>,
  WexCardProps
>(({ className, style, radiusSize = "sm", bordered = false, shadow = "low", ...props }, ref) => {
  const radiusKey: WexCardRadiusSize = radiusSize ?? "sm";
  const borderRadius = WEX_CARD_RADIUS_SIZE_VARS[radiusKey];
  const paddingX = WEX_CARD_PADDING_X_REM[radiusKey];
  const paddingY = WEX_CARD_PADDING_Y_REM[radiusKey];

  return (
    <CardRoot
      ref={ref}
      className={cn(
        "wex-card flex flex-col gap-4 bg-wex-card-bg text-wex-card-fg shadow-none",
        bordered ? "border border-wex-card-border" : "border-0",
        className
      )}
      style={{
        borderRadius,
        paddingLeft: paddingX,
        paddingRight: paddingX,
        paddingTop: paddingY,
        paddingBottom: paddingY,
        boxShadow: WEX_CARD_SHADOW_TOKEN_VARS[shadow],
        ...style,
      }}
      {...props}
    />
  );
});
WexCardRoot.displayName = "WexCard";

const WexCardTitle = React.forwardRef<
  React.ElementRef<typeof CardTitle>,
  React.ComponentPropsWithoutRef<typeof CardTitle>
>(({ className, ...props }, ref) => (
  <CardTitle
    ref={ref}
    className={cn("text-wex-card-header-fg", className)}
    {...props}
  />
));
WexCardTitle.displayName = "WexCard.Title";

/** Outer padding is on WexCard root; strips shadcn section padding. */
const WexCardHeader = React.forwardRef<
  React.ElementRef<typeof CardHeader>,
  React.ComponentPropsWithoutRef<typeof CardHeader>
>(({ className, ...props }, ref) => (
  <CardHeader ref={ref} className={cn("p-0", className)} {...props} />
));
WexCardHeader.displayName = "WexCard.Header";

const WexCardContent = React.forwardRef<
  React.ElementRef<typeof CardContent>,
  React.ComponentPropsWithoutRef<typeof CardContent>
>(({ className, ...props }, ref) => (
  <CardContent ref={ref} className={cn("p-0", className)} {...props} />
));
WexCardContent.displayName = "WexCard.Content";

const WexCardFooter = React.forwardRef<
  React.ElementRef<typeof CardFooter>,
  React.ComponentPropsWithoutRef<typeof CardFooter>
>(({ className, ...props }, ref) => (
  <CardFooter
    ref={ref}
    className={cn("flex flex-wrap items-center gap-2 p-0 text-wex-card-footer-fg", className)}
    {...props}
  />
));
WexCardFooter.displayName = "WexCard.Footer";

export const WexCard = Object.assign(WexCardRoot, {
  Header: WexCardHeader,
  Footer: WexCardFooter,
  Title: WexCardTitle,
  Description: CardDescription,
  Content: WexCardContent,
});
