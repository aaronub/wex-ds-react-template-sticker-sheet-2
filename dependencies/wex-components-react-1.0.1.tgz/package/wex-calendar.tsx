import * as React from "react";
import {
  Calendar as CalendarRoot,
} from "./shadcn/calendar";
import { getDefaultClassNames } from "react-day-picker";
import { WexButton } from "./wex-button";
import { cn } from "./lib/utils";

/**
 * WexCalendar - WEX Design System Calendar Component
 *
 * Date picker calendar component supporting single, multiple, and range selection.
 * Default width is 21.5rem (fixed shell; aligns with date picker field).
 * Range mode doubles the shell width (43rem) for two-month layout; when `mode`
 * is `range`, `numberOfMonths` defaults to 2 unless you pass another value.
 *
 * @example
 * const [date, setDate] = useState<Date | undefined>(new Date());
 * <WexCalendar
 *   mode="single"
 *   selected={date}
 *   onSelect={setDate}
 *   className="rounded-md border"
 * />
 */

function WexCalendarDayButton({
  className,
  day,
  modifiers,
  ...props
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- multiple react-day-picker copies disagree on DayButton props (upstream fix-type-and-module-issues)
}: any) {
  const defaultClassNames = getDefaultClassNames();

  const ref = React.useRef<HTMLButtonElement>(null);
  React.useEffect(() => {
    if (modifiers.focused) ref.current?.focus();
  }, [modifiers.focused]);

  const isRangeSingleDay =
    Boolean(modifiers.range_start) &&
    Boolean(modifiers.range_end) &&
    !modifiers.range_middle;

  const rangeEndpointRounding = (() => {
    if (modifiers.range_middle) return "!rounded-none";
    if (isRangeSingleDay) return "!rounded-full";
    if (modifiers.range_start && !modifiers.range_end) {
      return "!rounded-l-full !rounded-r-none";
    }
    if (modifiers.range_end && !modifiers.range_start) {
      return "!rounded-r-full !rounded-l-none";
    }
    return "!rounded-full";
  })();

  const showTodayHighlight =
    Boolean(modifiers.today) &&
    !modifiers.selected &&
    !modifiers.range_start &&
    !modifiers.range_middle &&
    !modifiers.range_end;

  const rangeMiddleFullWidth = Boolean(modifiers.range_middle);

  return (
    <WexButton
      ref={ref}
      intent="contrast"
      variant="ghost"
      iconOnly
      data-day={day.date.toLocaleDateString()}
      data-selected-single={
        modifiers.selected &&
        !modifiers.range_start &&
        !modifiers.range_end &&
        !modifiers.range_middle
      }
      data-range-start={modifiers.range_start}
      data-range-end={modifiers.range_end}
      data-range-middle={modifiers.range_middle}
      className={cn(
        // Contrast ghost avoids primary link blue overriding calendar day tokens.
        "!text-wex-calendar-day-fg",
        modifiers.outside && "!text-wex-calendar-day-outside-fg/80",
        "data-[selected-single=true]:!bg-wex-calendar-day-selected-bg data-[selected-single=true]:!text-wex-calendar-day-selected-fg data-[range-start=true]:!bg-wex-calendar-day-selected-bg data-[range-start=true]:!text-wex-calendar-day-selected-fg data-[range-end=true]:!bg-wex-calendar-day-selected-bg data-[range-end=true]:!text-wex-calendar-day-selected-fg group-data-[focused=true]/day:border-wex-calendar-day-selected-bg group-data-[focused=true]/day:ring-wex-calendar-day-selected-bg/50",
        modifiers.range_middle &&
          cn(
            modifiers.today
              ? "!bg-wex-calendar-day-today-bg !text-wex-calendar-day-today-fg [&:hover]:!bg-wex-calendar-day-today-bg [&:active]:!bg-wex-calendar-day-today-bg"
              : "!bg-transparent !text-wex-calendar-day-range-fg"
          ),
        rangeMiddleFullWidth &&
          "!flex !h-[--cell-size] min-h-[--cell-size] !min-w-0 !w-full !max-w-none flex-1 flex-col !gap-0 !aspect-auto",
        !rangeMiddleFullWidth &&
          "!aspect-square !h-[--cell-size] !w-[--cell-size] !min-w-[--cell-size] !max-w-[--cell-size]",
        "!flex !flex-col gap-0 !font-normal !leading-none !p-0 !m-0 !items-center !justify-center group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70 [&>span]:!text-inherit",
        rangeEndpointRounding,
        modifiers.today &&
          !modifiers.selected &&
          !showTodayHighlight &&
          !modifiers.range_middle &&
          "!text-wex-calendar-day-today-fg hover:!text-wex-calendar-day-today-fg active:!text-wex-calendar-day-today-fg",
        defaultClassNames.day_button,
        showTodayHighlight &&
          "!bg-wex-calendar-day-today-bg !text-wex-calendar-day-today-fg !rounded-full [&:hover]:!bg-wex-calendar-day-today-bg [&:active]:!bg-wex-calendar-day-today-bg",
        className
      )}
      {...props}
    />
  );
}

/** Single-strip width; range mode doubles to 43rem (2× 21.5rem). */
export const WexCalendar = ({
  className,
  classNames,
  components,
  mode,
  numberOfMonths,
  ...props
}: React.ComponentProps<typeof CalendarRoot>) => {
  const defaultClassNames = getDefaultClassNames();
  const isRangeMode = mode === "range";
  const numberOfMonthsResolved =
    numberOfMonths ?? (isRangeMode ? 2 : 1);
  /* literals must appear in source for Tailwind class detection */
  const shellWidthClass = isRangeMode
    ? "!w-[43rem] min-w-[43rem] max-w-[43rem]"
    : "!w-[21.5rem] min-w-[21.5rem] max-w-[21.5rem]";
  const rootWidthClass = isRangeMode
    ? "!w-[43rem] !min-w-[43rem] !max-w-[43rem]"
    : "!w-[21.5rem] !min-w-[21.5rem] !max-w-[21.5rem]";

  const calendarProps = {
      ...props,
      mode: mode ?? "single",
      numberOfMonths: numberOfMonthsResolved,
      components: {
        DayButton: WexCalendarDayButton,
        ...components,
      },
      className: cn(
        className,
        /* Match control height token (h-10); --spacing(8) is not a valid length for arbitrary props in all builds */
        "bg-wex-calendar-bg text-wex-calendar-fg group/calendar !p-4 [--cell-size:2.5rem]",
        shellWidthClass,
        "[[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent"
      ),
      classNames: {
        // Root is the visible shell; DayPicker joins root + className (no tw-merge) — use ! on radius/shadow
        // so consumer classes (e.g. rounded-md) do not override design tokens.
        root: cn(
          "min-w-0 w-full",
          rootWidthClass,
          "!rounded-[var(--wex-radius-controls-large)] !shadow-[var(--wex-shadow-medium)] overflow-x-clip overflow-y-visible",
          "border border-solid border-border",
          defaultClassNames.root
        ),
        months: cn(
          "relative flex w-full max-w-full flex-col gap-4 md:flex-row",
          defaultClassNames.months
        ),
        month: cn(
          "relative flex w-full max-w-full flex-col gap-4 self-stretch",
          defaultClassNames.month
        ),
        nav: cn(
          // Full-width toolbar must not Eat clicks in the center — only the arrows are interactive.
          "pointer-events-none absolute inset-x-0 top-0 z-20 flex w-full items-center justify-between gap-1",
          defaultClassNames.nav
        ),
        button_previous: cn(
          "pointer-events-auto h-[--cell-size] w-[--cell-size] select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_previous
        ),
        button_next: cn(
          "pointer-events-auto h-[--cell-size] w-[--cell-size] select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_next
        ),
        month_caption: cn(
          "relative z-0 isolate flex h-[--cell-size] w-full min-w-0 items-center justify-center px-[--cell-size]",
          defaultClassNames.month_caption
        ),
        dropdowns: cn(
          "flex h-[--cell-size] w-full min-w-0 items-center justify-center gap-x-2 gap-y-0 font-medium text-wex-calendar-header-fg",
          defaultClassNames.dropdowns
        ),
        /* Match label-caption look: no boxed chrome; invisible select sits above faux label (z-index). */
        dropdown_root: cn(
          "relative inline-flex shrink-0 items-center justify-center border-0 bg-transparent p-0 shadow-none",
          defaultClassNames.dropdown_root
        ),
        dropdown: cn(
          "absolute inset-0 z-[2] h-full min-h-full w-full min-w-0 cursor-pointer appearance-none border-0 bg-transparent p-0",
          /* Opacity 0 can reduce hit area in some engines; 0.01 stays invisible but reliably clickable. */
          "opacity-[0.01]",
          "focus:outline-none focus-visible:outline-none focus:ring-0 focus-visible:ring-0",
          defaultClassNames.dropdown
        ),
        caption_label: cn(
          "pointer-events-none relative z-[1] inline-flex select-none flex-row items-center gap-1 whitespace-nowrap font-medium text-wex-calendar-header-fg",
          "[&>svg]:size-3.5 [&>svg]:shrink-0 [&>svg]:text-wex-calendar-header-fg",
          defaultClassNames.caption_label
        ),
        /** Equal column widths (% of table): fixed min cell width fights 7-column layout otherwise. */
        month_grid: cn(
          "w-full min-w-0 table-fixed border-separate border-spacing-x-0 border-spacing-y-3",
          "[&_thead_tr_th]:box-border [&_thead_tr_th]:w-[calc(100%/7)] [&_thead_tr_th]:min-w-0 [&_thead_tr_th]:max-w-[calc(100%/7)]",
          "[&_tbody_td]:box-border [&_tbody_td]:min-w-0",
          defaultClassNames.month_grid
        ),
        table: cn(
          "w-full min-w-0 table-fixed border-separate border-spacing-x-0 border-spacing-y-3",
          "[&_thead_tr_th]:box-border [&_thead_tr_th]:w-[calc(100%/7)] [&_thead_tr_th]:min-w-0 [&_thead_tr_th]:max-w-[calc(100%/7)]",
          "[&_tbody_td]:box-border [&_tbody_td]:min-w-0",
          defaultClassNames.month_grid
        ),
        weekdays: cn("w-full py-2", defaultClassNames.weekdays),
        weekday: cn(
          "box-border px-1 py-0.5 align-middle text-center text-[0.8rem] font-normal leading-none text-wex-calendar-weekday-fg select-none rounded-md",
          defaultClassNames.weekday
        ),
        /** `<tr>` for tbody weeks — spacing handled by month_grid border-spacing-y */
        week: cn("w-full", defaultClassNames.week),
        week_number_header: cn(
          "w-[--cell-size] select-none",
          defaultClassNames.week_number_header
        ),
        week_number: cn(
          "text-wex-calendar-day-outside-fg select-none text-[0.8rem]",
          defaultClassNames.week_number
        ),
        day: cn(
          "group/day relative box-border min-w-0 max-w-none aspect-square h-full w-full select-none text-center align-middle !p-0 !m-0 [&:first-child[data-selected=true]_button]:rounded-l-full [&:last-child[data-selected=true]_button]:rounded-r-full",
          /* Never apply display:flex to <td> — it exits table-cell layout and breaks the 7-column grid. */
          "[&.rdp-range_start.rdp-range_end]:!bg-transparent [&.rdp-range_start.rdp-range_end]:![background-image:none]",
          defaultClassNames.day
        ),
        // Range strip paints on <td>; gradients bridge pill width (--cell-size). Cells stay display: table-cell.
        range_start: cn(
          defaultClassNames.range_start,
          "relative z-0 align-middle text-left !rounded-none !p-0",
          "ltr:![background-image:linear-gradient(to_right,transparent_0%,transparent_var(--cell-size),hsl(var(--wex-component-calendar-day-range-bg))_var(--cell-size),hsl(var(--wex-component-calendar-day-range-bg))_100%)]",
          "rtl:![background-image:linear-gradient(to_left,transparent_0%,transparent_var(--cell-size),hsl(var(--wex-component-calendar-day-range-bg))_var(--cell-size),hsl(var(--wex-component-calendar-day-range-bg))_100%)]"
        ),
        range_middle: cn(
          defaultClassNames.range_middle,
          "relative z-0 align-middle !rounded-none !bg-wex-calendar-day-range-bg !p-0"
        ),
        range_end: cn(
          defaultClassNames.range_end,
          "relative z-0 align-middle text-right !rounded-none !p-0",
          "ltr:![background-image:linear-gradient(to_right,hsl(var(--wex-component-calendar-day-range-bg))_0,hsl(var(--wex-component-calendar-day-range-bg))_calc(100%-var(--cell-size)),transparent_calc(100%-var(--cell-size)),transparent_100%)]",
          "rtl:![background-image:linear-gradient(to_left,hsl(var(--wex-component-calendar-day-range-bg))_0,hsl(var(--wex-component-calendar-day-range-bg))_calc(100%-var(--cell-size)),transparent_calc(100%-var(--cell-size)),transparent_100%)]"
        ),
        today: cn(
          defaultClassNames.today,
          "!rounded-none !bg-transparent p-0",
          "data-[selected=true]:!bg-transparent data-[selected=true]:!rounded-none"
        ),
        outside: cn(
          "text-wex-calendar-day-outside-fg/80 aria-selected:text-wex-calendar-day-outside-fg/80",
          defaultClassNames.outside
        ),
        disabled: cn(
          "text-wex-calendar-day-disabled-fg opacity-50",
          defaultClassNames.disabled
        ),
        hidden: cn("invisible", defaultClassNames.hidden),
        ...classNames,
      },
    } as React.ComponentProps<typeof CalendarRoot>;

  return <CalendarRoot {...calendarProps} />;
};
WexCalendar.displayName = "WexCalendar";
