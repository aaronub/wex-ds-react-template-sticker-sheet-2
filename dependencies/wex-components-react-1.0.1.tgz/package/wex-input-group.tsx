import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import {
  InputGroup as InputGroupRoot,
  InputGroupAddon as InputGroupAddonBase,
  InputGroupText as InputGroupTextBase,
  InputGroupTextarea,
} from "./shadcn/input-group";
import { cn } from "./lib/utils";
import { cva, type VariantProps } from "class-variance-authority";
import { WexInput, type WexInputProps } from "./wex-input";
import { WexInputMask, type WexInputMaskProps } from "./wex-input-mask";
import { WexInputNumber, type WexInputNumberProps } from "./wex-input-number";

export type WexInputGroupSize = "md" | "lg" | "xl";

const WexInputGroupContext = React.createContext<{ size: WexInputGroupSize }>({
  size: "md",
});

/**
 * WexInputGroup - WEX Design System Input Group Component
 *
 * Container for input with addons, buttons, and text.
 * Uses namespace pattern: WexInputGroup.Addon, WexInputGroup.Input, etc.
 *
 * @example
 * <WexInputGroup>
 *   <WexInputGroup.Addon align="inline-start">
 *     <Icon />
 *   </WexInputGroup.Addon>
 *   <WexInputGroup.Input placeholder="Search..." />
 *   <WexInputGroup.Addon align="inline-end">
 *     <WexInputGroup.Button>Search</WexInputGroup.Button>
 *   </WexInputGroup.Addon>
 * </WexInputGroup>
 */

const inputGroupSizeClass: Record<WexInputGroupSize, string> = {
  md: "h-10 min-h-10",
  lg: "h-12 min-h-12",
  xl: "h-14 min-h-14",
};

const inputGroupRadiusClass: Record<WexInputGroupSize, string> = {
  md: "rounded-[var(--wex-radius-controls-medium)]",
  lg: "rounded-[var(--wex-radius-controls-large)]",
  xl: "rounded-[var(--wex-radius-controls-extra-large)]",
};

const inputGroupRadiusVar: Record<WexInputGroupSize, string> = {
  md: "var(--wex-radius-controls-medium)",
  lg: "var(--wex-radius-controls-large)",
  xl: "var(--wex-radius-controls-extra-large)",
};

export type WexInputGroupRootProps = React.ComponentPropsWithoutRef<typeof InputGroupRoot> & {
  /** Matches WexInput / WexButton: md (2.5 rem, default), lg (3 rem), xl (3.5 rem) */
  size?: WexInputGroupSize;
};

const WexInputGroupRoot = React.forwardRef<HTMLDivElement, WexInputGroupRootProps>(
  ({ className, size = "md", style, ...props }, ref) => (
    <WexInputGroupContext.Provider value={{ size }}>
      <InputGroupRoot
        ref={ref}
        className={cn("wex-input-group", inputGroupSizeClass[size], inputGroupRadiusClass[size], className)}
        style={
          {
            ...style,
            ["--wex-input-group-radius" as string]: inputGroupRadiusVar[size],
          } as React.CSSProperties
        }
        {...props}
      />
    </WexInputGroupContext.Provider>
  )
);
WexInputGroupRoot.displayName = "WexInputGroup";

const wexInputGroupAddonVariants = cva(
  "text-wex-inputgroup-addon-fg flex h-auto cursor-text select-none items-center justify-center gap-2 py-1.5 text-sm font-medium group-data-[disabled=true]/input-group:opacity-50 [&>kbd]:rounded-[calc(var(--wex-input-group-radius)-5px)] [&>svg:not([class*='size-'])]:size-4",
  {
    variants: {
      align: {
        "inline-start":
          "order-first pl-3 has-[>button]:ml-[-0.45rem] has-[>kbd]:ml-[-0.35rem]",
        "inline-end":
          "order-last pr-3 has-[>button]:mr-[-0.4rem] has-[>kbd]:mr-[-0.35rem]",
        "block-start":
          "[.border-b]:pb-3 order-first w-full justify-start px-3 pt-3 group-has-[>input]/input-group:pt-2.5",
        "block-end":
          "[.border-t]:pt-3 order-last w-full justify-start px-3 pb-3 group-has-[>input]/input-group:pb-2.5",
      },
    },
    defaultVariants: {
      align: "inline-start",
    },
  }
);

const WexInputGroupAddon = React.forwardRef<
  HTMLDivElement,
  React.ComponentPropsWithoutRef<typeof InputGroupAddonBase> & VariantProps<typeof wexInputGroupAddonVariants>
>(({ className, align = "inline-start", ...props }, ref) => (
  <InputGroupAddonBase
    ref={ref}
    data-align={align}
    className={cn(wexInputGroupAddonVariants({ align }), className)}
    {...props}
  />
));
WexInputGroupAddon.displayName = "WexInputGroup.Addon";

const wexInputGroupButtonIconSize: Record<WexInputGroupSize, string> = {
  md: "h-8 w-8 min-h-8 min-w-8",
  lg: "h-9 w-9 min-h-9 min-w-9",
  xl: "h-10 w-10 min-h-10 min-w-10",
};

export type WexInputGroupButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  asChild?: boolean;
  /** Circular hit area. Omit for a pill-shaped text action (e.g. "Search"). */
  iconOnly?: boolean;
};

const WexInputGroupButton = React.forwardRef<HTMLButtonElement, WexInputGroupButtonProps>(function WexInputGroupButton(
  { className, asChild = false, iconOnly = false, type = "button", ...props },
  ref
) {
  const { size: groupSize } = React.useContext(WexInputGroupContext);
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      ref={ref}
      type={asChild ? undefined : type}
      data-slot="input-group-button"
      className={cn(
        "inline-flex shrink-0 items-center justify-center border-0 text-sm font-medium text-wex-inputgroup-addon-fg",
        "transition-[color,background-color]",
        "hover:bg-wex-inputgroup-addon-bg/50 active:bg-wex-inputgroup-addon-bg/65",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-wex-input-focus-ring focus-visible:ring-offset-0",
        "disabled:pointer-events-none disabled:opacity-50",
        iconOnly ? cn("rounded-full p-0", wexInputGroupButtonIconSize[groupSize]) : "rounded-full px-2.5 py-1.5",
        className
      )}
      {...props}
    />
  );
});
WexInputGroupButton.displayName = "WexInputGroup.Button";

const WexInputGroupText = React.forwardRef<
  HTMLSpanElement,
  React.ComponentPropsWithoutRef<typeof InputGroupTextBase>
>(({ className, ...props }, ref) => (
  <InputGroupTextBase
    ref={ref}
    className={cn("text-wex-inputgroup-addon-fg", className)}
    {...props}
  />
));
WexInputGroupText.displayName = "WexInputGroup.Text";

const inputGroupControlClasses =
  "h-full flex-1 rounded-none border-0 bg-transparent shadow-none focus-visible:ring-0 focus-visible:border-transparent hover:border-transparent dark:bg-transparent";

const WexInputGroupInput = React.forwardRef<
  HTMLInputElement,
  Omit<WexInputProps, "leftIcon" | "rightIcon">
>(({ className, style, size: sizeProp, ...props }, ref) => {
  const { size: ctxSize } = React.useContext(WexInputGroupContext);
  const size = sizeProp ?? ctxSize;
  return (
    <WexInput
      ref={ref}
      data-slot="input-group-control"
      size={size}
      className={cn(inputGroupControlClasses, className)}
      style={{ ...style, borderRadius: 0 }}
      {...props}
    />
  );
});
WexInputGroupInput.displayName = "WexInputGroup.Input";

const WexInputGroupInputMask = React.forwardRef<
  HTMLInputElement,
  Omit<WexInputMaskProps, "leftIcon" | "rightIcon">
>(({ className, style, size: sizeProp, ...props }, ref) => {
  const { size: ctxSize } = React.useContext(WexInputGroupContext);
  const size = sizeProp ?? ctxSize;
  return (
    <WexInputMask
      ref={ref}
      data-slot="input-group-control"
      size={size}
      className={cn(inputGroupControlClasses, className)}
      style={{ ...style, borderRadius: 0 }}
      {...props}
    />
  );
});
WexInputGroupInputMask.displayName = "WexInputGroup.InputMask";

const WexInputGroupInputNumber = React.forwardRef<
  HTMLInputElement,
  Omit<WexInputNumberProps, "fluid">
>(({ className, size: sizeProp, ...props }, ref) => {
  const { size: ctxSize } = React.useContext(WexInputGroupContext);
  const size = sizeProp ?? ctxSize;
  return (
    <WexInputNumber
      ref={ref}
      data-slot="input-group-control"
      size={size}
      fluid
      className={cn(
        "flex-1",
        "[&>input]:h-full [&>input]:border-0 [&>input]:bg-transparent [&>input]:shadow-none [&>input]:rounded-none [&>input]:focus-visible:ring-0 [&>input]:focus-visible:border-transparent [&>input]:hover:border-transparent [&>input]:dark:bg-transparent",
        className
      )}
      {...props}
    />
  );
});
WexInputGroupInputNumber.displayName = "WexInputGroup.InputNumber";

export const WexInputGroup = Object.assign(WexInputGroupRoot, {
  Addon: WexInputGroupAddon,
  Button: WexInputGroupButton,
  Text: WexInputGroupText,
  Input: WexInputGroupInput,
  InputMask: WexInputGroupInputMask,
  InputNumber: WexInputGroupInputNumber,
  Textarea: InputGroupTextarea,
});
