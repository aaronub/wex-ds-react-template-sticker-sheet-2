import * as React from "react";
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog";
import {
  AlertDialog as AlertDialogRoot,
  AlertDialogPortal,
  AlertDialogTrigger,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
} from "./shadcn/alert-dialog";
import { cn } from "./lib/utils";
import {
  WexOverlayDeferredHostCloseContext,
  useWexOverlayDeferredHostClose,
} from "./lib/radix-overlay-deferred-host-close";

/**
 * WexAlertDialog - WEX Design System Alert Dialog Component
 *
 * Modal dialog for important confirmations that require user acknowledgment.
 * Uses namespace pattern: WexAlertDialog.Trigger, WexAlertDialog.Content, etc.
 *
 * @example
 * <WexAlertDialog>
 *   <WexAlertDialog.Trigger asChild>
 *     <WexButton intent="destructive">Delete</WexButton>
 *   </WexAlertDialog.Trigger>
 *   <WexAlertDialog.Content>
 *     <WexAlertDialog.Header>
 *       <WexAlertDialog.Title>Are you sure?</WexAlertDialog.Title>
 *       <WexAlertDialog.Description>This action cannot be undone.</WexAlertDialog.Description>
 *     </WexAlertDialog.Header>
 *     <WexAlertDialog.Footer>
 *       <WexAlertDialog.CloseButton>Cancel</WexAlertDialog.CloseButton>
 *       <WexAlertDialog.Action>Continue</WexAlertDialog.Action>
 *     </WexAlertDialog.Footer>
 *   </WexAlertDialog.Content>
 * </WexAlertDialog>
 *
 * The root defers the host `onOpenChange(false)` call until the close has fully finished
 * (and falls back to a short timer if `WexAlertDialog.Content` is not used), matching
 * WexDialog and WexSheet. Avoids copy flashing on dismiss while the exit animation runs.
 */

// AlertDialogRoot is a context provider and doesn't accept refs
// Use the Root from UI components which is already properly set up; we wrap to defer
// host `onOpenChange(false)`.
const WexAlertDialogRoot = ((props: React.ComponentProps<typeof AlertDialogRoot>) => {
  const {
    open: openProp,
    defaultOpen,
    onOpenChange: onOpenChangeFromHost,
    children,
    ...rest
  } = props;
  const isControlled = openProp !== undefined;
  const { contextValue, openForRoot, onOpenChange: handleOpenChange } =
    useWexOverlayDeferredHostClose(openProp, onOpenChangeFromHost);

  return (
    <WexOverlayDeferredHostCloseContext.Provider value={contextValue}>
      <AlertDialogRoot
        {...rest}
        defaultOpen={defaultOpen}
        open={isControlled ? openForRoot : openProp}
        onOpenChange={handleOpenChange}
      >
        {children}
      </AlertDialogRoot>
    </WexOverlayDeferredHostCloseContext.Provider>
  );
}) as typeof AlertDialogRoot;

const WexAlertDialogOverlay = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-50 bg-wex-alertdialog-overlay data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    )}
    {...props}
    ref={ref}
  />
));
WexAlertDialogOverlay.displayName = "WexAlertDialog.Overlay";

const WexAlertDialogContent = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Content>
>(({ className, onCloseAutoFocus, ...props }, ref) => {
  const wexOverlayDeferred = React.useContext(WexOverlayDeferredHostCloseContext);
  return (
    <AlertDialogPortal>
      <WexAlertDialogOverlay />
      <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto p-4 pointer-events-none">
        <AlertDialogPrimitive.Content
          ref={ref}
          className={cn(
            "pointer-events-auto origin-center grid w-full max-w-lg gap-4 border border-wex-alertdialog-border bg-wex-alertdialog-bg text-wex-alertdialog-fg p-6 shadow-[var(--wex-component-alertdialog-shadow)] duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 rounded-[var(--wex-radius-card-small)]",
            className
          )}
          onCloseAutoFocus={(event) => {
            wexOverlayDeferred?.flushDeferredClose();
            onCloseAutoFocus?.(event);
          }}
          {...props}
        />
      </div>
    </AlertDialogPortal>
  );
});
WexAlertDialogContent.displayName = "WexAlertDialog.Content";

/** Non-destructive footer control: same Radix primitive as `Cancel` (shadcn outline cancel by default). */
function WexAlertDialogCloseButton(
  props: React.ComponentProps<typeof AlertDialogCancel>
) {
  return <AlertDialogCancel {...props} />;
}
WexAlertDialogCloseButton.displayName = "WexAlertDialog.CloseButton";

/** WEX spacing: tighter title↔description (`gap-3`); no extra margin—`Content` `gap-4` handles header↔body. */
const WexAlertDialogHeader = ({
  className,
  ...props
}: React.ComponentProps<typeof AlertDialogHeader>) => (
  <AlertDialogHeader className={cn("gap-3", className)} {...props} />
);
WexAlertDialogHeader.displayName = "WexAlertDialog.Header";

/** @deprecated Use `WexAlertDialog.CloseButton` or `Cancel`. */
const WexAlertDialogDismissButton = WexAlertDialogCloseButton;

const WexAlertDialogRootWithNamespace: typeof WexAlertDialogRoot & {
  Portal: typeof AlertDialogPortal;
  Overlay: typeof WexAlertDialogOverlay;
  Trigger: typeof AlertDialogTrigger;
  Content: typeof WexAlertDialogContent;
  Header: typeof WexAlertDialogHeader;
  Footer: typeof AlertDialogFooter;
  Title: typeof AlertDialogTitle;
  Description: typeof AlertDialogDescription;
  Action: typeof AlertDialogAction;
  Cancel: typeof AlertDialogCancel;
  CloseButton: typeof WexAlertDialogCloseButton;
  /** @deprecated Use `CloseButton` or `Cancel`. */
  DismissButton: typeof WexAlertDialogCloseButton;
} = Object.assign(WexAlertDialogRoot, {
  Portal: AlertDialogPortal,
  Overlay: WexAlertDialogOverlay,
  Trigger: AlertDialogTrigger,
  Content: WexAlertDialogContent,
  Header: WexAlertDialogHeader,
  Footer: AlertDialogFooter,
  Title: AlertDialogTitle,
  Description: AlertDialogDescription,
  Action: AlertDialogAction,
  Cancel: AlertDialogCancel,
  CloseButton: WexAlertDialogCloseButton,
  DismissButton: WexAlertDialogDismissButton,
});

export const WexAlertDialog = WexAlertDialogRootWithNamespace;

