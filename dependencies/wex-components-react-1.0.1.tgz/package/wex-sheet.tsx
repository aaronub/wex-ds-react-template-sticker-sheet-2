import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetTitle,
  SheetDescription,
} from "./shadcn/sheet";
import { cn } from "./lib/utils";
import { WexButton, type WexButtonProps } from "./wex-button";
import {
  WexOverlayDeferredHostCloseContext,
  useWexOverlayDeferredHostClose,
} from "./lib/radix-overlay-deferred-host-close";

/**
 * Many shadcn sheet modules only export SheetContent (which inlines Portal + Overlay).
 * Sheet and Dialog share @radix-ui/react-dialog; we provide Portal/Overlay here so
 * WexSheet.Portal / WexSheet.Overlay work without requiring host re-exports.
 */
const SheetPortal = DialogPrimitive.Portal;

const SheetOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0",
      className,
    )}
    {...props}
  />
));
SheetOverlay.displayName = "SheetOverlay";

/**
 * WexSheet - WEX Design System Sheet Component
 *
 * Slide-out panel from screen edge.
 * Uses namespace pattern: WexSheet.Trigger, WexSheet.Content, etc.
 *
 * @example
 * <WexSheet>
 *   <WexSheet.Trigger asChild>
 *     <WexButton variant="outline">Open Sheet</WexButton>
 *   </WexSheet.Trigger>
 *   <WexSheet.Content>
 *     <WexSheet.Header>
 *       <WexSheet.Title>Sheet Title</WexSheet.Title>
 *       <WexSheet.Description>Sheet description</WexSheet.Description>
 *     </WexSheet.Header>
 *     Content here
 *     <WexSheet.Footer>
 *       <WexSheet.CloseButton>Close</WexSheet.CloseButton>
 *     </WexSheet.Footer>
 *   </WexSheet.Content>
 * </WexSheet>
 *
 * The root defers the host `onOpenChange(false)` call until the close has fully finished
 * (and falls back to a short timer if `WexSheet.Content` is not used). That keeps
 * create vs edit (or any reset) in sync with the exit animation, same as WexDialog.
 */

// CRITICAL: Dialog and Sheet share the same Radix primitive (@radix-ui/react-dialog)
// We must create a wrapper function to avoid mutating the shared Root object
// If we use Object.assign directly on Sheet, Dialog will overwrite Sheet's Content
const WexSheetRoot = ((props: React.ComponentProps<typeof Sheet>) => {
  const {
    open: openProp,
    defaultOpen,
    onOpenChange: onOpenChangeFromHost,
    modal = true,
    children,
    ...rest
  } = props;
  const isControlled = openProp !== undefined;
  const { contextValue, openForRoot, onOpenChange: handleOpenChange } =
    useWexOverlayDeferredHostClose(openProp, onOpenChangeFromHost);

  return (
    <WexOverlayDeferredHostCloseContext.Provider value={contextValue}>
      <Sheet
        {...rest}
        modal={modal}
        defaultOpen={defaultOpen}
        open={isControlled ? openForRoot : openProp}
        onOpenChange={handleOpenChange}
      >
        {children}
      </Sheet>
    </WexOverlayDeferredHostCloseContext.Provider>
  );
}) as typeof Sheet;

interface WexSheetContentProps
  extends Omit<React.ComponentPropsWithoutRef<typeof SheetContent>, "size"> {
  size?: "sm" | "md" | "lg" | "xl" | "full";
}

const WexSheetContent = React.forwardRef<
  React.ElementRef<typeof SheetContent>,
  WexSheetContentProps
>(({ className, side = "right", size = "md", onOpenAutoFocus, onCloseAutoFocus, tabIndex, children, ...props }, ref) => {
  const wexOverlayDeferred = React.useContext(WexOverlayDeferredHostCloseContext);
  const sizeClasses = {
    sm: side === "left" || side === "right" ? "!w-64 !max-w-64" : "!h-64 !max-h-64",
    md: side === "left" || side === "right" ? "!w-96 !max-w-96" : "!h-96 !max-h-96",
    lg: side === "left" || side === "right" ? "!w-[32rem] !max-w-[32rem]" : "!h-[32rem] !max-h-[32rem]",
    xl: side === "left" || side === "right" ? "!w-[42rem] !max-w-[42rem]" : "!h-[42rem] !max-h-[42rem]",
    full: side === "left" || side === "right" ? "!w-screen !h-screen !max-w-none !max-h-none" : "!w-screen !h-screen !max-w-none !max-h-none",
  };
  const borderClass =
    side === "bottom"
      ? "border-t border-wex-sheet-border"
      : side === "top"
      ? "border-b border-wex-sheet-border"
      : side === "left"
      ? "border-r border-wex-sheet-border"
      : "border-l border-wex-sheet-border";
  return (
    <SheetContent
      ref={ref}
      side={side}
      className={cn(
        "wex-sheet-content bg-wex-sheet-bg gap-0 p-0 outline-none focus:outline-none min-h-0",
        borderClass,
        sizeClasses[size as keyof typeof sizeClasses],
        className
      )}
      {...props}
      tabIndex={tabIndex ?? -1}
      onOpenAutoFocus={(event) => {
        onOpenAutoFocus?.(event);
        if (event.defaultPrevented) return;
        event.preventDefault();
        (event.currentTarget as HTMLElement).focus();
      }}
      onCloseAutoFocus={(event) => {
        wexOverlayDeferred?.flushDeferredClose();
        onCloseAutoFocus?.(event);
      }}
    >
      <div
        data-slot="sheet-body"
        className="flex min-h-0 min-w-0 flex-1 flex-col gap-2 overflow-y-auto pb-4 [&>p]:mt-0"
        style={{ paddingInline: "1rem" }}
      >
        {children}
      </div>
    </SheetContent>
  );
});
WexSheetContent.displayName = "WexSheet.Content";

/** Vertical rhythm only; horizontal inset comes from the inner column in WexSheet.Content. */
const WexSheetHeader = ({ className, ...props }: React.ComponentProps<"div">) => (
  <div
    data-slot="sheet-header"
    className={cn(
      "flex flex-col gap-3 pt-4 pb-2 [&_h2]:mt-0 [&_h2]:mb-0 [&_p]:mt-0 [&_p]:mb-0",
      className
    )}
    {...props}
  />
);
WexSheetHeader.displayName = "WexSheet.Header";

const WexSheetFooter = ({ className, ...props }: React.ComponentProps<"div">) => (
  <div
    data-slot="sheet-footer"
    className={cn("mt-auto flex flex-col gap-2 py-4", className)}
    {...props}
  />
);
WexSheetFooter.displayName = "WexSheet.Footer";

/**
 * Footer **close** control: same Radix `Close` as the sheet header control, as a {@link WexButton}
 * (defaults: primary solid `md`). Next to another primary, use `variant="outline"`.
 * `WexSheet.Close` remains the low-level primitive; `CloseButton` is the preset WexButton wiring.
 */
export type WexSheetCloseButtonProps = Omit<WexButtonProps, "asChild">;

/** @deprecated Use {@link WexSheetCloseButtonProps} / `WexSheet.CloseButton`. */
export type WexSheetDismissButtonProps = WexSheetCloseButtonProps;

const WexSheetCloseButton = React.forwardRef<
  HTMLButtonElement,
  WexSheetCloseButtonProps
>(({ children = "Close", type, ...props }, ref) => (
  <SheetClose asChild>
    <WexButton ref={ref} type={type ?? "button"} {...props}>
      {children}
    </WexButton>
  </SheetClose>
));
WexSheetCloseButton.displayName = "WexSheet.CloseButton";

/** @deprecated Use `WexSheet.CloseButton` instead. */
const WexSheetDismissButton = WexSheetCloseButton;

const WexSheetRootWithNamespace: typeof WexSheetRoot & {
  Portal: typeof SheetPortal;
  Overlay: typeof SheetOverlay;
  Trigger: typeof SheetTrigger;
  Close: typeof SheetClose;
  CloseButton: typeof WexSheetCloseButton;
  /** @deprecated Use `CloseButton` instead. */
  DismissButton: typeof WexSheetCloseButton;
  Content: typeof WexSheetContent;
  Header: typeof WexSheetHeader;
  Footer: typeof WexSheetFooter;
  Title: typeof SheetTitle;
  Description: typeof SheetDescription;
} = Object.assign(WexSheetRoot, {
  Portal: SheetPortal,
  Overlay: SheetOverlay,
  Trigger: SheetTrigger,
  Close: SheetClose,
  CloseButton: WexSheetCloseButton,
  DismissButton: WexSheetDismissButton,
  Content: WexSheetContent,
  Header: WexSheetHeader,
  Footer: WexSheetFooter,
  Title: SheetTitle,
  Description: SheetDescription,
});

export const WexSheet = WexSheetRootWithNamespace;

