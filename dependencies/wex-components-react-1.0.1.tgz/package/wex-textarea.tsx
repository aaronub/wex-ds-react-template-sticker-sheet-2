import * as React from "react";
import { cn } from "./lib/utils";

/**
 * WexTextarea - WEX Design System Textarea Component
 *
 * Multi-line text input for forms.
 * Uses WEX sizing tokens for accessible touch targets.
 *
 * @example
 * <WexLabel htmlFor="message">Message</WexLabel>
 * <WexTextarea id="message" placeholder="Type your message..." />
 */

// ============================================================================
// Base Textarea Component (from shadcn)
// ============================================================================

const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.ComponentProps<"textarea">
>(({ className, ...props }, ref) => {
  return (
    <textarea
      className={cn(
        "flex min-h-[60px] w-full rounded-[var(--wex-radius-controls-large)] border border-wex-textarea-border bg-transparent px-3 py-2 shadow-sm placeholder:text-wex-textarea-placeholder focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-wex-textarea-focus-ring disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      ref={ref}
      {...props}
    />
  );
});
Textarea.displayName = "Textarea";

// ============================================================================
// WEX Wrappers
// ============================================================================

interface WexTextareaProps extends React.ComponentPropsWithoutRef<typeof Textarea> {
  autoResize?: boolean;
  invalid?: boolean;
}

export const WexTextarea = React.forwardRef<
  React.ElementRef<typeof Textarea>,
  WexTextareaProps
>(({ className, autoResize, invalid, style, ...props }, ref) => {
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);

  React.useImperativeHandle(ref, () => textareaRef.current as HTMLTextAreaElement);

  React.useEffect(() => {
    if (autoResize && textareaRef.current) {
      const textarea = textareaRef.current;
      textarea.style.height = "auto";
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [autoResize, props.value]);

  return (
    <Textarea
      ref={textareaRef}
      className={cn(
        "wex-textarea h-20 border-wex-textarea-border bg-wex-textarea-bg text-sm text-wex-textarea-fg placeholder:text-wex-textarea-placeholder focus-visible:ring-wex-textarea-focus-ring disabled:opacity-[var(--wex-component-textarea-disabled-opacity)]",
        invalid && [
          "border-wex-input-invalid-border",
          "focus-visible:border-wex-input-invalid-border",
          "focus-visible:ring-wex-input-invalid-focus-ring",
        ],
        autoResize && "overflow-hidden resize-none",
        className
      )}
      style={style}
      aria-invalid={invalid || undefined}
      {...props}
    />
  );
});
WexTextarea.displayName = "WexTextarea";
