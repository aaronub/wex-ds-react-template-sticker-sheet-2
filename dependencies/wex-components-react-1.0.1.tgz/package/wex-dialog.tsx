import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { cn } from "./lib/utils";
import { WexButton, type WexButtonProps } from "./wex-button";
import {
  WexOverlayDeferredHostCloseContext,
  useWexOverlayDeferredHostClose,
} from "./lib/radix-overlay-deferred-host-close";

/**
 * WexDialog - WEX Design System Dialog Component
 *
 * Modal dialog for focused content that requires user attention.
 * Uses namespace pattern: WexDialog.Trigger, WexDialog.Content, etc.
 *
 * The root defers the host `onOpenChange(false)` call until the close has fully finished
 * (and falls back to a short timer if `WexDialog.Content` is not used). That keeps
 * create vs edit title/actions from updating while the exit animation is still running.
 *
 * @example
 * <WexDialog>
 *   <WexDialog.Trigger asChild>
 *     <WexButton>Open</WexButton>
 *   </WexDialog.Trigger>
 *   <WexDialog.Content>
 *     <WexDialog.Header>
 *       <WexDialog.Title>Title</WexDialog.Title>
 *       <WexDialog.Description>Optional supporting line (Radix Description).</WexDialog.Description>
 *     </WexDialog.Header>
 *     Main body (forms, paragraphs) goes here as siblings—one `gap` step from the header block.
 *     <WexDialog.Footer>
 *       <WexDialog.CloseButton>Close</WexDialog.CloseButton>
 *     </WexDialog.Footer>
 *   </WexDialog.Content>
 * </WexDialog>
 */

// ============================================================================
// Base Dialog Components (from Radix/shadcn)
// ============================================================================

const Dialog = DialogPrimitive.Root;

const DialogTrigger = DialogPrimitive.Trigger;

const DialogPortal = DialogPrimitive.Portal;

const DialogOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    )}
    {...props}
  />
));
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;

const DialogContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <DialogPortal>
    <DialogOverlay />
    <DialogPrimitive.Content
      ref={ref}
      className={cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-wex-dialog-bg p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] rounded-[var(--wex-radius-card-small)]",
        className
      )}
      {...props}
    >
      {children}
      <DialogPrimitive.Close className="absolute right-4 top-4 rounded-sm p-1 text-wex-dialog-description-fg opacity-70 ring-offset-background transition-all hover:opacity-100 hover:bg-wex-dialog-close-hover-bg focus:outline-none focus:ring-2 focus:ring-wex-dialog-focus-ring focus:ring-offset-2 disabled:pointer-events-none">
        <X className="h-4 w-4" />
        <span className="sr-only">Close</span>
      </DialogPrimitive.Close>
    </DialogPrimitive.Content>
  </DialogPortal>
));
DialogContent.displayName = DialogPrimitive.Content.displayName;

const DialogHeader = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col gap-3 text-center sm:text-left",
      className
    )}
    {...props}
  />
);
DialogHeader.displayName = "DialogHeader";

const DialogFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",
      className
    )}
    {...props}
  />
);
DialogFooter.displayName = "DialogFooter";

const DialogTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn(
      "text-lg font-semibold leading-none tracking-tight",
      className
    )}
    {...props}
  />
));
DialogTitle.displayName = DialogPrimitive.Title.displayName;

const DialogDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-wex-dialog-description-fg", className)}
    {...props}
  />
));
DialogDescription.displayName = DialogPrimitive.Description.displayName;

// ============================================================================
// WEX Wrappers
// ============================================================================

// CRITICAL: Dialog and Sheet share the same Radix primitive (@radix-ui/react-dialog)
// We must create a wrapper function to avoid mutating the shared Root object
// If we use Object.assign directly on DialogRoot, Sheet will overwrite Dialog's Content
const WexDialogRoot = ((props: React.ComponentProps<typeof Dialog>) => {
  const {
    open: openProp,
    defaultOpen,
    onOpenChange: onOpenChangeFromHost,
    modal = true,
    children,
    ...rest
  } = props;
  const isControlled = openProp !== undefined;
  const { contextValue, openForRoot, onOpenChange: handleOpenChange } =
    useWexOverlayDeferredHostClose(openProp, onOpenChangeFromHost);

  return (
    <WexOverlayDeferredHostCloseContext.Provider value={contextValue}>
      <Dialog
        {...rest}
        modal={modal}
        defaultOpen={defaultOpen}
        open={isControlled ? openForRoot : openProp}
        onOpenChange={handleOpenChange}
      >
        {children}
      </Dialog>
    </WexOverlayDeferredHostCloseContext.Provider>
  );
}) as typeof Dialog;

const WexDialogContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content> & {
    position?: "center" | "top" | "bottom" | "left" | "right";
    size?: "sm" | "md" | "lg" | "xl" | "full";
    maximizable?: boolean;
  }
>(({ className, position, size = "md", maximizable, children, onOpenAutoFocus, onCloseAutoFocus, tabIndex, ...props }, ref) => {
  const wexOverlayDeferred = React.useContext(WexOverlayDeferredHostCloseContext);

  // Inject styles to constrain animations to single axis
  React.useEffect(() => {
    const styleId = "wex-dialog-animation-overrides";
    if (document.getElementById(styleId)) return;
    
    const style = document.createElement("style");
    style.id = styleId;
    style.textContent = `
      /* Override Tailwind slide animations for wex-dialog-content */
      .wex-dialog-content[data-state="open"][class*="slide-in-from-top"],
      .wex-dialog-content[data-state="closed"][class*="slide-out-to-top"],
      .wex-dialog-content[data-state="open"][class*="slide-in-from-bottom"],
      .wex-dialog-content[data-state="closed"][class*="slide-out-to-bottom"],
      .wex-dialog-content[data-state="open"][class*="slide-in-from-left"],
      .wex-dialog-content[data-state="closed"][class*="slide-out-to-left"],
      .wex-dialog-content[data-state="open"][class*="slide-in-from-right"],
      .wex-dialog-content[data-state="closed"][class*="slide-out-to-right"] {
        animation-duration: 0ms !important;
      }
      
      /* Center position: override all slide animations, use only zoom - ensure proper centering */
      .wex-dialog-content[data-wex-dialog-position="center"] {
        left: 50% !important;
        top: 50% !important;
        transform: translate(-50%, -50%) !important;
      }
      .wex-dialog-content[data-wex-dialog-position="center"][data-state="open"] {
        animation: wex-dialog-zoom-in 200ms ease-out forwards !important;
      }
      .wex-dialog-content[data-wex-dialog-position="center"][data-state="closed"] {
        animation: wex-dialog-zoom-out 200ms ease-in forwards !important;
      }
      
      @keyframes wex-dialog-zoom-in {
        from { 
          transform: translate(-50%, -50%) scale(0.95);
          opacity: 0;
        }
        to { 
          transform: translate(-50%, -50%) scale(1);
          opacity: 1;
        }
      }
      @keyframes wex-dialog-zoom-out {
        from { 
          transform: translate(-50%, -50%) scale(1);
          opacity: 1;
        }
        to { 
          transform: translate(-50%, -50%) scale(0.95);
          opacity: 0;
        }
      }
      
      /* Top: slide down from top (vertical Y-axis only) - ensure horizontal centering is maintained */
      .wex-dialog-content[data-wex-dialog-position="top"] {
        left: 50% !important;
        top: 1rem !important;
        transform: translate(-50%, 0) !important;
      }
      .wex-dialog-content[data-wex-dialog-position="top"][data-state="open"] {
        animation: wex-dialog-slide-in-top 200ms ease-out forwards !important;
      }
      .wex-dialog-content[data-wex-dialog-position="top"][data-state="closed"] {
        animation: wex-dialog-slide-out-top 200ms ease-in forwards !important;
      }
      
      /* Bottom: slide up from bottom (vertical Y-axis only) - ensure horizontal centering is maintained */
      .wex-dialog-content[data-wex-dialog-position="bottom"] {
        left: 50% !important;
        bottom: 1rem !important;
        transform: translate(-50%, 0) !important;
      }
      .wex-dialog-content[data-wex-dialog-position="bottom"][data-state="open"] {
        animation: wex-dialog-slide-in-bottom 200ms ease-out forwards !important;
      }
      .wex-dialog-content[data-wex-dialog-position="bottom"][data-state="closed"] {
        animation: wex-dialog-slide-out-bottom 200ms ease-in forwards !important;
      }
      
      /* Left: slide in from left (horizontal X-axis only) */
      .wex-dialog-content[data-wex-dialog-position="left"] {
        left: 1rem !important;
        top: 50% !important;
        transform: translate(0, -50%) !important;
      }
      .wex-dialog-content[data-wex-dialog-position="left"][data-state="open"] {
        animation: wex-dialog-slide-in-left 200ms ease-out forwards !important;
      }
      .wex-dialog-content[data-wex-dialog-position="left"][data-state="closed"] {
        animation: wex-dialog-slide-out-left 200ms ease-in forwards !important;
      }
      
      /* Right: slide in from right (horizontal X-axis only) */
      .wex-dialog-content[data-wex-dialog-position="right"] {
        right: 1rem !important;
        top: 50% !important;
        transform: translate(0, -50%) !important;
      }
      .wex-dialog-content[data-wex-dialog-position="right"][data-state="open"] {
        animation: wex-dialog-slide-in-right 200ms ease-out forwards !important;
      }
      .wex-dialog-content[data-wex-dialog-position="right"][data-state="closed"] {
        animation: wex-dialog-slide-out-right 200ms ease-in forwards !important;
      }
      
      @keyframes wex-dialog-slide-in-top {
        from { 
          transform: translate(-50%, -100%);
          opacity: 0;
        }
        to { 
          transform: translate(-50%, 0);
          opacity: 1;
        }
      }
      @keyframes wex-dialog-slide-out-top {
        from { 
          transform: translate(-50%, 0);
          opacity: 1;
        }
        to { 
          transform: translate(-50%, -100%);
          opacity: 0;
        }
      }
      @keyframes wex-dialog-slide-in-bottom {
        from { 
          transform: translate(-50%, 100%);
          opacity: 0;
        }
        to { 
          transform: translate(-50%, 0);
          opacity: 1;
        }
      }
      @keyframes wex-dialog-slide-out-bottom {
        from { 
          transform: translate(-50%, 0);
          opacity: 1;
        }
        to { 
          transform: translate(-50%, 100%);
          opacity: 0;
        }
      }
      @keyframes wex-dialog-slide-in-left {
        from { 
          transform: translate(-100%, -50%);
          opacity: 0;
        }
        to { 
          transform: translate(0, -50%);
          opacity: 1;
        }
      }
      @keyframes wex-dialog-slide-out-left {
        from { 
          transform: translate(0, -50%);
          opacity: 1;
        }
        to { 
          transform: translate(-100%, -50%);
          opacity: 0;
        }
      }
      @keyframes wex-dialog-slide-in-right {
        from { 
          transform: translate(100%, -50%);
          opacity: 0;
        }
        to { 
          transform: translate(0, -50%);
          opacity: 1;
        }
      }
      @keyframes wex-dialog-slide-out-right {
        from { 
          transform: translate(0, -50%);
          opacity: 1;
        }
        to { 
          transform: translate(100%, -50%);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);
    
    return () => {
      const existingStyle = document.getElementById(styleId);
      if (existingStyle) {
        existingStyle.remove();
      }
    };
  }, []);
  
  const sizeClasses = {
    sm: "max-w-sm",
    md: "max-w-lg",
    lg: "max-w-2xl",
    xl: "max-w-4xl",
    full: "max-w-[calc(100vw-2rem)]",
  };

  // Position classes - only set positioning, transforms handled by CSS
  const positionClasses = {
    center: "left-1/2 top-1/2",
    top: "left-1/2 top-4",
    bottom: "left-1/2 bottom-4",
    left: "left-4 top-1/2",
    right: "right-4 top-1/2",
  };

  const modalPosition = position ?? "center";
  const [isMaximized, setIsMaximized] = React.useState(false);

  return (
    <DialogPortal>
      <DialogOverlay />
      <DialogPrimitive.Content
        ref={ref}
        data-wex-dialog-position={!isMaximized ? modalPosition : undefined}
        className={cn(
          "wex-dialog-content fixed z-50 grid w-full gap-4 border bg-wex-dialog-bg p-6 shadow-lg duration-200 text-wex-dialog-fg border-wex-dialog-border",
          "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          "outline-none focus:outline-none",
          sizeClasses[size],
          !isMaximized && positionClasses[modalPosition],
          !isMaximized && modalPosition === "center" && "data-[state=open]:zoom-in-95 data-[state=closed]:zoom-out-95",
          isMaximized && "inset-4 !left-4 !right-4 !top-4 !bottom-4 !translate-x-0 !translate-y-0 w-auto h-auto max-w-none",
          maximizable && "wex-dialog-maximizable",
          "rounded-[var(--wex-radius-card-small)]",
          className
        )}
        style={isMaximized ? { width: "calc(100vw - 2rem)", height: "calc(100vh - 2rem)" } : undefined}
        {...props}
        tabIndex={tabIndex ?? -1}
        onOpenAutoFocus={(event) => {
          onOpenAutoFocus?.(event);
          if (event.defaultPrevented) return;
          // Radix otherwise focuses the first tabbable node — our close button is often first.
          event.preventDefault();
          (event.currentTarget as HTMLElement).focus();
        }}
        onCloseAutoFocus={(event) => {
          wexOverlayDeferred?.flushDeferredClose();
          onCloseAutoFocus?.(event);
        }}
      >
        {children}
        {maximizable && (
          <button
            type="button"
            onClick={() => setIsMaximized(!isMaximized)}
            className="absolute right-12 top-4 rounded-sm p-1 text-wex-dialog-description-fg opacity-70 ring-offset-background transition-all hover:opacity-100 hover:bg-wex-dialog-close-hover-bg focus:outline-none focus:ring-2 focus:ring-wex-dialog-focus-ring focus:ring-offset-2 disabled:pointer-events-none z-10"
            aria-label={isMaximized ? "Restore" : "Maximize"}
          >
            {isMaximized ? (
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 9V4.5M9 9H4.5M9 9L3.75 3.75M9 15v4.5M9 15H4.5M9 15l-5.25 5.25M15 9h4.5M15 9V4.5M15 9l5.25-5.25M15 15h4.5M15 15v4.5m0-4.5l5.25 5.25" />
              </svg>
            ) : (
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8h4V4m12 4h-4V4m-4 12H8v4m8-4v4" />
              </svg>
            )}
            <span className="sr-only">{isMaximized ? "Restore" : "Maximize"}</span>
          </button>
        )}
        <DialogPrimitive.Close className="absolute right-4 top-4 rounded-sm p-1 text-wex-dialog-description-fg opacity-70 ring-offset-background transition-all hover:opacity-100 hover:bg-wex-dialog-close-hover-bg focus:outline-none focus:ring-2 focus:ring-wex-dialog-focus-ring focus:ring-offset-2 disabled:pointer-events-none">
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </DialogPrimitive.Close>
      </DialogPrimitive.Content>
    </DialogPortal>
  );
});
WexDialogContent.displayName = "WexDialog.Content";

const WexDialogOverlay = React.forwardRef<
  React.ElementRef<typeof DialogOverlay>,
  React.ComponentPropsWithoutRef<typeof DialogOverlay>
>(({ className, ...props }, ref) => (
  <DialogOverlay
    ref={ref}
    className={cn(
      "bg-wex-dialog-overlay",
      className
    )}
    {...props}
  />
));
WexDialogOverlay.displayName = "WexDialog.Overlay";

const WexDialogClose = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Close>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Close>
>(({ className, asChild, ...props }, ref) => {
  // If asChild is provided, the child component (e.g., WexButton) handles its own styling
  // We only pass through the close functionality without additional styling
  if (asChild) {
    return (
      <DialogPrimitive.Close
        ref={ref}
        className={className}
        asChild={asChild}
        {...props}
      />
    );
  }
  
  // Default: render with X icon (styled close button)
  return (
    <DialogPrimitive.Close
      ref={ref}
      className={cn(
        "absolute right-4 top-4 rounded-sm p-1 text-wex-dialog-description-fg opacity-70 ring-offset-background transition-all hover:opacity-100 hover:bg-wex-dialog-close-hover-bg focus:outline-none focus:ring-2 focus:ring-wex-dialog-focus-ring focus:ring-offset-2 disabled:pointer-events-none",
        className
      )}
      {...props}
    >
      <X className="h-4 w-4" />
      <span className="sr-only">Close</span>
    </DialogPrimitive.Close>
  );
});
WexDialogClose.displayName = "WexDialog.Close";

/**
 * Footer **close** control: same Radix `Close` primitive as the header X, rendered as a
 * {@link WexButton} (defaults: primary solid `md`, matching Done / Save).
 * Prefer this over `onClick={() => setOpen(false)}` when `open` drives visible copy during exit.
 * Next to another solid primary (e.g. Save), pass `variant="outline"` (and `intent="primary"`).
 *
 * `WexDialog.Close` stays the low-level Radix primitive (icon close, or `asChild` with any element).
 * `CloseButton` is the preset **WexButton** wiring for footers.
 */
export type WexDialogCloseButtonProps = Omit<WexButtonProps, "asChild">;

/** @deprecated Use {@link WexDialogCloseButtonProps} / `WexDialog.CloseButton`. */
export type WexDialogDismissButtonProps = WexDialogCloseButtonProps;

const WexDialogCloseButton = React.forwardRef<
  HTMLButtonElement,
  WexDialogCloseButtonProps
>(({ children = "Close", type, ...props }, ref) => (
  <DialogPrimitive.Close asChild>
    <WexButton ref={ref} type={type ?? "button"} {...props}>
      {children}
    </WexButton>
  </DialogPrimitive.Close>
));
WexDialogCloseButton.displayName = "WexDialog.CloseButton";

/** @deprecated Use `WexDialog.CloseButton` instead. */
const WexDialogDismissButton = WexDialogCloseButton;

const WexDialogTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn(
      "text-lg font-semibold leading-snug tracking-tight text-wex-dialog-header-fg",
      className
    )}
    {...props}
  />
));
WexDialogTitle.displayName = "WexDialog.Title";

const WexDialogFooter = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 text-wex-dialog-footer-fg",
      className
    )}
    {...props}
  />
));
WexDialogFooter.displayName = "WexDialog.Footer";

const WexDialogRootWithNamespace: typeof WexDialogRoot & {
  Portal: typeof DialogPortal;
  Overlay: typeof WexDialogOverlay;
  Trigger: typeof DialogTrigger;
  Close: typeof WexDialogClose;
  CloseButton: typeof WexDialogCloseButton;
  /** @deprecated Use `CloseButton` instead. */
  DismissButton: typeof WexDialogCloseButton;
  Content: typeof WexDialogContent;
  Header: typeof DialogHeader;
  Footer: typeof WexDialogFooter;
  Title: typeof WexDialogTitle;
  Description: typeof DialogDescription;
} = Object.assign(WexDialogRoot, {
  Portal: DialogPortal,
  Overlay: WexDialogOverlay,
  Trigger: DialogTrigger,
  Close: WexDialogClose,
  CloseButton: WexDialogCloseButton,
  DismissButton: WexDialogDismissButton,
  Content: WexDialogContent,
  Header: DialogHeader,
  Footer: WexDialogFooter,
  Title: WexDialogTitle,
  Description: DialogDescription,
});

export const WexDialog = WexDialogRootWithNamespace;
